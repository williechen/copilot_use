# Pet 教學版本

來源：williechen/copilot_use@59e30c9dabfcfa1eff036de3a81143521bfac41a

原始檔案位於 copilot_use/，保留原路徑及原始 bytes。共 264 份；逐檔 Git blob／SHA256 見 MANIFEST.json。

包含歷史版本或現行對照，不表示所有內容已驗收；各文件的來源 SHA、日期及成功／失敗維持原範圍。跨包相對連結請將各包的 copilot_use/ 解壓至同一目錄。
