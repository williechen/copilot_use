## ① 學習大綱、現況與來源

<b>P0 / Chat Day 26 — 登出立即撤銷單一 SQLite Session，並開始抽取可跨系統共用的 Cookie/token 規則。</b> 來源：rust\_ai\_chat/main <code>aaa9194a966aefae1ef4724f5d2b576b4289c550</code>、教學分支 <code>4c759cf1c25eecb762be266915ed4abe3a273faa</code>；共同規則 <code>daily-tdd-minimum-v1</code>、blob <code>143fd1592322acda2a2c7821006f87020eec3518</code>。本頁是<b>待使用者套用的教學</b>，沒有修改 rust\_ai\_chat 原始碼。

既有：<code>apps/server/src/signin.rs</code> 的 POST /login 建立 mbr\_session、GET /account 驗證；<code>room_auth.rs</code> 守住 /room/\{room\_id\}；<code>apps/server/src/lib.rs</code> 未提供 POST /logout，<code>signin.rs</code> 與 <code>room_auth.rs</code> 仍分別複製 Cookie/SHA/Session 查詢。最早可操作缺口之一是登入後<b>無法主動登出</b>；本日只完成「撤銷本人一筆有效 Session」的單一功能切片。下一日繼續共享 Session Port/ACL，不能把此篇當全套 Auth 或房間授權完成。

## ② 實作內容：Red → 最小 Green → Refactor

### Red：從實際入口驗證登出與裝置隔離

缺少路由時 <code>POST /logout</code> 預期得到 404；這是<b>待執行的預期 Red</b>，不是本次已執行失敗。測試須採既有 SQLite migrations、登入後原 Session cookie，再送出登出表單。下方提供完整可執行整合測試。

### Green A：共用 token/Cookie 規則

<code>crates/shared/Cargo.toml</code> 的 \[dependencies\] 增加 <code>sha2.workspace = true</code>，<code>crates/shared/src/lib.rs</code> 增加 <code>pub mod auth;</code>。新增 <code>crates/shared/src/auth.rs</code> 完整內容：

```rs
use sha2::{Digest, Sha256};

pub fn cookie_token(header: &str, name: &str) -> Option<String> {
    let value = header.split(';').filter_map(|part| part.trim().split_once('='))
        .find(|(key, _)| *key == name)?.1;
    (value.len() == 64 && value.bytes().all(|b| b.is_ascii_hexdigit()))
        .then(|| value.to_owned())
}

pub fn token_digest(token: &str) -> String {
    Sha256::digest(token.as_bytes()).iter()
        .map(|b| format!("{b:02x}")).collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn cookie_name_is_exact_and_token_is_validated() {
        let token = "a".repeat(64);
        assert_eq!(cookie_token(&format!("xchat_session={token}; chat_session={token}"), "chat_session"), Some(token.clone()));
        assert_eq!(cookie_token("chat_session=bad", "chat_session"), None);
        assert_eq!(cookie_token("analytics_session=abc", "chat_session"), None);
        assert_eq!(token_digest(&token).len(), 64);
    }
}
```

此共用模組不認識 Chat 或 Analytics DB；Cookie 名稱由呼叫端傳入，兩系統仍使用不同 Cookie 名稱與不同資料庫。<b>不要把 token hash 或 Cookie 解析再次貼進各系統新 Handler。</b>

### Green B：登出路由（含 Origin 與表單 CSRF）

新增 <code>apps/server/src/logout.rs</code>：

```rs
use axum::{
    Form, Router,
    extract::State,
    http::{HeaderMap, StatusCode, header},
    response::{IntoResponse, Response},
    routing::post,
};
use serde::Deserialize;
use shared::auth::{cookie_token, token_digest};
use sqlx::SqlitePool;

#[derive(Deserialize)]
struct LogoutForm { csrf: String }

pub fn routes(pool: SqlitePool) -> Router {
    Router::new().route("/logout", post(logout)).with_state(pool)
}

async fn logout(
    State(pool): State<SqlitePool>,
    headers: HeaderMap,
    Form(form): Form<LogoutForm>,
) -> Result<Response, StatusCode> {
    if headers.get(header::ORIGIN).and_then(|v| v.to_str().ok())
        != Some("http://127.0.0.1:3000") {
        return Err(StatusCode::FORBIDDEN);
    }
    let token = headers.get(header::COOKIE).and_then(|v| v.to_str().ok())
        .and_then(|h| cookie_token(h, "chat_session"))
        .ok_or(StatusCode::UNAUTHORIZED)?;
    if form.csrf != token_digest(&format!("logout:{token}")) {
        return Err(StatusCode::FORBIDDEN);
    }
    let result = sqlx::query("DELETE FROM mbr_session WHERE token_hash=?1")
        .bind(token_digest(&token)).execute(&pool).await
        .map_err(|_| StatusCode::SERVICE_UNAVAILABLE)?;
    if result.rows_affected() != 1 {
        return Err(StatusCode::UNAUTHORIZED);
    }
    Ok((
        StatusCode::SEE_OTHER,
        [(header::LOCATION, "/"),
         (header::SET_COOKIE, "chat_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0"),
         (header::CACHE_CONTROL, "no-store")],
    ).into_response())
}
```

<code>apps/server/src/lib.rs</code> 增加 <code>pub mod logout;</code>，在 <code>application()</code> 內既有 <code>let signin_routes = ...;</code> 之後新增：

```rs
let logout_routes = logout::routes(db.clone());
```

於 Router 原有 <code>.merge(signin_routes)</code> 後再接 <code>.merge(logout_routes)</code>。CSRF 值不存新資料表，由既有 Session token 導出；POST 驗證 Origin，拒絕跨站提交。正式部署如不在 loopback 3000，必須將既有 login/signup 及此路由改為一致的可信 Origin 政策。Cookie 若改在 HTTPS，須統一加入 Secure 屬性。

### Green C：在已登入的帳號頁提供真正可操作的登出

<code>apps/server/src/signin.rs</code> 的 <code>account</code> Handler 在驗證通過後已持有 <code>token</code>。將回傳型別從 <code>Result<Html<&'static str>, StatusCode></code> 改為 <code>Result<Html<String>, StatusCode></code>，最後的靜態 <code>Ok(Html(...))</code> 改為：

```rs
let csrf = shared::auth::token_digest(&format!("logout:{token}"));
Ok(Html(format!(r#"<!doctype html>
<html lang="zh-Hant"><head><meta charset="utf-8"><title>已登入</title></head>
<body><h1>已登入</h1>
<form action="/logout" method="post">
<input type="hidden" name="csrf" value="{csrf}">
<button type="submit">登出</button></form>
<a href="/">回首頁</a></body></html>"#)))
```

這裡的 token 是目前已驗證 Cookie，HTML 隱藏欄位僅傳送雜湊後的 CSRF，<b>不把原始 bearer token 寫進 HTML</b>。Account 頁的現有 Cookie 查詢暫留，下一個共用 Session Port 切片才統一改接 Adapter。

### Green D：完整整合測試

新增 <code>apps/server/tests/day26_logout.rs</code>（需既有 dev-dependency <code>tower</code>、<code>sha2</code>、<code>sqlx</code>）：

```rs
use axum::{body::Body,http::{Request,StatusCode,header}};
use server::{signin,logout};
use sha2::{Digest,Sha256};
use tower::ServiceExt;

fn hash(t: &str) -> String {
    Sha256::digest(t.as_bytes()).iter().map(|b| format!("{b:02x}")).collect()
}

#[tokio::test]
async fn day26_logout_revokes_only_one_session() {
    let db = sqlx::sqlite::SqlitePoolOptions::new().max_connections(1)
        .connect("sqlite::memory:").await.unwrap();
    sqlx::raw_sql(include_str!("../../../migrations/20261018073931_create_auth_user.sql"))
        .execute(&db).await.unwrap();
    sqlx::raw_sql(include_str!("../../../migrations/20261020152737_mbr_sessions.sql"))
        .execute(&db).await.unwrap();
    sqlx::query("INSERT INTO mbr_user (id,user_acnt,user_pd,user_email,user_name,user_status,user_sexy,user_birthday,is_init_pd,created_at,updated_at) VALUES('m1','user','hash','u@test.example','User','active',NULL,NULL,FALSE,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)")
        .execute(&db).await.unwrap();
    let a = "a".repeat(64); let b = "b".repeat(64);
    for (id,raw) in [("s1",&a),("s2",&b)] {
        sqlx::query("INSERT INTO mbr_session(id,mbr_user_id,token_hash,expires_at) VALUES(?1,'m1',?2,unixepoch()+3600)")
            .bind(id).bind(hash(raw)).execute(&db).await.unwrap();
    }
    let app = axum::Router::new().merge(signin::routes(db.clone()))
        .merge(logout::routes(db.clone()));
    let req = |raw: &str| Request::get("/account")
        .header(header::COOKIE,format!("chat_session={raw}"))
        .body(Body::empty()).unwrap();
    assert_eq!(app.clone().oneshot(req(&a)).await.unwrap().status(), StatusCode::OK);
    let csrf = hash(&format!("logout:{a}"));
    let bad = app.clone().oneshot(Request::post("/logout")
        .header(header::ORIGIN,"http://127.0.0.1:3000")
        .header(header::COOKIE,format!("chat_session={a}"))
        .header(header::CONTENT_TYPE,"application/x-www-form-urlencoded")
        .body(Body::from("csrf=wrong")).unwrap()).await.unwrap();
    assert_eq!(bad.status(),StatusCode::FORBIDDEN);
    let ok = app.clone().oneshot(Request::post("/logout")
        .header(header::ORIGIN,"http://127.0.0.1:3000")
        .header(header::COOKIE,format!("chat_session={a}"))
        .header(header::CONTENT_TYPE,"application/x-www-form-urlencoded")
        .body(Body::from(format!("csrf={csrf}"))).unwrap()).await.unwrap();
    assert_eq!(ok.status(),StatusCode::SEE_OTHER);
    assert!(ok.headers()[header::SET_COOKIE].to_str().unwrap().contains("Max-Age=0"));
    assert_eq!(app.clone().oneshot(req(&a)).await.unwrap().status(),StatusCode::UNAUTHORIZED);
    assert_eq!(app.oneshot(req(&b)).await.unwrap().status(),StatusCode::OK);
}
```

### Refactor 與舊 Day 補教（FIFO）

Refactor：将 <code>signin.rs::token_digest()</code> 及 <code>room_auth.rs</code> 的 SHA 計算替換為 <code>shared::auth::token_digest</code>，Cookie 擷取改用 <code>shared::auth::cookie_token</code>；但需同時將 <code>room_auth</code>、<code>account</code> 的 Session 查詢收斂為一個共享 storage Port 才能完成跨系統重構。此篇<b>不冒稱</b>已完成共用登入／Session；Analytics 的 PostgreSQL Adapter 後續接入，同時維持 Cookie 與登入狀態獨立。

Day25 補教狀態：<code>chat-day25-shared-auth-20261022</code> 保留 pending。Day25 已完成的房間 Session Gate 不回寫、不重教；完整 shared login/logout/session 經真實呼叫端核對之前不得關閉該 FIFO 單元。

## ③ Cargo、套件版本

Workspace edition 2024、version 0.2.25；依 <code>Cargo.toml</code>：Axum 0.8、sqlx 0.9、sha2 0.11、Tokio 1.54、uuid 1.28、serde 1.0。新增依賴只有 shared crate 的 <code>sha2.workspace = true</code>。本日未執行 <code>cargo update</code>，亦未核驗 lock 實際解析版本、MSRV 與 native/WASM 建置結果；禁止把 workspace 需求範圍當成精確 lock 結果。

## ④ 驗證項目：命令／預期／實際／CI／限制

1. <code>cargo test -p server day26_logout -- --nocapture</code>：預期登出後 cookie A 失效、cookie B 不受影響；<b>本次未執行</b>。
2. <code>cargo test -p shared auth -- --nocapture</code>：預期 Cookie 名稱與 token 長度檢查通過；<b>本次未執行</b>。
3. <code>cargo test -p server</code> 與 <code>cargo check -p server --features ssr</code>：預期舊登入／房間測試無退化；<b>本次未執行</b>。
4. 實際瀏覽器：登入 → /account → 登出 → 再進 /account 應 401；另一裝置仍登入；<b>本次未部署／未驗收</b>。
5. CI：<code>rust_ai_chat/main</code> SHA <code>aaa9194a966aefae1ef4724f5d2b576b4289c550</code>、[Rust Dashboard Run 39651403341](https://github.com/williechen/rust_ai_chat/actions/runs/39651403341) completed/success；屬<b>來源提交</b>，不含本教學尚未套用的修改，故不能當本 Green 通過。
6. 尚未完成：共享 Session Storage Port、有效 Session 滑動續期、房間成員 ACL、REST 建房和 WebSocket 的權限重驗、Cookie Secure/Origin 部署政策、完整產品入口測試。上述均不視為 Day26 驗收通過。

<b>發布規則：</b> 只有完整 Notion 正文讀回成功才有資格條件式推進該專案 next\_day；單純撰寫或 CI 狀態不使 Day 增加。
