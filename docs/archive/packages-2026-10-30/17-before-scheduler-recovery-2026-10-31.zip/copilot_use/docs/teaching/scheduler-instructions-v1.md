# 每日教學執行規則

本頁保留接續教學所需的提示詞；本次未修改雲端任務的時間、模型或啟用狀態。實際設定需另讀即時任務。

```text
每日依Chat→Pet→Analytics交付TDD文章。先讀copilot_use/main的共用規則、需求、架構、learning-state、manifest、入口與上一篇，核對兩庫精確SHA及當日官方穩定版本，依目前next_day選功能，不固定Day或重複發布。

每篇保留目標、完整Red／Green、版本與驗證，另設與Red／Green並列的「Refactor」獨立段落，只處理該篇所屬專案：Chat只寫Chat、Pet只寫Pet、Analytics只寫Analytics。依各案累積進度逐步整理自身架構、測試、fixture與專案CI，不限定當日功能切片，也不作Green後續的小整理。交代逐檔完整變更／patch、有效斷言承接、實際驗證與下一步；未完成如實記錄。

全專案重構獨立集中於docs/engineering/README.md：跨案契約、共用crates、跨workspace依賴與全庫CI。不得混入各案Refactor或重複計功。

開工先確認當次可用GitHub／網頁與執行工具。Gate1文件交付與Gate2產品驗收分開：沒有本地checkout、Rust/Cargo、DB、GUI或CI權限時，繼續用可用工具完成GitHub來源、官方穩定版本與相容限制、完整Red／Green／Refactor、patch接線及讀回，不要求使用者提供本地資訊，不單憑Gate2未跑阻止合格文件發布。真正程式／patch／文件缺陷仍須版本化修訂；無法驗證項明列未執行，不能把靜態hunk或舊SHA結果當實測。

每案獨立commit到copilot_use/main，從精確commit全文讀回並保存blob／SHA256；重查parent與目前state，Gate1條件齊備後才依expected next_day條件同步學習狀態、manifest、七首頁及ENTRY。已同步不再加一；單案受阻繼續其他獨立案，衝突不得強制覆寫。修訂保留原文／歷史證據與FIFO，不增加Day，不更新last_full_comparison。

只寫copilot_use/main；rust_ai_ring唯讀，完整產品變更由使用者套用。有執行工具才在隔離副本與測試DB驗證，保留真命令、exit、SHA與限制；不碰正式DB／秘密／付費AI。核心60分鐘只計Red／Green，Refactor與版本／驗證／交付另計。

每次完成回報三案實際文章連結、commit、讀回／同步狀態、目前next_day、Gate1／Gate2與具體剩餘缺口。不要只交計畫或因環境不足停在籠統候選；中斷時保留已提交成果與單一待續記錄，避免重複提交。
```

執行時只讀現行規則／需求／架構／state／manifest；上一篇若只留 ZIP，從分包讀取所列 entry。Day44 未驗證原稿保留原檔。

[共用規則](../COMMON_LEARNING_RULES.md) · [現況](current/STATUS.md)
