<mention-page url="https://app.notion.com/p/3f2e51d4509381ddb8a8ce7cb4cd3e60">Rust AI 三專案｜共同學習規則與前進目標</mention-page>
本頁說明本專案的功能、操作主線、當前缺口與證據入口；每日完整程式與實作步驟放在既有 Day。現行教學方法、時程、四節格式、發布讀回、條件推進及失敗恢復，統一引用上方共同總頁「每日 TDD 教學最小必要規則 v1」（daily-tdd-minimum-v1／2026-10-18）。
Day18 三篇已在既有頁發布並讀回；learning-state 的 next_day 各為 19。本次正式複驗與文章修訂沒有增加 Day。98f30d8／next_day=17、18 等舊觀察保留歷史身分，目前實作與驗收以本頁第3、4節及 Day18 為準。
## 1. 專案大綱與操作主線
建立可啟動、互動與持久保存設定的桌面寵物，再逐步提供受控的檔案整理、學習記憶及 AI 協作。
基本主線：啟動寵物 → 即時調整互動／設定 → 保存設定與記憶 → 授權目錄 → 掃描／SHA256 預覽 → 確認或取消 → 受控操作 → 成功收據／還原 → Analytics 紀錄。每段可跨 Day 完成；確認預覽與實際檔案操作分別判定。
## 已逐項確認的現行需求（2026-10-17）
以下 16 組需求經使用者逐項核對；屬現行要求，未宣稱已實作或驗收。網頁／本地排程每次重新讀取並採用；與下方歷史來源觀察或封存 Day 不同時，以本節作為後續需求，歷史證據保留原 SHA 與範圍。Day15／Day16 保持封存，不新增 Day，原記錄 next_day 各17屬歷史；目前各19，本輪文章修訂未遞增。
### Pet：多寵物、出入籠與活動
- 控制窗有多隻寵物清單，每隻各有獨立狀態、設定與生活窗，可同時出籠；狀態同步以寵物識別分流，不將所有寵物共用一份狀態。
- 「回籠子」關閉該隻生活窗、停止活動，保留資料與設定，不刪除也不影響其他寵物；直接關生活窗等同回籠子。只有出籠寵物會活動。啟動時僅預設寵物自動出籠，可預設多隻；回籠不取消預設資格。
- 關閉控制窗不停止已出籠寵物；重開只顯示並聚焦既有控制窗。已出籠者再按出籠只聚焦自己的既有生活窗。
- 右鍵提供「開啟控制窗」「回籠子」「坐下」；開啟控制窗時自動選取自己；坐下等同關閉該隻漫遊。
- 控制窗與寵物生活窗皆可手動拖曳，自動漫遊只移動寵物，不移動控制窗。拖曳寵物時暫停漫遊，放開依原開關恢復；漫遊開關逐隻持久保存，重啟沿用。
- 走、跑、睡、跳依種類習性自然交替，不提供使用者固定速度設定。關閉漫遊時坐原地，僅保留眨眼、呼吸等細微待機動畫，不跑跳。睡覺停止自動位移，仍可手動拖曳。
- 多隻寵物可重疊並依習性互相打鬧，打鬧會吵醒睡覺的寵物；被吵醒後依種類與個性決定加入、避開或繼續睡。關閉漫遊者不參與追逐或跑跳打鬧。
- 正常活動支援跨螢幕並遵守可用工作區邊界；螢幕拔除或配置改變不立即搬回，讓寵物自行跑回。控制窗提供「找回寵物」，手動移回可見螢幕，不改漫遊設定。
## 2. 功能目標與完成條件
- 寵物與控制：五欄設定（名字、種類、喜好、個性、興趣），選用外觀覆寫；每隻寵物的資料與素材獨立。設定能即時生效並在重啟後保留。
- 顯示與移動：200×200 範圍內等比動畫，手動拖曳與明確啟用的自動漫遊，多寵物逐步加入；移動偏好不能因重開控制面板而意外變更。
- 安全整理：只處理授權 root，前台使用 opaque ID；確認綁定目前掃描結果，操作前重驗權限／symlink／檔案變更，並有 journal、隔離收據與還原。預覽、確認及 Domain 成功狀態都不能代替真實 OS 結果。
- 後續能力：記憶／回想／複習／提醒、RAG／MCP／Agent、備份／還原、安裝包與簽章更新；更新由啟動或手動檢查觸發。
## 3. 目前程式與 Day16 封存
本輪來源main `2c7ace259ef790cea303d841f5779cd5f022d554`；修正分支codex/revalidate-f9484f2，commit `1abcb8aa6bc279e888a057b87069bea788281c7c`，未合併main。完整workspace明確啟用SSR、PostgreSQL integration及include-ignored：main126通過／1失敗／0忽略，候選131通過／0失敗／0忽略。main的WASM／SSR、Pet前端及原生建置成功；fmt通過，嚴格Clippy仍失敗於logout巢狀if，候選嚴格Clippy通過。規則v1正文、既有需求及next_day各19不變；文章修訂不推進Day。
資料庫：Chat六份migration／20張業務表；main新建chat_action_log已拒絕缺少／NULL主鍵，不能再寫「NULL仍可插入」。但任意created_user_id仍可接受、沒有Rust寫入呼叫端，不算完整稽核。main直接修改20261018122554，從fa0888e升級實際checksum mismatch；舊Chat91733與舊PG31仍missing migration。候選還原舊migration並新增20261018130000前向修補，有效舊row保留、NULL舊row中止且資料／歷史保留，共六案通過；此候選僅相容原fa歷史，已套用改版22554的f9484f2／2c7ace2資料庫仍checksum mismatch，不能直接套用或刪庫掩蓋。table及field可依功能需求增減，使用者資料庫未重建或清空。
Pet：最新main使用獨立SQLite三份migration／九張業務表，普通停用啟動與前端／原生建置通過。候選只加可選原生探針，對實際Tauri視窗重跑enabled／disabled／boundary／close四案：main不移動、停用不移動pet、邊界反彈及關窗不回退main通過。探針等待映射後啟動，不能代替普通啟動漫遊時序、完整手動GUI、拖曳暫停恢復、逐寵物設定持久化、多寵物及真實多螢幕驗證。
原發布98f30d8／舊候選的紀錄只適用其原SHA，不再作當前結論。完整修正與重現集中於既有Day18。
Day16 封存入口：<mention-page url="https://app.notion.com/p/3fce51d4509381e9aa03d633822eee89">2026-10-17｜P0 Pet Day 16｜寵物生活與控制雙視窗</mention-page>。<mention-page url="https://app.notion.com/p/3fbe51d4509381d68666d3031d1c8011">2026-10-17｜P0 Pet Day 15｜掃描後確認與取消流程</mention-page>
[目前程式驗證與未完成項目](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/teaching/evidence/2026-10-17-source-98f30d8-recheck.json)；以下為保留的功能目標與驗收條件，是否完成以上方最新來源及證據為準。
#### 控制介面目標：雙窗骨架已套用，其餘能力分段驗收
一個後台控制窗管理多隻寵物，各出籠寵物有獨立原生生活窗，不採放大同一張混合頁面的方式。前台寵物保留 200×200 等比動畫、拖曳、漫遊與右鍵入口；後台控制視窗承載六區功能並可縮放／捲動。關閉控制視窗後寵物繼續運作，反覆開啟只聚焦既有視窗，透過後端 snapshot／事件同步。原單視窗放大修正檔不採用，未獲授權套用至原始碼；雙視窗骨架已在目前來源存在；以下仍為完整功能目標，驗收狀態以上方目前證據為準。Day15／Day16 原文不改。
寵物視窗與控制視窗分工：寵物視窗保留 200×200 等比動畫、拖曳與右鍵入口；控制視窗使用 Leptos，可調整大小並可捲動，不把掃描結果、設定表單與所有按鈕堆進寵物小視窗。重複開啟只顯示／聚焦既有控制視窗，關閉控制視窗不停止寵物，不建立新寵物。
控制視窗分為六個功能區：
- 互動：狀態、互動／結束／睡覺／醒來、已有聊天入口；漫遊逐隻保存；右鍵「坐下」關閉漫遊；動作速度依種類習性，不提供固定速度設定。
- 設定：五欄與選用外觀；必須能讀回、保存及重啟保留，缺後端時明示未接通。
- 記憶：列表、查詢與管理接既有資料服務；尚無對應 API 時只顯示能力狀態，不放無作用的操作按鈕。
- 檔案：授權狀態 → 掃描／SHA256 → 結果 → 確認／取消 → 操作結果／收據 → 還原。只呈現可用 IPC；預覽確認與真實操作分開，未有操作 IPC 時明示未接通。
- 管理：多寵物、備份／還原及封存；依實作能力逐步接通。
- 更新：版本與啟動／手動檢查，依安裝與簽章更新能力接線。
控制窗依寵物識別同步各生活窗的獨立後端狀態；分頁切換不新增寵物、不自行掃描或觸發檔案動作。掃描、確認、收據與錯誤保留在對應功能區，長結果可換行／捲動且操作按鈕可到達。
驗收包含：控制視窗縮至可用小尺寸及放大、系統縮放、鍵盤焦點與捲動、長清單／錯誤文案、六區切換、反覆開啟不重複建立、關閉後寵物仍運作；專用目錄實測 UI → bridge → Tauri → OS／資料層 → 回應 → 畫面，無後端的功能不得假報成功。雙窗骨架已有實作；上述完整 GUI／IPC／檔案流程仍需後續 Day 分段驗收，Day15／Day16 不修改。
## 4. 驗證方式與尚未驗收範圍
Pet：最新main使用獨立SQLite三份migration／九張業務表，普通停用啟動與前端／原生建置通過。候選只加可選原生探針，對實際Tauri視窗重跑enabled／disabled／boundary／close四案：main不移動、停用不移動pet、邊界反彈及關窗不回退main通過。探針等待映射後啟動，不能代替普通啟動漫遊時序、完整手動GUI、拖曳暫停恢復、逐寵物設定持久化、多寵物及真實多螢幕驗證。
完整命令、預期／實際結果、環境、SHA、CI workflow/job與證據連結見[本輪完整證據](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/teaching/evidence/2026-10-19-full-2c7ace2/REPORT.md)。CI只代表其實際覆蓋；零測試target、未執行與失敗不算通過。跨平台／MSRV、付費AI未測，未讀正式秘密。三專案完整功能均維持未驗收。
## 5. 開發位置與使用本入口的方式
學習庫 apps/desktop_pet 負責 Tauri／OS 入口，frontend 負責 Leptos 畫面與 bridge，crates/pet_domain 負責純規則；產品端另有 crates/pet_runtime，介面與學習庫不同，不照抄檔名當成已同步。
本機 IPC 可用於測試實際能力，使用全新測試資料與授權目錄；本入口不要求重跑付費 AI。實作與驗證步驟看對應 Day，不將專用測試收據當成私人檔案已處理。
[產品操作設定](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/DEPLOYMENT.md) · [產品未來清單](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/FUTURE_WORK.md)
## 既有Day索引
<page url="https://app.notion.com/p/3fee51d45093811c83eed982ef9ab69e">2026-10-20｜Pet Day 22｜建立寵物與 SQLite 儲存【已封存】</page>
<page url="https://app.notion.com/p/3fee51d450938163b451e803639e657c">2026-10-19｜P0 Pet Day 21｜新增寵物表單與名稱 IPC 前置接線</page>
<page url="https://app.notion.com/p/3fee51d45093816897feec3468239e43">2026-10-19｜P0 Pet Day 20｜可用工作區不足時停止無效漫遊</page>
<page url="https://app.notion.com/p/3fde51d450938194ae7fdcc55bce44e2">2026-10-19｜P0 Pet Day 19｜觀察到非預期位移時停止漫遊</page>
<page url="https://app.notion.com/p/3fde51d4509381bfa106ea4d9b190480">2026-10-18｜P0 Pet Day 18｜漫遊只移動生活窗並核對真實標籤</page>
<page url="https://app.notion.com/p/3fce51d4509381ca83e3e825f0313698">2026-10-18｜P0 Pet Day 17｜漫遊指向寵物生活窗</page>
<page url="https://app.notion.com/p/3fce51d4509381e9aa03d633822eee89">2026-10-17｜P0 Pet Day 16｜寵物生活與控制雙視窗</page>
<page url="https://app.notion.com/p/3fbe51d4509381d68666d3031d1c8011">2026-10-17｜P0 Pet Day 15｜掃描後確認與取消流程</page>
<page url="https://app.notion.com/p/3fbe51d4509381e484f4eb9e1f98fc68">2026-10-16｜P0 Pet Day 14｜主動掃描授權目錄與摘要顯示</page>
<page url="https://app.notion.com/p/3fae51d45093814dbdabee6deac48554">2026-10-16｜P0 Pet Day 13｜重複預覽顯示群組大小與檔案數</page>
<page url="https://app.notion.com/p/3fae51d4509381d0a80ddbbaf251fb03">2026-10-15｜P0 Pet Day 12｜桌面漫遊明確啟用控制</page>
<page url="https://app.notion.com/p/3f9e51d450938152a147c931e3e945be">2026-10-15｜P0 Pet Day 11｜SHA256 重複預覽接入 Tauri 與 UI</page>
<page url="https://app.notion.com/p/3f9e51d4509381f7ab32d0dc8b389a86">2026-10-14｜P0 Pet Day 10｜Profile 驗證後才解析外觀</page>
<page url="https://app.notion.com/p/3f8e51d4509381c3b989f2365fd0c0af">2026-10-14｜P0 Pet Day 9｜Profile 外觀覆寫與預設值合併</page>
<page url="https://app.notion.com/p/3f8e51d4509381bf9da4c44750ffc726">2026-10-13｜正式補跑｜Pet｜成功事件契約測試</page>
<page url="https://app.notion.com/p/3f8e51d45093815fbec6ec85bc547bd6">2026-10-13｜手動補跑｜Pet｜既有 CleanupOperation 狀態機的重入防護</page>
## Day22 封存與下一 Day 修正（2026-10-20）
Day22（含）以前所有既有文章均已封存，原文、版本勘誤與歷史證據保留，不回寫舊文；不只Day22三篇。後續差異在下一Day新實作／Refactor後補充。next_day維持23；本次未發布Day23。新版建立寵物 IPC 已存在；舊 migration 修改造成升級 checksum mismatch，生活窗身分與重啟載入仍未完成。
下一 Day 先完成本日新 Red／完整 Green／Refactor，再追加一個「舊 Day 更正補充（程式／套件差異）」單元；執行時重核最新main與官方套件、按既有makeup_queue FIFO，全文讀回後才結案。
[下一 Day 的 Day22 更正補充草稿](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/teaching/pending/day23/pet-day22-corrections.md)
