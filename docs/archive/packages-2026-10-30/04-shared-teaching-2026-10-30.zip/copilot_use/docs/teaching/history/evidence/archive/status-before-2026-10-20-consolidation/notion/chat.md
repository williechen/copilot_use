<mention-page url="https://app.notion.com/p/3f2e51d4509381ddb8a8ce7cb4cd3e60">Rust AI 三專案｜共同學習規則與前進目標</mention-page>
本頁說明本專案的功能、操作主線、當前缺口與證據入口；每日完整程式與實作步驟放在既有 Day。現行教學方法、時程、四節格式、發布讀回、條件推進及失敗恢復，統一引用上方共同總頁「每日 TDD 教學最小必要規則 v1」（daily-tdd-minimum-v1／2026-10-18）。
Day18 三篇已在既有頁發布並讀回；learning-state 的 next_day 各為 19。本次正式複驗與文章修訂沒有增加 Day。98f30d8／next_day=17、18 等舊觀察保留歷史身分，目前實作與驗收以本頁第3、4節及 Day18 為準。
## 1. 專案大綱與操作主線
建立多人、多房間的聊天系統，先讓使用者能建立房間、找到房間、選房並聊天，再逐步接上身分、權限、歷史與管理。
前台主線：公開房間清單 → 點房名 → 必要時登入 → 伺服器核對房間權限 → 進房收發 → 重進讀歷史 → Analytics。首頁登入／管理另導向個人頁；註冊完成維持登出，從獨立訊息頁按回首頁後重新選房。這是分段完成方向。
後台主線：系統管理者管理 AI 聊天者、每人可開房間數、公告與管理者帳號。房間管理與系統管理分開，不能把房主當成系統管理者。
## 已逐項確認的現行需求（2026-10-17）
以下 16 組需求經使用者逐項核對；屬現行要求，未宣稱已實作或驗收。網頁／本地排程每次重新讀取並採用；與下方歷史來源觀察或封存 Day 不同時，以本節作為後續需求，歷史證據保留原 SHA 與範圍。Day15／Day16 保持封存，不新增 Day，原記錄 next_day 各17屬歷史；目前各19，本輪文章修訂未遞增。
### Chat：已確認的入口、註冊與管理
- 首頁未登入即可查看可公開顯示的聊天室清單；點聊天室名稱連結後，未登入者先登入並保留目標房間，再由伺服器核對進入權限。有權才進房，無權顯示拒絕原因；看得到房間不代表有權進入。已登入者直接核對權限，不重複登入。
- 首頁「登入」成功後前往個人頁；已登入時文字改為「管理」，直接進個人頁。Session 失效才重新登入，成功後仍回個人頁。個人頁建立／管理自己有權管理的聊天室；系統管理另設入口並由伺服器核權。
- 一般使用者自行註冊，以唯一且不分英文大小寫的自訂帳號＋密碼登入；Email 唯一、不需驗證，用於密碼重設。註冊完成維持登出、清除原選房目標，顯示獨立完成訊息頁，不自動跳轉；只有按「回首頁」才返回清單，之後須重新選房。
- 僅首次初始化建立系統管理者 admin/admin；首次登入須修改密碼並設定唯一 Email，完成後才可使用系統管理功能；之後仍可修改密碼。密碼以加鹽雜湊持久保存，重啟不重設。
### Chat 與 Analytics：各系統獨立的人員登入保護
- 連續登入失敗次數以各系統的帳號累計，由伺服器保存；等待自 15 秒起逐次加倍（15、30、60、120 秒……），不設上限，重新整理、換瀏覽器或 IP 不重設。失敗保留原登入導向。
- 等待期間再次送出時拒絕驗證並回傳剩餘時間；不增加次數、不重新起算倒數。登入成功清除失敗次數及等待時間。
- 管理頁修改密碼須驗目前密碼；忘記密碼則寄重設連結至登記 Email。修改或重設成功均清除失敗次數與等待時間，使該帳號所有 Session 失效，須重新登入。
- 登入後持續操作會更新活動時間，Session 持續有效；閒置逾時由各系統的管理後台設定。不能只因登入後經過固定時間而強制登出；密碼變更、停用與授權撤銷仍須生效。
## 2. 功能目標與完成條件
- 基本聊天：從真實首頁進入房間，兩個瀏覽器可在同房收發；不同房間不串訊息。SQLite 寫入失敗不能先發送成功廣播。
- 房間管理：只操作自己有權管理的房間；成員停用／恢復限定該房間。房主交接後失去管理權並保留一般聊天資格，AI 設定仍由系統管理者管理。
- 歷史與帳號：重啟後可讀回已保存訊息；刪除帳號前處理房主交接或封存，保留應保留的聊天紀錄。
- 後續能力：Session／ACL、presence／typing／reconnect、Outbox、備份，接著才逐步加入 streaming、RAG／MCP／Agent、多 Persona 與同意／撤回。
## 3. 目前程式與 Day16 封存
Chat：main已接通後端參數化SQL LIKE，名稱不是room ID；完整／部分名稱、字面%／_／反斜線、注入字串與輸入限制12案通過，瀏覽器「Rust 技術交流」完整顯示同名兩筆及「Rust 技術交流延伸」共三筆，空結果提示正確。真WS七案及SQLite持久化讀回通過。但SSR「歷史載入尚未接通」仍缺少，重新整理遇503會清空原有結果，故本切片仍有阻擋；候選恢復提示、直接顯示SQL結果並保留失敗前清單。
### copilot_use產品試作（與參考庫驗收分開）
copilot_use P0 試作已完成註冊身分切片：本地工作分支 `codex/p0-table-trial`，commit `948685fe0692a9e56de94a4ae6a817fdf13fc0a2`（基底 `0bf1d460ea8f20dfaa3bcdaf14b7a895d1b3aacd`，未合併main）。沿用chat_users，新增email與帳號／Email不分英文大小寫唯一索引；註冊必填Email，成功後撤銷該瀏覽器舊Session並保持登出。UI→HTTP→SQLite→獨立完成頁、不同大小寫登入個人頁、重啟保存已實測。相關測試21通過／0失敗，HTTP／資料檢查16案、舊資料升級2案、fmt／嚴格Clippy／前端建置通過。既有帳號Email暫為NULL、大小寫衝突升級回滾；Email重設寄信、舊帳號補Email、admin初始化、遞增登入等待及完整活動Session仍待實作，Pet／Analytics本次未新增功能，完整P0未驗收。詳[試作與重現證據](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/teaching/evidence/2026-10-18-copilot-p0-registration/REPORT.md)。
### rust_ai_chat參考庫複驗
本輪來源main `2c7ace259ef790cea303d841f5779cd5f022d554`；修正分支codex/revalidate-f9484f2，commit `1abcb8aa6bc279e888a057b87069bea788281c7c`，未合併main。完整workspace明確啟用SSR、PostgreSQL integration及include-ignored：main126通過／1失敗／0忽略，候選131通過／0失敗／0忽略。main的WASM／SSR、Pet前端及原生建置成功；fmt通過，嚴格Clippy仍失敗於logout巢狀if，候選嚴格Clippy通過。規則v1正文、既有需求及next_day各19不變；文章修訂不推進Day。
資料庫：Chat六份migration／20張業務表；main新建chat_action_log已拒絕缺少／NULL主鍵，不能再寫「NULL仍可插入」。但任意created_user_id仍可接受、沒有Rust寫入呼叫端，不算完整稽核。main直接修改20261018122554，從fa0888e升級實際checksum mismatch；舊Chat91733與舊PG31仍missing migration。候選還原舊migration並新增20261018130000前向修補，有效舊row保留、NULL舊row中止且資料／歷史保留，共六案通過；此候選僅相容原fa歷史，已套用改版22554的f9484f2／2c7ace2資料庫仍checksum mismatch，不能直接套用或刪庫掩蓋。table及field可依功能需求增減，使用者資料庫未重建或清空。
Chat：main已接通後端參數化SQL LIKE，名稱不是room ID；完整／部分名稱、字面%／_／反斜線、注入字串與輸入限制12案通過，瀏覽器「Rust 技術交流」完整顯示同名兩筆及「Rust 技術交流延伸」共三筆，空結果提示正確。真WS七案及SQLite持久化讀回通過。但SSR「歷史載入尚未接通」仍缺少，重新整理遇503會清空原有結果，故本切片仍有阻擋；候選恢復提示、直接顯示SQL結果並保留失敗前清單。
原發布98f30d8／舊候選的紀錄只適用其原SHA，不再作當前結論。完整修正與重現集中於既有Day18。
Day16 封存入口：<mention-page url="https://app.notion.com/p/3fce51d450938143a0b9cc9a3f93860e">2026-10-17｜P0 Chat Day 16｜清楚選房與聊天</mention-page>。<mention-page url="https://app.notion.com/p/3fbe51d450938130a3c0c93171105f3a">2026-10-17｜P0 Chat Day 15｜首頁房間列表與選房流程</mention-page>
[目前程式驗證與未完成項目](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/teaching/evidence/2026-10-17-source-98f30d8-recheck.json)；以下為保留的功能目標與驗收條件，是否完成以上方最新來源及證據為準。
#### 聊天前台目標：基本選房聊天已實測，管理入口待分離
聊天前台使用 Leptos，採左側房間欄、中央訊息區、底部輸入區；個人管理與系統後台使用各自頁面／路由及後端權限，不塞進聊天訊息區。
- 首頁只顯示聊天室清單與必要狀態；建立／管理房間放個人管理頁，點選清單後進入聊天頁。
- 房間欄：顯示可存取房間與目前選取狀態，沿用既有列表 API；窄螢幕時可收合，切換不應把草稿送往錯誤房間。
- 訊息區：房間名稱與連線狀態固定可見，訊息以氣泡與適當寬度呈現；辨識自己、其他使用者、AI／系統。作者、時間與日期分隔只使用實際資料，缺少時明示或省略，不編造頭像、線上人數或歷史紀錄。
- 輸入區：多行輸入、送出與清楚的鍵盤操作，處理中文輸入法組字；空白／送出中禁用，保留失敗草稿。傳送中、失敗／重試等狀態須由真實協定與回應支持，不將本地送出成功冒稱伺服器已持久化。
- 使用回饋：載入、空房間引導、錯誤及重新連線狀態清楚可辨；歷史載入或重連若尚無完整後端能力，明示未接通，不顯示沒有作用的按鈕。
- 視覺與可用性：柔和背景、清楚留白與一致字體；訊息區獨立捲動，輸入區不被長訊息擠出，長文字／網址可換行。不能只靠顏色區分作者；鍵盤焦點、對比、窄螢幕與系統縮放均需驗證。
驗收從真實房間列表進房，測同房收發／跨房隔離、切房與草稿、長訊息、空／錯誤狀態、斷線、中文多行輸入及窄螢幕；無訊息確認或重試冪等能力時不能宣稱傳送狀態已完整實作。基本瀏覽器選房／聊天已依上方來源實測，其餘項目尚未完整驗收；參考庫複驗未直接修改main；copilot_use試作另列於上方，Day15／Day16 保留。
## 4. 驗證方式與尚未驗收範圍
Chat：main已接通後端參數化SQL LIKE，名稱不是room ID；完整／部分名稱、字面%／_／反斜線、注入字串與輸入限制12案通過，瀏覽器「Rust 技術交流」完整顯示同名兩筆及「Rust 技術交流延伸」共三筆，空結果提示正確。真WS七案及SQLite持久化讀回通過。但SSR「歷史載入尚未接通」仍缺少，重新整理遇503會清空原有結果，故本切片仍有阻擋；候選恢復提示、直接顯示SQL結果並保留失敗前清單。
完整命令、預期／實際結果、環境、SHA、CI workflow/job與證據連結見[本輪完整證據](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/teaching/evidence/2026-10-19-full-2c7ace2/REPORT.md)。CI只代表其實際覆蓋；零測試target、未執行與失敗不算通過。跨平台／MSRV、付費AI未測，未讀正式秘密。三專案完整功能均維持未驗收。
## 5. 開發位置與使用本入口的方式
學習庫：apps/server 負責 HTTP／WS，crates/ui 負責畫面，chat_domain／chat_application 負責規則與 Port，crates/persistence 負責 SQLite／migration；資料庫差異留在 Adapter。
先讀目前 Day 的「學習大綱」確認前置能力，再按第 2 節套用與 Refactor，最後照第 4 節從真實入口驗證。已實作的舊篇用來追溯，不照順序把所有舊程式再貼一次。
[產品操作設定](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/DEPLOYMENT.md) · [產品未來清單](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/FUTURE_WORK.md)；兩者是 copilot_use 產品文件，執行學習庫時仍以該庫目前 Cargo／README 為準。
## 既有Day索引
<page url="https://app.notion.com/p/3fee51d45093814385cdcdc9e693789a">2026-10-20｜P0 Chat Day 22｜會員註冊表單與 SQLite【已封存】</page>
<page url="https://app.notion.com/p/3fee51d450938168aaa0c11d9ad7d827">2026-10-19｜P0 Chat Day 21｜登入頁可達但不偽裝已登入</page>
<page url="https://app.notion.com/p/3fee51d4509381d1a1e6eb5e5a1c996e">2026-10-19｜P0 Chat Day 20｜重新整理後顯示完整房間快照</page>
<page url="https://app.notion.com/p/3fde51d4509381d2aac7ea4b356c213b">2026-10-19｜P0 Chat Day 19｜重新整理失敗保留房間列表</page>
<page url="https://app.notion.com/p/3fde51d45093816bb36dd9099190d907">2026-10-18｜P0 Chat Day 18｜查詢房間完成 HTTP 接線與錯誤恢復</page>
<page url="https://app.notion.com/p/3fce51d45093818b913bebb8dab5ab65">2026-10-18｜P0 Chat Day 17｜查詢房間接通 HTTP</page>
<page url="https://app.notion.com/p/3fce51d450938143a0b9cc9a3f93860e">2026-10-17｜P0 Chat Day 16｜清楚選房與聊天</page>
<page url="https://app.notion.com/p/3fbe51d450938130a3c0c93171105f3a">2026-10-17｜P0 Chat Day 15｜首頁房間列表與選房流程</page>
<page url="https://app.notion.com/p/3fbe51d450938149af5dd68abc6109bd">2026-10-16｜P0 Chat Day 14｜以 HTTP 讀回 SQLite 房間資料</page>
<page url="https://app.notion.com/p/3fae51d4509381e499e5e02cfba58336">2026-10-16｜P0 Chat Day 13｜HTTP 建房名稱驗證與 201 Created</page>
<page url="https://app.notion.com/p/3fae51d45093812bbf88c3e7f51d6522">2026-10-15｜P0 Chat Day 12｜WebSocket 房間 Typing 即時通知</page>
<page url="https://app.notion.com/p/3f9e51d4509381508c0dd3ca22cf5df7">2026-10-15｜P0 Chat Day 11｜WebSocket 寫入時重新核對房間</page>
<page url="https://app.notion.com/p/3f9e51d45093818a849dd8b1fbf2c045">2026-10-14｜P0 Chat Day 10｜防止錯誤房間查詢結果寫入訊息</page>
<page url="https://app.notion.com/p/3f8e51d45093814b992eea570411bd7d">2026-10-14｜P0 Chat Day 9｜房間不存在時禁止持久化訊息</page>
<page url="https://app.notion.com/p/3f8e51d450938174a707d200f2e0de52">2026-10-13｜正式補跑｜Chat｜持久化成功後通知的對稱測試</page>
<page url="https://app.notion.com/p/3f8e51d45093816690f8d5b4ff04ff70">2026-10-13｜手動補跑｜Chat｜既有 MessageRepository 的 SQLite 遷移切片</page>
## 2026-10-19｜Chat Day 19
本日教學：重新整理失敗時保留上次房間列表。完整程式、Red／Green／Refactor 與實測範圍見下方 Day19；程式尚未套用 main，完整功能未驗收。
## Day22 封存與下一 Day 修正（2026-10-20）
Day22（含）以前所有既有文章均已封存，原文、版本勘誤與歷史證據保留，不回寫舊文；不只Day22三篇。後續差異在下一Day新實作／Refactor後補充。next_day維持23；本次未發布Day23。已確認新版註冊欄位驗證與既有測試不一致，並有舊 migration checksum 問題；完整修正候選與新版 Argon2 API 說明已列待補。
下一 Day 先完成本日新 Red／完整 Green／Refactor，再追加一個「舊 Day 更正補充（程式／套件差異）」單元；執行時重核最新main與官方套件、按既有makeup_queue FIFO，全文讀回後才結案。
[下一 Day 的 Day22 更正補充草稿](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/teaching/pending/day23/chat-day22-corrections.md)
