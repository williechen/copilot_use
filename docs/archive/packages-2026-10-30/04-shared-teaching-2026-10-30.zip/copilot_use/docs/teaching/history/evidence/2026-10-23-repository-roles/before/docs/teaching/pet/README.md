# Pet 首頁

[共用文章](../../COMMON_LEARNING_RULES.md) · [三專案首頁](../README.md)

## 目前狀態

[單一目前進度](../current/STATUS.md) · [即時進度檔](../../learning-state.json)。本文的需求不代表已完成；不在首頁複製過期的 Day 或測試快照。

## 專案大綱與操作主線

建立可啟動、互動與持久保存設定的桌面寵物，再逐步提供受控的檔案整理、學習記憶及 AI 協作。

基本主線：啟動寵物 → 即時調整互動／設定 → 保存設定與記憶 → 授權目錄 → 掃描／SHA256 預覽 → 確認或取消 → 受控操作 → 成功收據／還原 → Analytics 紀錄。每段可跨 Day 完成；確認預覽與實際檔案操作分別判定。

## 現行需求

[三專案使用者流程](../../requirements/USER_FLOWS.md) · [共用人員驗證](../../requirements/AUTHENTICATION.md) · [UI 詳細驗收](../../UI_ALIGNMENT_REQUIREMENTS.md)。共用條款統一維護，不在各首頁重複。

## 功能目標與完成條件

- 寵物與控制：五欄設定（名字、種類、喜好、個性、興趣），選用外觀覆寫；每隻寵物的資料與素材獨立。設定能即時生效並在重啟後保留。
- 顯示與移動：200×200 範圍內等比動畫，手動拖曳與明確啟用的自動漫遊，多寵物逐步加入；移動偏好不能因重開控制面板而意外變更。
- 安全整理：只處理授權 root，前台使用 opaque ID；確認綁定目前掃描結果，操作前重驗權限／symlink／檔案變更，並有 journal、隔離收據與還原。預覽、確認及 Domain 成功狀態都不能代替真實 OS 結果。
- 後續能力：記憶／回想／複習／提醒、RAG／MCP／Agent、備份／還原、安裝包與簽章更新；更新由啟動或手動檢查觸發。

## 介面與接線要求

#### 控制介面目標：雙窗骨架已套用，其餘能力分段驗收

一個後台控制窗管理多隻寵物，各出籠寵物有獨立原生生活窗，不採放大同一張混合頁面的方式。前台寵物保留 200×200 等比動畫、拖曳、漫遊與右鍵入口；後台控制視窗承載六區功能並可縮放／捲動。關閉控制視窗後寵物繼續運作，反覆開啟只聚焦既有視窗，透過後端 snapshot／事件同步。以下為完整功能要求，仍需分段驗收。

寵物視窗與控制視窗分工：寵物視窗保留 200×200 等比動畫、拖曳與右鍵入口；控制視窗使用 Leptos，可調整大小並可捲動，不把掃描結果、設定表單與所有按鈕堆進寵物小視窗。重複開啟只顯示／聚焦既有控制視窗，關閉控制視窗不停止寵物，不建立新寵物。

控制視窗分為六個功能區：

- 互動：狀態、互動／結束／睡覺／醒來、已有聊天入口；漫遊逐隻保存；右鍵「坐下」關閉漫遊；動作速度依種類習性，不提供固定速度設定。
- 設定：五欄與選用外觀；必須能讀回、保存及重啟保留，缺後端時明示未接通。
- 記憶：列表、查詢與管理接既有資料服務；尚無對應 API 時只顯示能力狀態，不放無作用的操作按鈕。
- 檔案：授權狀態 → 掃描／SHA256 → 結果 → 確認／取消 → 操作結果／收據 → 還原。只呈現可用 IPC；預覽確認與真實操作分開，未有操作 IPC 時明示未接通。
- 管理：多寵物、備份／還原及封存；依實作能力逐步接通。
- 更新：版本與啟動／手動檢查，依安裝與簽章更新能力接線。

控制窗依寵物識別同步各生活窗的獨立後端狀態；分頁切換不新增寵物、不自行掃描或觸發檔案動作。掃描、確認、收據與錯誤保留在對應功能區，長結果可換行／捲動且操作按鈕可到達。

驗收包含：控制視窗縮至可用小尺寸及放大、系統縮放、鍵盤焦點與捲動、長清單／錯誤文案、六區切換、反覆開啟不重複建立、關閉後寵物仍運作；專用目錄實測 UI → bridge → Tauri → OS／資料層 → 回應 → 畫面，無後端的功能不得假報成功。雙窗骨架已有實作；上述完整 GUI／IPC／檔案流程仍需後續 Day 分段驗收。

## 驗證範圍

已核驗來源與測試範圍統一見GitHub [目前進度](../current/STATUS.md)。完整功能驗收仍須由真實入口逐段測試；單元測試、資料寫入或建置通過不能代替使用者流程驗收。

## 開發位置

學習庫 apps/desktop\_pet 負責 Tauri／OS 入口，frontend 負責 Leptos 畫面與 bridge，crates/pet\_domain 負責純規則；產品端另有 crates/pet\_runtime，介面與學習庫不同，不照抄檔名當成已同步。

本機 IPC 可用於測試實際能力，使用全新測試資料與授權目錄；本入口不要求重跑付費 AI。實作與驗證步驟看對應 Day，不將專用測試收據當成私人檔案已處理。

[產品操作設定](https://github.com/williechen/copilot_use/blob/main/docs/DEPLOYMENT.md) · [產品未來清單](https://github.com/williechen/copilot_use/blob/main/docs/FUTURE_WORK.md)


## 目前教學

- **最新已發布：** [Pet Day 27](../daily/day-27/pet.md)（教學文章與程式套用／驗收分開）
- 前一篇：[Pet Day 26](../daily/day-26/pet.md)
- **下一篇 Day：** 以 [learning-state.json](../../learning-state.json) 的 `next_day.pet` 即時值為準；不依首頁快照或直接重發 Day27。

<details>
<summary>歷史文章、修訂與原始封存證據</summary>

| Day | 文章與原始資料 |
| --- | --- |
| 25 | [文章／版本／證據](../history/day-25/pet/README.md) |
| 24 | [文章／版本／證據](../history/day-24/pet/README.md) |
| 23 | [文章／版本／證據](../history/day-23/pet/README.md) |
| 22 | [文章／版本／證據](../history/day-22/pet/README.md) |
| 21 | [文章／版本／證據](../history/day-21/pet/README.md) |
| 20 | [文章／版本／證據](../history/day-20/pet/README.md) |
| 19 | [文章／版本／證據](../history/day-19/pet/README.md) |
| 18 | [文章／版本／證據](../history/day-18/pet/README.md) |
| 17 | [文章／版本／證據](../history/day-17/pet/README.md) |
| 16 | [文章／版本／證據](../history/day-16/pet/README.md) |
| 15 | [文章／版本／證據](../history/day-15/pet/README.md) |
| 14 | [文章／版本／證據](../history/day-14/pet/README.md) |
| 13 | [文章／版本／證據](../history/day-13/pet/README.md) |
| 12 | [文章／版本／證據](../history/day-12/pet/README.md) |
| 11 | [文章／版本／證據](../history/day-11/pet/README.md) |
| 10 | [文章／版本／證據](../history/day-10/pet/README.md) |
| 9 | [文章／版本／證據](../history/day-09/pet/README.md) |
| 8 | [文章／版本／證據](../history/day-08/pet/README.md) |
| 7 | [文章／版本／證據](../history/day-07/pet/README.md) |
| 6 | [文章／版本／證據](../history/day-06/pet/README.md) |
| 5 | [文章／版本／證據](../history/day-05/pet/README.md) |
| 4 | [文章／版本／證據](../history/day-04/pet/README.md) |
| 3 | [文章／版本／證據](../history/day-03/pet/README.md) |
| 2 | [文章／版本／證據](../history/day-02/pet/README.md) |

</details>
