<mention-page url="https://app.notion.com/p/3f2e51d4509381ddb8a8ce7cb4cd3e60"/>

## 目前狀態

已實作：註冊、帳密登入、SQLite 持久 Session 與房間頁 Session Gate。

待完成：共用登入／登出／Cookie／Session，以及房間 ACL、API／WebSocket 授權。Chat Day25 補教 pending，依本專案 FIFO 在適用的新教學 Red／Green／Refactor 後補入。

下一教學：Day26。產品完整瀏覽器流程尚未驗收。

本頁呈現現行需求與缺口；每日方法、排程與驗證來源以共同主頁為準。

## 專案大綱與操作主線

建立多人、多房間的聊天系統，先讓使用者能建立房間、找到房間、選房並聊天，再逐步接上身分、權限、歷史與管理。

前台主線：公開房間清單 → 點房名 → 必要時登入 → 伺服器核對房間權限 → 進房收發 → 重進讀歷史 → Analytics。首頁登入／管理另導向個人頁；註冊完成維持登出，從獨立訊息頁按回首頁後重新選房。這是分段完成方向。

後台主線：系統管理者管理 AI 聊天者、每人可開房間數、公告與管理者帳號。房間管理與系統管理分開，不能把房主當成系統管理者。

## 現行需求

以下為功能要求，實作與驗收狀態以上方摘要為準。

### Chat：已確認的入口、註冊與管理

- 首頁未登入即可查看可公開顯示的聊天室清單；點聊天室名稱連結後，未登入者先登入並保留目標房間，再由伺服器核對進入權限。有權才進房，無權顯示拒絕原因；看得到房間不代表有權進入。已登入者直接核對權限，不重複登入。
- 首頁「登入」成功後前往個人頁；已登入時文字改為「管理」，直接進個人頁。Session 失效才重新登入，成功後仍回個人頁。個人頁建立／管理自己有權管理的聊天室；系統管理另設入口並由伺服器核權。
- 一般使用者自行註冊，以唯一且不分英文大小寫的自訂帳號＋密碼登入；Email 唯一、不需驗證，用於密碼重設。註冊完成維持登出、清除原選房目標，顯示獨立完成訊息頁，不自動跳轉；只有按「回首頁」才返回清單，之後須重新選房。
- 僅首次初始化建立系統管理者 admin/admin；首次登入須修改密碼並設定唯一 Email，完成後才可使用系統管理功能；之後仍可修改密碼。密碼以加鹽雜湊持久保存，重啟不重設。

### Chat 與 Analytics：各系統獨立的人員登入保護

- 連續登入失敗次數以各系統的帳號累計，由伺服器保存；等待自 15 秒起逐次加倍（15、30、60、120 秒……），不設上限，重新整理、換瀏覽器或 IP 不重設。失敗保留原登入導向。
- 等待期間再次送出時拒絕驗證並回傳剩餘時間；不增加次數、不重新起算倒數。登入成功清除失敗次數及等待時間。
- 管理頁修改密碼須驗目前密碼；忘記密碼則寄重設連結至登記 Email。修改或重設成功均清除失敗次數與等待時間，使該帳號所有 Session 失效，須重新登入。
- 登入後持續操作會更新活動時間，Session 持續有效；閒置逾時由各系統的管理後台設定。不能只因登入後經過固定時間而強制登出；密碼變更、停用與授權撤銷仍須生效。

## 功能目標與完成條件

- 基本聊天：從真實首頁進入房間，兩個瀏覽器可在同房收發；不同房間不串訊息。SQLite 寫入失敗不能先發送成功廣播。
- 房間管理：只操作自己有權管理的房間；成員停用／恢復限定該房間。房主交接後失去管理權並保留一般聊天資格，AI 設定仍由系統管理者管理。
- 歷史與帳號：重啟後可讀回已保存訊息；刪除帳號前處理房主交接或封存，保留應保留的聊天紀錄。
- 後續能力：Session／ACL、presence／typing／reconnect、Outbox、備份，接著才逐步加入 streaming、RAG／MCP／Agent、多 Persona 與同意／撤回。

## 介面與接線要求

#### 聊天前台與管理入口

聊天前台使用 Leptos，採左側房間欄、中央訊息區、底部輸入區；個人管理與系統後台使用各自頁面／路由及後端權限，不塞進聊天訊息區。

- 首頁只顯示聊天室清單與必要狀態；建立／管理房間放個人管理頁，點選清單後進入聊天頁。
- 房間欄：顯示可存取房間與目前選取狀態，沿用既有列表 API；窄螢幕時可收合，切換不應把草稿送往錯誤房間。
- 訊息區：房間名稱與連線狀態固定可見，訊息以氣泡與適當寬度呈現；辨識自己、其他使用者、AI／系統。作者、時間與日期分隔只使用實際資料，缺少時明示或省略，不編造頭像、線上人數或歷史紀錄。
- 輸入區：多行輸入、送出與清楚的鍵盤操作，處理中文輸入法組字；空白／送出中禁用，保留失敗草稿。傳送中、失敗／重試等狀態須由真實協定與回應支持，不將本地送出成功冒稱伺服器已持久化。
- 使用回饋：載入、空房間引導、錯誤及重新連線狀態清楚可辨；歷史載入或重連若尚無完整後端能力，明示未接通，不顯示沒有作用的按鈕。
- 視覺與可用性：柔和背景、清楚留白與一致字體；訊息區獨立捲動，輸入區不被長訊息擠出，長文字／網址可換行。不能只靠顏色區分作者；鍵盤焦點、對比、窄螢幕與系統縮放均需驗證。

驗收從真實房間列表進房，測同房收發／跨房隔離、切房與草稿、長訊息、空／錯誤狀態、斷線、中文多行輸入及窄螢幕；無訊息確認或重試冪等能力時不能宣稱傳送狀態已完整實作。完整瀏覽器互動仍須按上述條件驗收。

## 驗證範圍

已核驗來源與測試範圍統一見共同主頁「目前進度」。完整功能驗收仍須由真實入口逐段測試；單元測試、資料寫入或建置通過不能代替使用者流程驗收。

## 開發位置

學習庫：apps/server 負責 HTTP／WS，crates/ui 負責畫面，chat\_domain／chat\_application 負責規則與 Port，crates/persistence 負責 SQLite／migration；資料庫差異留在 Adapter。

先讀目前 Day 的「學習大綱」確認前置能力，再按第 2 節套用與 Refactor，最後照第 4 節從真實入口驗證。已實作的舊篇用來追溯，不照順序把所有舊程式再貼一次。

[產品操作設定](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/DEPLOYMENT.md) · [產品未來清單](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/FUTURE_WORK.md)；兩者是 copilot\_use 產品文件，執行學習庫時仍以該庫目前 Cargo／README 為準。

<details>
<summary>封存教學索引</summary>
	<page url="https://app.notion.com/p/400e51d450938155a6a1c5dee070f1b8">
	2026-10-21｜Chat Day 25｜聊天室頁登入 Session Gate（未套用）【已封存・不可再編修】
	</page>
	
	<page url="https://app.notion.com/p/3ffe51d4509381ee9326ce6cc7f1c8a1">
	2026-10-21｜Chat Day 24｜註冊完成頁保持登出【已封存】
	</page>
	
	<page url="https://app.notion.com/p/3ffe51d4509381cf8532fb767afc33ab">
	2026-10-20｜P0 Chat Day 23｜帳密登入與持久 SQLite Session【已封存】
	</page>
	
	<page url="https://app.notion.com/p/3fee51d45093814385cdcdc9e693789a">
	2026-10-20｜P0 Chat Day 22｜會員註冊表單與 SQLite【已封存】
	</page>
	
	<page url="https://app.notion.com/p/3fee51d450938168aaa0c11d9ad7d827">
	2026-10-19｜P0 Chat Day 21｜登入頁可達但不偽裝已登入
	</page>
	
	<page url="https://app.notion.com/p/3fee51d4509381d1a1e6eb5e5a1c996e">
	2026-10-19｜P0 Chat Day 20｜重新整理後顯示完整房間快照
	</page>
	
	<page url="https://app.notion.com/p/3fde51d4509381d2aac7ea4b356c213b">
	2026-10-19｜P0 Chat Day 19｜重新整理失敗保留房間列表
	</page>
	
	<page url="https://app.notion.com/p/3fde51d45093816bb36dd9099190d907">
	2026-10-18｜P0 Chat Day 18｜查詢房間完成 HTTP 接線與錯誤恢復
	</page>
	
	<page url="https://app.notion.com/p/3fce51d45093818b913bebb8dab5ab65">
	2026-10-18｜P0 Chat Day 17｜查詢房間接通 HTTP
	</page>
	
	<page url="https://app.notion.com/p/3fce51d450938143a0b9cc9a3f93860e">
	2026-10-17｜P0 Chat Day 16｜清楚選房與聊天
	</page>
	
	<page url="https://app.notion.com/p/3fbe51d450938130a3c0c93171105f3a">
	2026-10-17｜P0 Chat Day 15｜首頁房間列表與選房流程
	</page>
	
	<page url="https://app.notion.com/p/3fbe51d450938149af5dd68abc6109bd">
	2026-10-16｜P0 Chat Day 14｜以 HTTP 讀回 SQLite 房間資料
	</page>
	
	<page url="https://app.notion.com/p/3fae51d4509381e499e5e02cfba58336">
	2026-10-16｜P0 Chat Day 13｜HTTP 建房名稱驗證與 201 Created
	</page>
	
	<page url="https://app.notion.com/p/3fae51d45093812bbf88c3e7f51d6522">
	2026-10-15｜P0 Chat Day 12｜WebSocket 房間 Typing 即時通知
	</page>
	
	<page url="https://app.notion.com/p/3f9e51d4509381508c0dd3ca22cf5df7">
	2026-10-15｜P0 Chat Day 11｜WebSocket 寫入時重新核對房間
	</page>
	
	<page url="https://app.notion.com/p/3f9e51d45093818a849dd8b1fbf2c045">
	2026-10-14｜P0 Chat Day 10｜防止錯誤房間查詢結果寫入訊息
	</page>
	
	<page url="https://app.notion.com/p/3f8e51d45093814b992eea570411bd7d">
	2026-10-14｜P0 Chat Day 9｜房間不存在時禁止持久化訊息
	</page>
	
	<page url="https://app.notion.com/p/3f8e51d450938174a707d200f2e0de52">
	2026-10-13｜正式補跑｜Chat｜持久化成功後通知的對稱測試
	</page>
	
	<page url="https://app.notion.com/p/3f8e51d45093816690f8d5b4ff04ff70">
	2026-10-13｜手動補跑｜Chat｜既有 MessageRepository 的 SQLite 遷移切片
	</page>
</details>
