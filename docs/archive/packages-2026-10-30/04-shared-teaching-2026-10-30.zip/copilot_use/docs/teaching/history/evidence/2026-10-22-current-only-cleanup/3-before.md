<mention url="https://app.notion.com/p/3f2e51d4509381ddb8a8ce7cb4cd3e60">Rust AI 三專案｜共同學習規則與前進目標</mention>

本頁說明本專案的功能、操作主線、當前缺口與證據入口；每日完整程式與實作步驟放在既有 Day。現行教學方法、時程、四節格式、發布讀回、條件推進及失敗恢復，統一引用上方共同總頁「每日 TDD 教學最小必要規則 v1」（daily-tdd-minimum-v1／2026-10-18）。

Day25（含）以前文章均已封存；Analytics Day25 正文、程式碼及封存雜湊已重新讀回核對，next\_day=26。這是教學發布進度，產品套用與功能驗收分開記錄；後續差異只在下一 Day 的新實作／Refactor 後補充。實作與證據統一見共同總頁「目前進度」。

## 1. 專案大綱與操作主線

將 Chat 與 Pet 的真實動作轉成可追溯統計，供使用者查詢、篩選與管理。Analytics 提供觀察與建議，Chat／Pet 是否採用仍須各自授權。

主線：真實動作 → 來源認證 → Schema 驗證 → 去重／衝突處理 → PostgreSQL 提交 → Dashboard 查詢／篩選 → 趨勢與明細 → 管理／封存／備份。資料提交與畫面出現是不同步驟，要各有證據。

## 已逐項確認的現行需求（2026-10-17）

以下 16 組需求經使用者逐項核對；屬現行要求，未宣稱已實作或驗收。網頁／本地排程每次重新讀取並採用；與下方歷史來源觀察或封存 Day 不同時，以本節作為後續需求，歷史證據保留原 SHA 與範圍。既有需求持續有效；Day22（含）以前原文封存，後續修正在下一Day的新實作／Refactor後補充。

### Analytics：帳號、授權、稽核與來源

- 僅首次初始化建立 admin/admin；首次登入強制改密碼並設定唯一 Email，之後可修改密碼。不開放自行註冊；由系統管理者新增帳號、初始密碼與唯一 Email，新帳號首次登入須改密碼，之後可修改或以 Email 重設。密碼加鹽雜湊持久保存，重啟不重設。
- 採系統管理者及唯讀檢視者兩角色；管理者管理帳號、來源與設定，可授權檢視者查看 Chat、Pet 或兩者。
- 除登入及必要的密碼重設流程外，所有業務頁面、查詢／管理 API 與即時資料由伺服器檢查人員 Session、角色及來源範圍。帳號停用或權限縮減立即影響既有 Session 與即時連線，不等待重登。
- 帳號、權限、來源憑證及資料管理操作記錄操作者、時間、對象與結果，不保存密碼、重設連結或憑證秘密。
- Chat／Pet 各用獨立服務身分與權限，採管理者核准配對 → 短效憑證 → 自動續期／輪替 → 可撤銷。服務憑證不能代替人員後台登入。

### Chat 與 Analytics：各系統獨立的人員登入保護

- 連續登入失敗次數以各系統的帳號累計，由伺服器保存；等待自 15 秒起逐次加倍（15、30、60、120 秒……），不設上限，重新整理、換瀏覽器或 IP 不重設。失敗保留原登入導向。
- 等待期間再次送出時拒絕驗證並回傳剩餘時間；不增加次數、不重新起算倒數。登入成功清除失敗次數及等待時間。
- 管理頁修改密碼須驗目前密碼；忘記密碼則寄重設連結至登記 Email。修改或重設成功均清除失敗次數與等待時間，使該帳號所有 Session 失效，須重新登入。
- 登入後持續操作會更新活動時間，Session 持續有效；閒置逾時由各系統的管理後台設定。不能只因登入後經過固定時間而強制登出；密碼變更、停用與授權撤銷仍須生效。

## 2. 功能目標與完成條件

Analytics 定位為純管理後台，Leptos 提供後台畫面；除登入及必要的身分驗證流程外，所有業務頁面、查詢、管理與即時資料均須登入且具相應權限，不提供匿名 Dashboard。管理者 Session 與 Chat／Pet 服務憑證分開：服務上報／換證驗證機器身分，不以人員登入或來源 token 取代後台登入。

- 攝取與持久化：相同來源／事件 ID 重送不重複計數，內容衝突明確拒絕；失敗不能回成功 ACK，重啟後仍可查。
- Dashboard：選來源與事件類型、載入／空資料／錯誤／重試、數量與明細；不同來源資料與授權隔離，交易未提交不得先通知畫面。
- 通訊與資料：產品攝取目標為 gRPC／Protobuf 與逐事件 ACK，Dashboard 使用 HTTP JSON＋SSE；學習庫既有 HTTP 相容入口保留。Analytics 獨立 PostgreSQL，不讀寫 Chat／Pet 的業務 SQLite。
- 管理與洞察：封存／還原／備份、可追溯 AI 洞察、人工審核及採用／回退；再加入 Provider／Model／來源／功能的 Token 用量、成本與實際可取得額度。未知額度明示未知，不能由 Token 數推算。

## 3. 目前實作與後續接線

最新main aaa9194已修正Day24的Email欄位與SQL引號；隔離PostgreSQL加--include-ignored後31項全通過，無DB URL的預設stats-server測試20通過／1ignored，CI Test All亦success。原NotPresent環境失敗已由恢復ignore解除；若要覆蓋被略過的PG測試，須在已配置PG的環境明確執行--include-ignored。共用登入與角色／來源授權仍未完整驗收；本次歷史庫依使用者新政策改採刪除重建，不再要求保留資料升級。

來源與三案測試結果統一見共同總頁「目前進度」，不在各入口重複列歷次 SHA／測試統計。下列保留的是功能目標與驗收條件，不代表均已完成。

[下一 Day 的 Day22 更正補充草稿](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/teaching/pending/day23/analytics-day22-corrections.md)

#### Leptos Dashboard：帳密主線已接通，完整互動與角色仍待驗收

Analytics 畫面沿用 Leptos 與 Rust 元件，不以獨立手寫 HTML／JavaScript 維護另一套互動介面。先核對現有 UI crate／SSR／hydration 的責任與建置入口再接線，不為三專案檔名一致新建空骨架。

基本元件為來源選擇、事件類型篩選、查詢／重新整理、載入狀態、空資料、錯誤／重試與結果表格；由 Leptos 狀態與非同步請求呼叫現有 HTTP JSON Query API，保留來源授權與 PostgreSQL Adapter。篩選切換時清除過時結果，取消或辨識舊請求，避免晚回應覆蓋新結果。SSE 於基本查詢接通後逐步補齊。

UI 不持有 SQLx／PgPool，不另建平行 total API 或資料來源；正式管理者 Session／唯讀查詢權限與服務憑證分開，不把後端來源密鑰嵌入 WASM／HTML。來源 token 的既有學習契約保留為過渡事實，不當成正式 Dashboard 授權模型。

Day15 的 HTML／JavaScript 提案保留歷史；改採 Leptos 的完整變更與原因，在下一 Day 的 Refactor 後「舊 Day 更正補充」提出，不回填 Day15。這次只記錄方向與缺口，不新增 Day 或宣稱已接通。

驗證須分別包含 native SSR（若採用）、WASM hydration／CSR、元件狀態、HTTP／來源隔離、真實 PostgreSQL 結果與瀏覽器流程；既有 API 或 CI 成功不能代替 Leptos 畫面驗收。本輪未執行上述新增驗證。

#### 服務間交互憑證：已確認需求，未實作

服務間來源認證採「首次核准配對 → 短效憑證 → 來源端自動交互續期／輪替 → 撤銷／重新配對」；Chat／Pet 與 Analytics 互驗對方身分，不以 source\_app 自我宣告或固定 token 無限換證。Leptos 管理畫面負責配對核准、期限／輪替政策、狀態與稽核；後端及來源端執行自動換證。此為已確認需求、未實作／未驗證，完整方案於後續 Day 提出，不回改 Day15。

- 首次配對：管理者核准來源服務／實例，短效一次性配對碼須綁定核准交易與來源身分、可過期且只可成功兌換一次；配對碼只作首次信任建立，不能當永久服務憑證。
- 存取與續期：簽發限定來源、實例、接收服務與權限的短效存取憑證；來源端憑受保護的續期資格／身分證明，於到期前自動申請，成功確認後原子切換。被撤銷或已過期的存取憑證不得單獨換取新憑證。
- 通訊與保管：使用可驗證服務端身分的受保護通道；來源端持久安全保管必要續期資格，發證端對可雜湊的隨機 bearer／續期秘密僅存驗證雜湊，不存可讀明文。若採非對稱身分，私鑰由持有者安全保管，對端保存公鑰與綁定；不預定必須採 JWT 或 mTLS，協定與金鑰格式留待實作選型。
- 可靠輪替：新舊憑證僅在明確、有期限的窗口重疊；處理重試、並發、回應遺失、程序重啟及時鐘偏差，續期資格輪替與重放偵測須有交易一致性。更新 Analytics 必須與 Chat／Pet 的取得、確認和切換接通，不靠人工定期複製 token。
- 撤銷：管理者可停用來源／實例、撤銷續期資格及存取授權；定義撤銷生效上限並由服務端強制執行，失效時拒絕受保護操作，不無限延用舊憑證。來源重新配對須再次核准。
- Leptos 管理畫面：顯示來源／實例、憑證識別碼、權限、狀態、簽發／到期／輪替時間、最後成功通訊與錯誤；提供核准、立即輪替、撤銷／重新配對。完整秘密只在必要簽發交付時可見，不做日常回顯，不進 URL、日誌或統計事件；管理者 Session 與服務憑證分開。
- 驗收：未核准／錯誤對端不能配對；一次性碼過期／重放拒絕；跨來源與越權拒絕；到期前自動換證不中斷；回應遺失／重啟可恢復；舊證窗口結束失效；撤銷後不能續期；畫面狀態與實際授權一致，稽核可追溯且不含秘密。以本機合成測試服務及測試憑證驗證，不讀正式密鑰。本次均未執行。

#### 純後台登入與授權：帳密與 Session 已接通，完整管理仍待驗收

Analytics 定位為純管理後台，Leptos 提供後台畫面；除登入及必要的身分驗證流程外，所有業務頁面、查詢、管理與即時資料均須登入且具相應權限，不提供匿名 Dashboard。管理者 Session 與 Chat／Pet 服務憑證分開：服務上報／換證驗證機器身分，不以人員登入或來源 token 取代後台登入。

- 入口：未登入只可進入登入及必要驗證流程，不渲染或傳送業務資料；登入成功後只進入授權頁面。不提供公開業務首頁或匿名統計。
- 服務端強制：Leptos 畫面／SSR／server functions（若採用）、HTTP 查詢／管理 API 及 SSE 均檢查 Session 與操作權限；隱藏按鈕或前台 route guard 不能代替後端授權。未登入的 API 回 401，已登入但權限不足回 403；瀏覽器頁面導向登入，不先輸出敏感 SSR 資料。
- Session 生命週期：登入建立與更新有效工作階段；逾期、登出或管理者撤銷後不能繼續查詢／管理。SSE 在建立、重連及存續期間依授權政策處理失效，不能讓已登出的連線持續收到資料；具體撤銷生效期限在實作時明定與驗證。
- 管理操作：來源配對核准、憑證輪替／撤銷、封存／還原／備份等均須管理者權限與操作稽核；若使用 Cookie Session，狀態變更須有 CSRF 防護。不將來源服務的 ingestion／續期秘密交給後台瀏覽器當登入憑證。
- 機器通道：Chat／Pet 的 HTTP／gRPC 上報、配對兌換與自動換證使用各自服務身分及權限；不能開放匿名，也不要求每次自動上報由人員互動登入。一次性配對須有已登入管理者的核准交易。
- 驗收：直接輸入後台 URL、未登入呼叫 API／建立 SSE、跨權限操作、Session 到期／登出／撤銷、重連及狀態變更防護；確認沒有先洩漏頁面資料或以來源 token 越權登入。機器上報／換證與人員登入分別驗證。本輪僅驗證上方列出的帳密／Session／改密碼切片，其餘完整授權與機器通道條件未驗收。

此要求納入既有 Dashboard 與來源認證項；不回填 Day15，不新增 Day，不增加 next\_day。

## 4. 驗證方式與尚未驗收範圍

本輪最新main aaa9194預設stats-server測試20項通過／1ignored，配置隔離PG並加--include-ignored後31項通過。先前真CLI／HTTP保留a06c038證據及覆蓋範圍，本輪未重跑HTTP。共用登入、角色／來源授權與完整瀏覽器流程仍待處理；部分通過不等於完整產品驗收。

最新來源、命令、CI與限制統一見共同總頁「目前進度」及[main aaa9194增量驗證報告](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/teaching/evidence/2026-10-22-main-aaa9194/REPORT.md)。Day24 fixture失敗已修正並通過；Analytics Day24補教已於2026-10-22結案：既有Day25補教已發布讀回，fixture已在main修復驗證，歷史庫依使用者指定改採刪除重建；不再等待下一Day重發，不遞增next\_day。

## 5. 開發位置與使用本入口的方式

學習庫 apps/stats\_server/src/<code>lib.rs</code> 負責 HTTP 路由與來源授權，pg\_<code>store.rs</code> 負責 PostgreSQL 聚合與持久化，migrations 保留已套用歷史；產品端 shared/proto 與 analytics\_transport 提供產品通訊契約，不能視為學習庫已有同一實作。

先沿既有 API 接通粗略可操作畫面，再逐步補趨勢、明細與管理。資料安全或基本流程阻礙當步處理，其他深化留在原功能追蹤；詳細程式與驗證仍看既有 Day。

[產品通訊契約](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/ANALYTICS_TRANSPORT.md) · [操作設定](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/DEPLOYMENT.md) · [產品未來清單](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/FUTURE_WORK.md)

## 既有Day索引

<page url="https://app.notion.com/p/400e51d45093810796cbd6074c8d35c3">
2026-10-21｜Analytics Day 25｜已初始化管理員再次修改密碼與 Email（未套用）【已封存・不可再編修】
</page>

<page url="https://app.notion.com/p/3ffe51d4509381c88f26f4a90c2958fc">
2026-10-21｜Analytics Day 24｜首次改密碼與唯一Email【已封存】
</page>

<page url="https://app.notion.com/p/3ffe51d4509381f88d1be27bc5ec5f9f">
2026-10-20｜Analytics Day 23｜帳密登入與 PostgreSQL 受限 Session【已封存】
</page>

<page url="https://app.notion.com/p/3fee51d450938103b0eafc50f32822c1">
2026-10-20｜Analytics Day 22｜PostgreSQL 管理員初始化【已封存】
</page>

<page url="https://app.notion.com/p/3fee51d450938178bdb6c37fede38fd4">
2026-10-19｜P0 Analytics Day 21｜管理員帳號欄位接通登入請求
</page>

<page url="https://app.notion.com/p/3fee51d4509381618739f23dcd766996">
2026-10-19｜P0 Analytics Day 20｜登入限流回應提供剩餘等待秒數
</page>

<page url="https://app.notion.com/p/3fde51d4509381ed8a2eecf3ba7e4093">
2026-10-19｜P0 Analytics Day 19｜成功登入不消耗失敗額度
</page>

<page url="https://app.notion.com/p/3fde51d4509381c2a0d5f60041137619">
2026-10-18｜P0 Analytics Day 18｜有效活動延長伺服器 Session 並拒絕過期
</page>

<page url="https://app.notion.com/p/3fce51d4509381ea871ec9c92da37c1b">
2026-10-18｜P0 Analytics Day 17｜活動延長管理員 Session
</page>

<page url="https://app.notion.com/p/3fce51d45093813fa38ae37a47ae4959">
2026-10-17｜P0 Analytics Day 16｜登入 Leptos 後台並查詢
</page>

<page url="https://app.notion.com/p/3fbe51d4509381319460de180d9e173d">
2026-10-17｜P0 Analytics Day 15｜Dashboard 查詢與篩選接線
</page>

<page url="https://app.notion.com/p/3fbe51d4509381f2a9a2e4b608706eea">
2026-10-16｜P0 Analytics Day 14｜依事件類型篩選來源統計
</page>

<page url="https://app.notion.com/p/3fae51d4509381808a9cd813423d52d1">
2026-10-16｜P0 Analytics Day 13｜來源隔離的 PostgreSQL 統計查詢
</page>

<page url="https://app.notion.com/p/3fae51d4509381ebb1e9f8482b5bf44e">
2026-10-15｜P0 Analytics Day 12｜HTTP 來源驗證與 PostgreSQL 持久化接線
</page>

<page url="https://app.notion.com/p/3f9e51d45093814a8054d44c4ff9fa55">
2026-10-15｜P0 Analytics Day 11｜PostgreSQL 事件儲存與冪等
</page>

<page url="https://app.notion.com/p/3f9e51d4509381269984c5f49a429b5d">
2026-10-14｜P0 Analytics Day 10｜有效事件的來源與 ID 去重入口
</page>

<page url="https://app.notion.com/p/3f8e51d45093810d830ef3fd40e419f0">
2026-10-14｜P0 Analytics Day 9｜事件類型前後空白拒絕
</page>

<page url="https://app.notion.com/p/3f8e51d45093816e96edd35b83543ed3">
2026-10-13｜正式補跑｜Analytics｜來源與版本驗證測試
</page>

<page url="https://app.notion.com/p/3f8e51d4509381689c98ed86fecc50a2">
2026-10-13｜手動補跑｜Analytics｜現有 EventInput 的有效識別碼前置驗證
</page>
