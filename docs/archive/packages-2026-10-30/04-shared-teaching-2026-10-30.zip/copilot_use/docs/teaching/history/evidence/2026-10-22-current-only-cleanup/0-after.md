## 目前進度

資料核驗日：2026-10-22。最近已核驗來源：rust_ai_chat/main `aaa9194a966aefae1ef4724f5d2b576b4289c550`。以下為已確認範圍，並非即時 CI 或完整產品驗收。

<table header-row="true">
	<tr>
		<td>專案</td>
		<td>已實作</td>
		<td>待完成／補教</td>
	</tr>
	<tr>
		<td>Chat</td>
		<td>註冊、帳密登入、SQLite 持久 Session、房間頁 Session Gate</td>
		<td>共用登入／登出／Cookie／Session；API／WebSocket 房間 ACL</td>
	</tr>
	<tr>
		<td>Pet</td>
		<td>SQLite 建立／載入、逐寵物生活窗、pet-* 事件權限、單一 PetStatus 元件</td>
		<td>動畫每幀單一寵物圖像；三個不同 pet id 原生生活窗的狀態、事件、裁切與重啟驗收</td>
	</tr>
	<tr>
		<td>Analytics</td>
		<td>管理員初始化、帳密登入、持久 Session、首次與後續修改密碼／Email</td>
		<td>共用登入、角色／來源授權、服務配對換證與完整後台互動</td>
	</tr>
</table>

- Analytics Day24 補教：已結案，無須重發。
- Chat／Pet Day25 補教：各自 pending，依各專案 FIFO 處理已列缺口；已實作內容不重教。
- 三案 next_day 均為 26；Day25（含）以前正文與程式封存。教學發布、程式套用及功能驗收分開記錄。
- Analytics 本次歷史學習庫採刪除重建政策，不要求保留資料原地升級；本次未操作資料庫。

### 驗證範圍

上述來源的預設 stats-server 測試：20 通過、0 失敗、1 ignored；隔離 PostgreSQL 18.6 配置 DATABASE_URL 並加 `--include-ignored`：31 通過、0 失敗、0 ignored。CI 的 PG workflow 未加此旗標，不能視為覆蓋全部 31 項。

Chat 真瀏覽器完整流程與 API／WS 授權、Pet 三窗 GUI、Analytics 完整角色／來源授權仍須驗收；本次文章整理未重跑程式測試。copilot_use 產品整合與驗收另列。

[驗證證據](https://github.com/williechen/copilot_use/blob/teaching/rust-ai-chat-alignment/docs/teaching/evidence/2026-10-22-main-aaa9194/REPORT.md)

### 排程與通知

- 三專案每日 TDD 教學：每日 06:00，Asia/Taipei，啟用。
- 提示詞指定 `gpt-6.1-sol`、推理強度中；實際引擎選用尚未核實。
- 帳戶「任務」通知：推播與電子郵件均已開啟；實際送達未測試。

## 每日 TDD 教學最小必要規則 v1

規則版本：daily-tdd-minimum-v1。Notion 共同總頁是現行規則正本，GitHub <code>COMMON_LEARNING_RULES.md</code> 為鏡像；不以舊對話或歷史決議覆蓋本版。規則／索引衝突須揭露並核對，不能默認已同步。

### 1. 來源與選題

每次實際重讀 copilot\_use 的 <code>docs/COMMON_LEARNING_RULES.md</code>、<code>docs/learning-state.json</code>、<code>docs/P9_TARGET.md</code>、<code>docs/FUTURE_WORK.md</code>、<code>docs/SYSTEM_ARCHITECTURE.md</code>、<code>docs/UI_ALIGNMENT_REQUIREMENTS.md</code>、<code>docs/teaching/current/manifest.json</code>，以及 Notion 共同總頁、三專案入口與相關 Day。取得 rust\_ai\_chat/main 與 copilot\_use 教學分支最新完整 SHA，核對本日相關程式、實際呼叫端、測試及差異。必要來源讀取失敗，只暫停受影響專案，不能以快取冒充最新。

發布每篇前再取 main SHA 及必要規則版本；來源 SHA 改變就重建所有尚未發布草稿，規則改變則重新核對、必要時重建。已完整發布讀回的 Day 不自動撤銷。記錄規則版本、Notion page\_last\_edited\_at、GitHub 規則 blob／commit SHA、兩庫來源 SHA 及讀取時間。rust\_ai\_chat 全庫唯讀，教學程式由使用者套用；copilot\_use 產品整合與教學分開。

#### 基本可操作流程優先

每日選題必須先核對最新 <code>rust_ai_chat/main</code> 與對應 <code>copilot_use</code> 真正入口、可操作 UI、HTTP/IPC、Session/權限、SQLite/PostgreSQL 持久化和對應 CI；找出使用者操作流程中最早缺失的必要環節，先教／補最小可套用、已連至真實呼叫者的 Red→Green。不能因 API、helper、單元測試、HTTP 狀態碼、視窗動畫已存在，就跳過前面的註冊、登入或寵物建立。若早期流程尚未可用，不優先教後段的歷史訊息、漫遊細節或登入限流細節；未完成的同一功能跨日延續，依最新程式重新判斷，不預排 Day。

- <b>Chat 基本功能門檻：</b> 使用者能註冊／登入，帳號資料與 Session 合理持久化，未登入者不能進入需要授權的聊天室；登入後可看見房間清單並加入或建立房間，才能依需要開發歷史訊息、重連及進階 UI。只有首頁 <code>/signin</code> 連結，或僅能透過 <code>/room/:id</code> 開啟頁面，不等於登入與授權鏈完成；須檢查後端、前端與 SQLite 之間的實際接線。
- <b>Pet 基本功能門檻：</b> 使用者可建立第一隻具身分、名稱、初始外觀的寵物，透過 Tauri IPC 真正儲存 SQLite、顯示於生活視窗，重新啟動後能載入。<code>PetMachine::default()</code> 不等於使用者建立寵物；在建立、載入流程可用前，視窗漫遊／拖曳／找回與多寵物進階特性只列後續項目。
- <b>Analytics 基本功能門檻：</b> 建立並持久化管理員帳號，安全的加鹽密碼雜湊、首次登入強制改密碼、有效 Session 與後台頁面授權先接通，再深化角色、帳號級登入等待、報表及來源事件。

主體為各專案每天 <b>一個</b>可驗證的最小 Green 切片，功能可跨日，真正使用者流程尚未可用須在文章與進度明示缺口；以最新程式與資料庫契約優先，不強制當天一次完成註冊／登入或整套寵物建立。原 P9 產品目標、功能 Gate、歷史 Day、四節文章、Notion 正式發布及全文讀回、條件式更新 <code>next_day</code>、CI 覆蓋範圍與每日／週六各自驗收規則全部保留。

### 2. 文章最小格式

沿用四節：①學習大綱＝目標、現況、前置條件與本日差異；②實作內容＝Red → 完整最小 Green → Refactor → 必要的舊 Day 更正補充；③套件版本＝本日涉及的 Cargo／lock、stable／MSRV／native／WASM 核對，未查明示；④驗證項目＝測試、證據、待完成與下一步。

每篇只教一個最小完整切片，提供真實檔案位置、必要完整修改與繁體中文說明，交代入口到資料／畫面的呼叫鏈。Red 必須對應同篇 Green，預期行為失敗、缺少待新增符號的預期編譯失敗、匯入／環境錯誤分別標示；已通過的既有測試不能冒稱 Red。不能以未確認的建窗標籤或介面假設冒稱完整可套用 Green；必要契約未核實先補齊，否則只存草稿。

大功能可跨日；原切片未完成如實保留，不把 API、欄位或純補測當完整新功能。已實作 Day 封存，未實作部分可在原頁修訂；狀態不明先列未核實。重大錯誤由人工逐案裁定影響範圍及是否版本化重發，保留原文與版本；更正不自動新增 Day 或倒退進度。

#### 封存與補教

三案 Day25（含）以前正文、程式與證據不回寫；封存不代表產品驗收。每次先核對最新來源、真實呼叫鏈、CI 與涉及套件的 manifest／lock／官方穩定版本，再將必要更正放在下一個適用原教學第2節的新 Red／完整 Green／Refactor 之後，另列「舊 Day 更正補充」。提供真實路徑、必要完整修改、版本理由及驗證範圍。

各專案 makeup_queue 採 FIFO、每篇最多一個舊 Day 單元；新差異去重入列，完整發布讀回才結案，不因補教、文件整理或驗證增加 Day。最新依賴不直接等於適合升級，不自動修改來源 lock。

登入、登出、Cookie 與 Session 採共用實作，各系統透過儲存介面及政策接入；SQLite／PostgreSQL 與登入狀態保持獨立。Pet 每窗單一元件、動畫每幀單一寵物圖像及至少三個不同 pet id 的生活窗各自驗證。Analytics 須驗完整 postgres-integration targets 與全新建庫流程。

### 3. 測試與證據

CI 必須核對並揭露精確 SHA、workflow／job、狀態、時間與連結；Success／Failure／Pending／Skipped／Cancelled／無紀錄均不單獨阻擋教學發布或 next\_day。CI Success 只證明實際執行的範圍，不能代替 DB、HTTP／WS、SSR／WASM、GUI 或端到端驗收；copilot\_use CI 僅是產品證據。

每項列命令、預期、實際結果、證據 SHA、覆蓋範圍、未執行／失敗／待修。未執行明示，不捏造 Red／Green 成功；教學發布、使用者套用、產品整合、功能驗收分別記錄。跨 SHA 引用證據須核對相關差異及依賴，不能直接沿用成功結論。寫入／補償成功不等於測試成功，驗證範圍縮小須列剩餘缺口。

### 4. Notion 發布與 Day 推進

按專案＋Day＋修訂版查現有頁與索引，重用既有頁，不重複建同一教學。先完整發布 Notion，再讀回全文，核對四節、Red／完整 Green、程式碼、來源版本與索引；部分失敗保留失敗紀錄，重建同一文章的完整內容，成功讀回前不得推進。

每專案獨立處理：原教學 Day N 完整發布且讀回成功，才可將該專案 next\_day 從預期 N 更新為 N+1。更新前重新讀取 learning-state 及 blob／branch SHA，依 Notion 證據於單次條件提交更新進度及既有 makeup\_queue，保留其他欄位，寫後讀回；manifest 同步目前索引。若現值已為 N+1 且證據一致，視為已補更新，不再遞增。併發衝突重新讀取，不能安全合併就暫停該狀態更新。

文章修訂、規則同步、補教、CI 成功與週六比對都不自行推進 next\_day。原教學與補教分開；已存在的 makeup\_queue 採 FIFO，每篇最多一個舊 Day 補教單元，完整讀回才結案，不因補教失敗回退已確認的原教學進度。未完成原教學不冒充已發布；隔日新內容須標明原教學與待補內容，不能跳號掩蓋失敗。

### 5. 最小失敗恢復

Notion 已完整讀回但 GitHub 狀態寫入／讀回失敗，保留頁面 ID、專案／Day／修訂、來源版本、預期狀態及錯誤，下次先讀 Notion 與 GitHub，只補缺少的狀態，不重發、不重複加 Day。狀態不明只暫停受影響專案，其他來源完整者繼續。

證據檔保存失敗另記 pending 與錯誤；原教學已完整讀回時可依上節推進，不能聲稱證據已保存或測試已驗證。重試前先讀取去重，沿用同一筆待辦；同項連續三次失敗轉 needs\_manual\_review、停止相同自動寫入，人工重新啟用才恢復，保留歷史。若失敗紀錄也無法持久保存，回報明示。只保留必要失敗紀錄，不新增多層補償／cycle／復發風險系統。

### 6. 時程與邊界

每日 06:00 Asia/Taipei，依 Chat → Pet → Analytics；主體 Red／最小 Green 學習合計最多 60 分鐘，各預留 15 分鐘，加共用彈性 15 分鐘。保留既有主體學習計時口徑：Refactor、必要補加／補教及第1、3、4節另列估時，不隱藏成本，也不為填滿時間擴大切片。超出主體預算的內容留待後續，不以缺少 Green 的文章冒稱完成；執行遇到時間上限先保存可恢復進度。

週六 00:00 Asia/Taipei 獨立完整比對 tracked 程式、介面、呼叫流程、契約、DB／migration、UI、設定、測試、CI 與文件；只有完整成功才更新 last\_full\_comparison 並讀回。每日做增量核對，不覆蓋完整比對時間。週六失敗不自動阻擋每日教學，須揭露並重新讀取必要來源。既有排程原地更新，不建立重複任務；指令保存不等於排程已更新或實際執行成功。

保留原生環境、Domain／Application 與 Adapter 邊界、不同 DB 分別驗證、既有 migration／固定 tag／證據不可改寫、權限與檔案操作確認。不得讀正式秘密或執行付費 AI；週六功能驗收不冒稱 AI 已重測。P9 產品目標、P0–P12 學習階段及實際驗收分開。

## 專案入口

<page url="https://app.notion.com/p/3f3e51d45093807da638c336e857543a">
聊天室
</page>

<page url="https://app.notion.com/p/3f3e51d45093817eafaee0cfc9ea4cc8">
統計儀錶板｜聊天室 × 桌面寵物
</page>

<page url="https://app.notion.com/p/3f3e51d450938067923ae5a424d30950">
桌面寵物
</page>

<details>
<summary>封存資料入口</summary>
	<page url="https://app.notion.com/p/3f7e51d4509381faa894d3660c3252f7">
	文件與教學封存（非現行規則）
	</page>
</details>
