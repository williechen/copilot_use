import ctypes

def press_keys(display_name,keysyms):
 x=ctypes.CDLL('libX11.so.6');xt=ctypes.CDLL('libXtst.so.6')
 x.XOpenDisplay.argtypes=[ctypes.c_char_p];x.XOpenDisplay.restype=ctypes.c_void_p;x.XKeysymToKeycode.argtypes=[ctypes.c_void_p,ctypes.c_ulong];x.XKeysymToKeycode.restype=ctypes.c_ubyte;x.XFlush.argtypes=[ctypes.c_void_p];x.XCloseDisplay.argtypes=[ctypes.c_void_p]
 xt.XTestFakeKeyEvent.argtypes=[ctypes.c_void_p,ctypes.c_uint,ctypes.c_int,ctypes.c_ulong]
 d=x.XOpenDisplay(display_name.encode());assert d
 for sym in keysyms:
  key=x.XKeysymToKeycode(d,sym);assert key
  xt.XTestFakeKeyEvent(d,key,True,0);xt.XTestFakeKeyEvent(d,key,False,0)
 x.XFlush(d);x.XCloseDisplay(d)
