import pathlib,shutil,json,subprocess,datetime
b=pathlib.Path.cwd();src=pathlib.Path('/home/willie/Documents/rust_ai_chat');out=b/'outputs/verification-2026-10-24';tracked=set(subprocess.check_output(['git','ls-files'],cwd=src,text=True).splitlines())
paths=[b/'work'/n for n in ['rust_ai_chat','pg-data','pg-socket','pet-upgrade.sqlite','chat-runtime.sqlite','gui-runtime','gui-runtime-2','gui-runtime-3','gui-runtime-4','gui-runtime-5','upgrade-probe','publish','initial-cache-unavailable','pre-update-interrupted','pg.log']]
paths += [src/'target',src/'apps/desktop_pet/frontend/dist',src/'apps/desktop_pet/gen',pathlib.Path('/home/willie/.local/share/dev.rustai.desktop-pet')]
for p in src.rglob('*'):
 if '.git' in p.parts:continue
 if p.is_file() and (p.name.endswith(('.swp','.swo','.bak','.tmp','~')) or p.name.startswith('.#')) and str(p.relative_to(src)) not in tracked:paths.append(p)
rows=[]
for p in paths:
 if not p.exists() and not p.is_symlink():continue
 if src in p.parents and any(str(p.relative_to(src))==f or f.startswith(str(p.relative_to(src))+'/') for f in tracked):raise RuntimeError('Refuse tracked deletion '+str(p))
 if p.is_dir() and not p.is_symlink():size=sum(f.stat().st_size for f in p.rglob('*') if f.is_file() and not f.is_symlink());shutil.rmtree(p)
 else:size=p.lstat().st_size;p.unlink()
 rows.append({'path':str(p),'removed_bytes':size})
x={'date':datetime.datetime.now().isoformat(),'user_authorized_application_db_reset':True,'application_db_targets_found':[],'system_pg_databases_preserved':['postgres','willie'],'removed':rows,'historical_outputs_preserved':True,'source_status_after':subprocess.check_output(['git','status','--porcelain'],cwd=src,text=True)}
(out/'reset-cleanup.json').write_text(json.dumps(x,ensure_ascii=False,indent=2));print('Removed',len(rows),'paths;',round(sum(r['removed_bytes'] for r in rows)/1024**3,2),'GiB logical bytes')
