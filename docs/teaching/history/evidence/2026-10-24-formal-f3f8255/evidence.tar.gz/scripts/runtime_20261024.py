import pathlib,subprocess,os,json,time,socket,urllib.request,urllib.error,urllib.parse,sqlite3,hashlib,uuid
base=pathlib.Path.cwd(); repo=base/'work/rust_ai_chat'; out=base/'outputs/verification-2026-10-24'; results=[]
env={k:v for k,v in os.environ.items() if not any(x in k.upper() for x in ['TOKEN','SECRET','PASSWORD','API_KEY','DATABASE_URL'])}
env.update(CHAT_DATABASE_URL='sqlite://'+str(base/'work/chat-runtime.sqlite')+'?mode=rwc',LEPTOS_OUTPUT_NAME='rust_ai_chat',LEPTOS_SITE_ROOT=str(repo/'target/site'),LEPTOS_SITE_PKG_DIR='pkg',LEPTOS_SITE_ADDR='127.0.0.1:3000')
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**kw): return None
opener=urllib.request.build_opener(NoRedirect)
def req(path,expected=200,data=None,cookie=None,headers=None):
 h=headers or {}
 if cookie:h['Cookie']=cookie
 if data is not None:
  h['Origin']='http://127.0.0.1:3000'
  if isinstance(data,dict): data=urllib.parse.urlencode(data).encode(); h.setdefault('Content-Type','application/x-www-form-urlencoded')
 q=urllib.request.Request('http://127.0.0.1:3000'+path,data=data,headers=h)
 try:r=opener.open(q,timeout=10)
 except urllib.error.HTTPError as e:r=e
 body=r.read().decode();results.append({'path':path,'expected':expected,'actual':r.code,'passed':r.code==expected});return r,body
def start():
 log=(out/'logs/runtime-chat.log').open('a'); p=subprocess.Popen([str(repo/'target/release/server')],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 for _ in range(200):
  try:
   with socket.create_connection(('127.0.0.1',3000),timeout=.1):return p,log
  except OSError:time.sleep(.1)
  if p.poll() is not None: break
 raise RuntimeError('server not ready')
def stop(p,log):
 p.terminate()
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:p.kill();p.wait()
 log.close()
with socket.socket() as s:
 if s.connect_ex(('127.0.0.1',3000))==0:raise RuntimeError('port 3000 occupied')
p=None
try:
 p,log=start()
 req('/health'); req('/');req('/api/rooms');req('/account',401);req('/room/unauthed',401);req('/ws/unauthed',401)
 req('/api/rooms',401,b'{"name":"unauthorized"}',headers={'Content-Type':'application/json'})
 form={'username':'formaltest','email':'formal@example.test','display_name':'正式測試','password':'fixture-password-only'}
 r,_=req('/signup',303,form); assert r.headers['Location']=='/signup/complete'
 req('/signup',409,form)
 req('/login',401,{'username':'formaltest','password':'wrong'})
 r,_=req('/login',303,{'username':'FORMALTEST','password':'fixture-password-only'}); cookie=r.headers['Set-Cookie'].split(';')[0]
 _,account=req('/account',cookie=cookie)
 csrf=hashlib.sha256(('create-room:'+cookie.split('=')[1]).encode()).hexdigest()
 req('/account/rooms',403,{'name':'bad-csrf','csrf':'invalid'},cookie)
 r,created_page=req('/account/rooms',201,{'name':'個人頁表單建房','csrf':csrf},cookie)
 results.append({'name':'account form creates room with entry link','passed':'進入剛建立的房間' in created_page})
 r,body=req('/api/rooms',201,json.dumps({'name':'正式驗證房間','csrf':csrf}).encode(),cookie,{'Content-Type':'application/json'})
 if r.code==201:
  room=json.loads(body)['id'];req('/room/'+room,cookie=cookie);req('/api/rooms/'+room,cookie=cookie)
  stop(p,log);p=None;p,log=start();req('/account',cookie=cookie);req('/api/rooms/'+room,cookie=cookie)
 csrf=hashlib.sha256(('logout:'+cookie.split('=')[1]).encode()).hexdigest()
 req('/logout',303,{'csrf':csrf},cookie);req('/account',401,cookie=cookie)
 with sqlite3.connect('file:'+str(base/'work/chat-runtime.sqlite')+'?mode=ro',uri=True) as db:
  results.append({'name':'SQLite integrity','passed':db.execute('pragma integrity_check').fetchone()[0]=='ok'})
  results.append({'name':'signup persists','passed':db.execute('select count(*) from mbr_user').fetchone()[0]==1})
except Exception as e:results.append({'name':'runtime suite','passed':False,'error':str(e)})
finally:
 if p:stop(p,log)
 (out/'runtime.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(json.dumps(results,ensure_ascii=False,indent=2))
