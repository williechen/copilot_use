import pathlib,tomllib,urllib.request,json,concurrent.futures,re
lock=tomllib.loads(pathlib.Path('work/rust_ai_chat/Cargo.lock').read_text())['package'];names=['axum','sqlx','tauri','tauri-build','leptos','leptos_router','leptos_axum','argon2','tower','uuid']
def get(n):
 u=f'https://crates.io/api/v1/crates/{n}';d=json.load(urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Day30-verification'}),timeout=30));vs=[v for v in d['versions'] if not v['yanked'] and not re.search('[-+]',v['num'])];v=max(vs,key=lambda v:tuple(map(int,v['num'].split('.'))));return dict(name=n,resolved=[x['version'] for x in lock if x['name']==n],latest_stable=v['num'],msrv=v.get('rust_version'),source=u)
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:r=list(ex.map(get,names))
pathlib.Path('work/logs/versions.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
