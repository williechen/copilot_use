import pathlib,json,time,subprocess,os
root=pathlib.Path.cwd();logs=root/'work/logs'
while len(json.loads((logs/'results.json').read_text()))<5:time.sleep(2)
env={**os.environ,'CARGO_TARGET_DIR':str(root/'work/target-day30'),'CARGO_BUILD_JOBS':'2','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_INCREMENTAL':'0','DATABASE_URL':'postgres://willie@127.0.0.1:55440/day30'}
commands=[('pg-all',['cargo','test','--locked','--offline','-p','stats-server','--features','postgres-integration','--no-fail-fast','--','--include-ignored']),('ui-ssr',['cargo','test','--locked','--offline','-p','ui','--features','ssr','--no-fail-fast'])]
r=[]
for name,c in commands:
 with (logs/(name+'.log')).open('w') as f:p=subprocess.run(c,cwd=root/'work/rust_ai_chat',env=env,stdout=f,stderr=subprocess.STDOUT)
 r.append(dict(name=name,command=c,exit=p.returncode));(logs/'additional-results.json').write_text(json.dumps(r,indent=2));print(r[-1],flush=True)
p=subprocess.run(['python3','work/http_day30.py'],cwd=root,stdout=(logs/'http-run.log').open('w'),stderr=subprocess.STDOUT);print('HTTP runner exit',p.returncode,flush=True);(logs/'http-run.exit').write_text(str(p.returncode))
