import pathlib,subprocess,os,time,requests,json,sqlite3,socket,re,pty,select,uuid
root=pathlib.Path.cwd();src=root/'work/rust_ai_chat';bins=root/'work/target-day30/debug';logs=root/'work/logs';rows=[];procs=[]
def rec(name,actual,expected):
 rows.append(dict(name=name,actual=actual,expected=expected,passed=actual==expected));(logs/'http-results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
def start(name,env,port):
 f=(logs/(name+'-http.log')).open('a');p=subprocess.Popen([str(bins/name)],cwd=src,env={**os.environ,**env},stdout=f,stderr=f);procs.append(p)
 for _ in range(100):
  try:
   with socket.create_connection(('127.0.0.1',port),timeout=.2):return p
  except OSError:time.sleep(.1)
 raise RuntimeError(name+' did not start')
def req(port,path,method='GET',data=None,cookie=None,json_body=None,token=None):
 h={'Origin':f'http://127.0.0.1:{port}'}
 if cookie:h['Cookie']=cookie
 if token:h['Authorization']='Bearer '+token
 return requests.request(method,f'http://127.0.0.1:{port}{path}',data=data,json=json_body,headers=h,allow_redirects=False,timeout=10)
def create(cookie=None):return req(3000,'/api/rooms','POST',cookie=cookie,json_body={'name':'Day30 fixture'})
def bootstrap():
 pid,fd=pty.fork()
 if pid==0:
  os.chdir(src);os.environ['ANALYTICS_DATABASE_URL']='postgres://willie@127.0.0.1:55440/day30';os.execv(str(bins/'bootstrap_admin'),[str(bins/'bootstrap_admin')])
 text=b'';sent=0
 while True:
  ready,_,_=select.select([fd],[],[],15)
  if not ready:raise RuntimeError('bootstrap prompt timeout')
  try:b=os.read(fd,4096)
  except OSError:break
  if not b:break
  text+=b
  if '：'.encode() in b and sent<2:os.write(fd,b'day30-fixture-password\n');sent+=1
 _,status=os.waitpid(pid,0);os.close(fd);(logs/'bootstrap-pty.log').write_bytes(text);rec('bootstrap CLI',os.waitstatus_to_exitcode(status),0)
try:
 db=root/'work/day30-chat.sqlite';db.touch();env={'CHAT_DATABASE_URL':f'sqlite://{db}','LEPTOS_OUTPUT_NAME':'rust_ai_chat','LEPTOS_SITE_ROOT':str(root/'work/site'),'LEPTOS_SITE_PKG_DIR':'pkg'}
 chat=start('server',env,3000)
 rec('Chat public GET',req(3000,'/api/rooms').status_code,200);rec('Chat anonymous POST',create().status_code,401);rec('Chat forged POST',create('chat_session='+'f'*64).status_code,401)
 c=sqlite3.connect(db);rec('Chat rejected POST leaves no rooms',c.execute('select count(*) from rooms').fetchone()[0],0)
 rec('Chat signup',req(3000,'/signup','POST',dict(username='day30user',email='day30@example.test',display_name='Day30',password='day30-fixture-password')).status_code,303)
 r=req(3000,'/login','POST',dict(username='day30user',password='day30-fixture-password'));rec('Chat login',r.status_code,303);ck=r.headers['Set-Cookie'].split(';')[0]
 r=create(ck);rec('Chat ordinary member creates',r.status_code,201);room=r.json()['id'];rec('Chat room persisted',c.execute('select count(*) from rooms where id=?',(room,)).fetchone()[0],1)
 c.execute('update mbr_session set expires_at=unixepoch()-1');c.commit();rec('Chat expired Session POST',create(ck).status_code,401)
 c.execute('update mbr_session set expires_at=unixepoch()+3600');c.commit();chat.terminate();chat.wait();chat=start('server',env,3000)
 rec('Chat restart public list',any(x['id']==room for x in req(3000,'/api/rooms').json()),True);rec('Chat restart valid Session POST',create(ck).status_code,201)
 page=req(3000,'/account',cookie=ck);csrf=re.search('name="csrf" value="([^"]+)"',page.text).group(1);rec('Chat logout',req(3000,'/logout','POST',dict(csrf=csrf),ck).status_code,303);rec('Chat revoked Session POST',create(ck).status_code,401);rec('Chat GET stays public',req(3000,'/api/rooms').status_code,200);c.close()
 stats=start('stats-server',{'ANALYTICS_DATABASE_URL':'postgres://willie@127.0.0.1:55440/day30','ANALYTICS_CHAT_TOKEN':'day30-chat-token','ANALYTICS_PET_TOKEN':'day30-pet-token'},3100);bootstrap()
 page=req(3100,'/login');rec('Analytics login HTTP',page.status_code,200);rec('Analytics one doctype',page.text.lower().count('<!doctype html>'),1);rec('Analytics accessible password field',all(v in page.text for v in ['for="analytics-password"','id="analytics-password"','action="/login"','autocomplete="current-password"']),True)
 rec('Analytics anonymous dashboard',req(3100,'/dashboard').headers.get('Location'),'/login');r=req(3100,'/login','POST',dict(username='admin',password='day30-fixture-password'));rec('Analytics first login',r.status_code,303);ck=r.headers['Set-Cookie'].split(';')[0];rec('Analytics forced password change',req(3100,'/dashboard',cookie=ck).headers.get('Location'),'/change-password')
 page=req(3100,'/change-password',cookie=ck);csrf=re.search('name="csrf" value="([^"]+)"',page.text).group(1)
 rec('Analytics password change',req(3100,'/change-password','POST',dict(current_password='day30-fixture-password',new_password='day30-changed-password',confirm_password='day30-changed-password',email='day30-admin@example.test',csrf=csrf),ck).status_code,303)
 rec('Analytics revoked prior session',req(3100,'/api/v1/events/web_chat/summary',cookie=ck).status_code,401)
 r=req(3100,'/login','POST',dict(username='admin',password='day30-changed-password'));ck=r.headers['Set-Cookie'].split(';')[0]
 for source,token in [('web_chat','day30-chat-token'),('desktop_pet','day30-pet-token')]:
  e=dict(schema_version=1,event_id=str(uuid.uuid4()),source_app=source,event_type='day30.fixture');rec('Analytics '+source+' ingest',req(3100,'/api/v1/events','POST',json_body=e,token=token).status_code,201)
 for source,label in [('web_chat','Chat'),('desktop_pet','Pet')]:
  page=req(3100,'/dashboard?source='+source,cookie=ck);rec('Analytics '+source+' dashboard',page.status_code,200);rec('Analytics '+source+' real count',label+' 已提交事件總數 1' in page.text,True);rec('Analytics '+source+' active marker',page.text.count('aria-current="page"'),1)
 rec('Analytics unknown source',req(3100,'/dashboard?source=unknown',cookie=ck).status_code,400)
finally:
 for p in procs:
  if p.poll() is None:p.terminate()
 for p in procs:
  if p.poll() is None:p.wait(timeout=5)
print(json.dumps(rows,ensure_ascii=False,indent=2))
