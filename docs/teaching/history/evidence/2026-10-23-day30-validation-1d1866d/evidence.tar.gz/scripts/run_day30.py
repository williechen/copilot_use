import subprocess,pathlib,json,os,time
root=pathlib.Path.cwd();src=root/'work/rust_ai_chat';logs=root/'work/logs'
env={**os.environ,'CARGO_TARGET_DIR':str(root/'work/target-day30'),'CARGO_BUILD_JOBS':'2','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_INCREMENTAL':'0'}
cmds=[['node','--test'],['cargo','test','--locked','--offline','-p','server','-p','desktop-pet','-p','stats-server','--no-fail-fast'],['cargo','check','--locked','--offline','-p','ui','--features','hydrate','--target','wasm32-unknown-unknown'],['cargo','check','--locked','--offline','-p','desktop-pet-frontend','--target','wasm32-unknown-unknown'],['cargo','build','--locked','--offline','-p','server','--features','ssr','-p','stats-server']]
r=[]
for i,c in enumerate(cmds):
 t=time.time()
 with (logs/f'day30-{i}.log').open('w') as f:p=subprocess.run(c,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT)
 r.append(dict(command=c,exit=p.returncode,seconds=round(time.time()-t,2),log=f'day30-{i}.log'));(logs/'results.json').write_text(json.dumps(r,indent=2));print(r[-1],flush=True)
