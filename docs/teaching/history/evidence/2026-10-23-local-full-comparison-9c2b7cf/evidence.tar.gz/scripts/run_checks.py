import subprocess,pathlib,json,os,time
root=pathlib.Path.cwd(); logs=root/'work/logs';logs.mkdir(exist_ok=True)
target='/home/willie/Documents/Codex/2026-10-23/referenced-chatgpt-conversation-this-is-an-2/work/target-full'
cmds=[['node','--test'],['cargo','test','--locked','--offline','-p','server','-p','ui','-p','chat-application','-p','chat-domain','-p','persistence','-p','shared','-p','ai-core','-p','pet-domain','--features','server/ssr,ui/ssr','--no-fail-fast'],['cargo','test','--locked','--offline','-p','desktop-pet','--no-fail-fast'],['cargo','check','--locked','--offline','-p','ui','--features','hydrate','--target','wasm32-unknown-unknown'],['cargo','check','--locked','--offline','-p','desktop-pet-frontend','--target','wasm32-unknown-unknown']]
results=[]
for i,cmd in enumerate(cmds):
 start=time.time()
 with (logs/f'check-{i}.log').open('w') as f:
  p=subprocess.run(cmd,cwd=root/'work/rust_ai_chat',stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'CARGO_TARGET_DIR':target,'CARGO_BUILD_JOBS':'2'})
 results.append(dict(command=cmd,exit=p.returncode,seconds=round(time.time()-start,2),log=f'check-{i}.log'))
 (logs/'results.json').write_text(json.dumps(results,indent=2));print(results[-1],flush=True)
