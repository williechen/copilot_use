import pathlib,subprocess,os,time,requests,json,sqlite3,socket,base64,struct,re,pty,select
root=pathlib.Path.cwd();src=root/'work/rust_ai_chat';logs=root/'work/logs';bins=pathlib.Path('/home/willie/Documents/Codex/2026-10-23/referenced-chatgpt-conversation-this-is-an-2/work/target-full/debug');out=[];procs=[]
def rec(name,actual,expected=None):
 out.append(dict(name=name,actual=actual,expected=expected));(logs/'analytics-runtime.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
def start(bin,env,port):
 f=(logs/(bin+'-runtime.log')).open('w');p=subprocess.Popen([str(bins/bin)],cwd=src,env={**os.environ,**env},stdout=f,stderr=f);procs.append(p)
 for _ in range(100):
  try:
   with socket.create_connection(('127.0.0.1',port),timeout=.2):return p
  except OSError:time.sleep(.1)
 raise RuntimeError(f'{bin} did not start')
def req(port,path,method='GET',data=None,cookie=None):
 h={'Origin':f'http://127.0.0.1:{port}'}
 if cookie:h['Cookie']=cookie
 return requests.request(method,f'http://127.0.0.1:{port}{path}',data=data,headers=h,allow_redirects=False,timeout=10)
def ws(room,cookie=None):
 s=socket.create_connection(('127.0.0.1',3000));s.settimeout(3);key=base64.b64encode(os.urandom(16)).decode();h=f'GET /ws/{room} HTTP/1.1\r\nHost: 127.0.0.1:3000\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: {key}\r\nOrigin: http://127.0.0.1:3000\r\n'
 if cookie:h+=f'Cookie: {cookie}\r\n'
 s.sendall((h+'\r\n').encode());data=s.recv(4096);return s,int(data.split(b' ')[1])
def frame(s,value):
 b=json.dumps(value).encode();mask=os.urandom(4);head=bytes([129,128|len(b)]) if len(b)<126 else bytes([129,254])+struct.pack('!H',len(b));s.sendall(head+mask+bytes(x^mask[i%4] for i,x in enumerate(b)))
 h=s.recv(2);n=h[1]&127
 if n==126:n=struct.unpack('!H',s.recv(2))[0]
 return json.loads(s.recv(n))
try:
 start('stats-server',{'ANALYTICS_DATABASE_URL':'postgres://willie@127.0.0.1:55439/audit','ANALYTICS_CHAT_TOKEN':'fixture-chat-only','ANALYTICS_PET_TOKEN':'fixture-pet-only'},3100)
 rec('Analytics anonymous dashboard',req(3100,'/dashboard').status_code,303)
 rec('Analytics kind summary route',req(3100,'/api/v1/events/web_chat/summary/chat.message.persisted').status_code,'protected route expected; currently 404')
 rec('Analytics login doctype count',req(3100,'/login').text.lower().count('<!doctype html>'),1)
 r=req(3100,'/login','POST',dict(username='admin',password='fixture-only-password'));rec('Analytics password login',r.status_code,303)
 if 'Set-Cookie' in r.headers:
  ck=r.headers['Set-Cookie'].split(';')[0];rec('Analytics restricted redirect',req(3100,'/dashboard',cookie=ck).headers.get('Location'),'/change-password')
  html=req(3100,'/change-password',cookie=ck).text;csrf=re.search('name="csrf" value="([^"]+)"',html).group(1)
  rec('Analytics first password change',req(3100,'/change-password','POST',dict(current_password='fixture-only-password',new_password='fixture-changed-password',confirm_password='fixture-changed-password',email='audit-admin@example.test',csrf=csrf),ck).status_code,303)
  r=req(3100,'/login','POST',dict(username='admin',password='fixture-changed-password'));ck=r.headers['Set-Cookie'].split(';')[0];rec('Analytics authenticated dashboard',req(3100,'/dashboard?source=desktop_pet',cookie=ck).status_code,200)
finally:
 for p in procs:p.terminate()
 for p in procs:p.wait(timeout=5)
print(json.dumps(out,ensure_ascii=False,indent=2))
