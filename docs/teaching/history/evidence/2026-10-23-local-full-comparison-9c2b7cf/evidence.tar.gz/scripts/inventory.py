from pathlib import Path
import subprocess,json,hashlib,csv,tomllib,collections,re
out=Path('work/logs')
for repo in ['rust_ai_chat','copilot_use']:
 root=Path('work')/repo;files=subprocess.check_output(['git','-c','core.quotepath=false','-C',str(root),'ls-files','-s'],text=True).splitlines();rows=[]
 for l in files:
  meta,p=l.split('\t',1);mode,blob,stage=meta.split();data=(root/p).read_bytes();calc=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  rows.append(dict(path=p,blob=blob,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),matches_git=calc==blob))
 (out/(repo+'-inventory.json')).write_text(json.dumps(rows,indent=2));print(repo,len(rows),'all byte match',all(r['matches_git'] for r in rows))
root=Path('work/rust_ai_chat');lock=tomllib.loads((root/'Cargo.lock').read_text());(out/'lock-packages.json').write_text(json.dumps(lock['package'],indent=2));print('lock packages',len(lock['package']))
migrations=[]
for p in sorted(root.rglob('*.sql')):
 rel=str(p.relative_to(root));history=subprocess.check_output(['git','-C',str(root),'log','--format=%H','--',rel],text=True).splitlines();old=history[-1];data=subprocess.check_output(['git','-C',str(root),'show',old+':'+rel]);migrations.append(dict(path=rel,first_commit=old,first_sha384=hashlib.sha384(data).hexdigest(),current_sha384=hashlib.sha384(p.read_bytes()).hexdigest(),modified_since_first=data!=p.read_bytes()))
(out/'migration-history.json').write_text(json.dumps(migrations,indent=2));print('migrations',len(migrations),'modified since first',sum(r['modified_since_first'] for r in migrations))
# Canonical history + current lessons: verify all bytes, parse fenced source pointers, distinguish existence from implementation.
docs=Path('work/copilot_use');index=json.loads((docs/'docs/teaching/history/ARTICLES.json').read_text());articles=[]
paths={x['article'] for x in index['lessons']};paths.update(str(p.relative_to(docs)) for folder in ['daily','archived'] for p in (docs/('docs/teaching/'+folder)).rglob('*.md') if p.name in ['chat.md','pet.md','analytics.md'])
for path in sorted(paths):
 p=docs/path;s=p.read_text();refs=sorted(set(re.findall(r'(?:apps|crates)/[A-Za-z0-9_./-]+\.(?:rs|toml|html|json|sql)',s)))
 articles.append(dict(path=path,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),lines=len(s.splitlines()),source_paths=[dict(path=r,exists_in_program=(root/r).exists()) for r in refs],review='automated source-path/byte inventory only; not semantic lesson acceptance'))
(out/'article-inventory.json').write_text(json.dumps(articles,ensure_ascii=False,indent=2));print('canonical/current article files',len(articles))
