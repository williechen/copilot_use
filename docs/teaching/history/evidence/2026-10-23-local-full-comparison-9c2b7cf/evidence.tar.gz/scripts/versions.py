import pathlib,tomllib,urllib.request,json,concurrent.futures,re,datetime
root=pathlib.Path('work/rust_ai_chat');lock=tomllib.loads((root/'Cargo.lock').read_text()); direct={}
for f in root.rglob('Cargo.toml'):
 d=tomllib.loads(f.read_text())
 def walk(o):
  if isinstance(o,dict):
   for k,v in o.items():
    if k.endswith('dependencies') and isinstance(v,dict):
     for n,c in v.items():
      if isinstance(c,str):direct.setdefault(n,[]).append(c)
      elif 'version' in c:direct.setdefault(c.get('package',n),[]).append(c['version'])
    else:walk(v)
 walk(d)
for n in ['cargo-leptos','trunk','sqlx-cli','tauri-build']:direct.setdefault(n,[])
def get(n):
 url=f'https://crates.io/api/v1/crates/{n}'
 try:
  data=json.load(urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'repository-comparison/1.0'}),timeout=40))
  stable=[v for v in data['versions'] if not v['yanked'] and not re.search(r'[-+]',v['num']) and v['created_at'][:10]<='2026-10-23']; v=max(stable,key=lambda v:tuple(map(int,v['num'].split('.'))))
  return dict(name=n,declared=sorted(set(direct[n])),resolved=[p['version'] for p in lock['package'] if p['name']==n],latest_stable=v['num'],rust_version=v.get('rust_version'),published=v['created_at'],source=url)
 except Exception as e:return dict(name=n,error=str(e),source=url)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex: rows=list(ex.map(get,sorted(direct)))
pathlib.Path('work/logs/versions.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
