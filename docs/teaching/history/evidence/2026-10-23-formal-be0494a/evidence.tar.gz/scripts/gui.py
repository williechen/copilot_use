from native_close import request_close
import os,pathlib,subprocess,json,time,socket,urllib.request,urllib.error,signal,base64,sqlite3,traceback
base=pathlib.Path.cwd();repo=base/'work/rust_ai_chat';out=base/'outputs/verification/gui';out.mkdir(exist_ok=True);results=[];children=[];sid=None
run=base/'work/gui-runtime-5';run.mkdir(exist_ok=True);(run/'root').mkdir(exist_ok=True);(run/'cache').mkdir(exist_ok=True);(run/'data').mkdir(exist_ok=True);(run/'config').mkdir(exist_ok=True)
def record(name,passed,detail):
 results.append({'name':name,'passed':passed,'detail':detail});(out/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(name,passed,flush=True)
def rpc(method,path,data=None,timeout=30):
 port=4456 if path.startswith('/session/') else 4455
 req=urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=None if data is None else json.dumps(data).encode(),method=method,headers={'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=timeout) as r:d=json.load(r)
 except urllib.error.HTTPError as e:raise RuntimeError(e.read().decode())
 v=d.get('value')
 if isinstance(v,dict) and v.get('error'):raise RuntimeError(str(v))
 return v
def ses(method,path,data=None):return rpc(method,'/session/'+sid+path,data)
def js(script):return ses('POST','/execute/sync',{'script':script,'args':[]})
def body():return js('return document.body.innerText')
def wait(fn,seconds=20):
 until=time.monotonic()+seconds;last=None
 while time.monotonic()<until:
  try:
   last=fn()
   if last:return last
  except Exception as e:last=str(e)
  time.sleep(.2)
 raise RuntimeError('wait timed out '+str(last))
def elem(using,value):return ses('POST','/element',{'using':using,'value':value})['element-6066-11e4-a52e-4f735466cecf']
def click(label):ses('POST','/element/'+elem('xpath',f'//button[normalize-space(.)="{label}"]')+'/click',{})
def fill(value):
 e=elem('css selector','main.control-shell section input');ses('POST','/element/'+e+'/clear',{});ses('POST','/element/'+e+'/value',{'text':value})
def screen(name):(out/(name+'.png')).write_bytes(base64.b64decode(ses('GET','/screenshot')))
def start(cmd,name,env):
 f=(out/(name+'.log')).open('w');p=subprocess.Popen(cmd,cwd=run,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);children.append((p,f));return p
def session():
 global sid
 val=rpc('POST','/session',{'capabilities':{'alwaysMatch':{'tauri:options':{'application':str(repo/'target/debug/desktop-pet')}}}},60);sid=val['sessionId'];ses('POST','/timeouts',{'implicit':1000,'script':10000,'pageLoad':20000});return wait(lambda:ses('GET','/window/handles'))
def switch(h):ses('POST','/window',{'handle':h})
def asyncjs(code):return ses('POST','/execute/async',{'script':'const done=arguments[arguments.length-1]; (async()=>{'+code+'})().then(x=>done({ok:true,value:x})).catch(e=>done({ok:false,error:String(e)}));','args':[]})
for port in [1420,4455,4456]:
 with socket.socket() as s:
  if s.connect_ex(('127.0.0.1',port))==0:raise RuntimeError(f'port {port} occupied')
env={k:os.environ[k] for k in ['PATH','HOME','XDG_RUNTIME_DIR','DBUS_SESSION_BUS_ADDRESS','DISPLAY','XAUTHORITY'] if k in os.environ};env.update(PET_DATABASE_URL=f'sqlite://{run}/pet.sqlite?mode=rwc',PET_AUTHORIZED_ROOT=str(run/'root'),PET_ENABLE_ROAM='false',XDG_CACHE_HOME=str(run/'cache'),XDG_DATA_HOME=str(run/'data'),XDG_CONFIG_HOME=str(run/'config'),WEBKIT_DISABLE_DMABUF_RENDERER='1')
try:
 start(['python3','-m','http.server','1420','--bind','127.0.0.1','--directory',str(repo/'apps/desktop_pet/frontend/dist')],'assets',env)
 start(['tauri-driver','--port','4455','--native-port','4456'],'driver',env);wait(lambda:rpc('GET','/status')['ready'])
 handles=session();main=handles[0];switch(main);wait(lambda:'寵物控制台' in body());record('native control window',True,body())
 for name in ['正式甲','正式乙','正式丙']:
  switch(main);fill(name);click('建立寵物');wait(lambda:'已建立並出籠：'+name in body())
 handles=wait(lambda:(h if len(h:=ses('GET','/window/handles'))==4 else None));pets=[]
 for h in handles:
  switch(h);url=ses('GET','/url')
  if 'view=pet' in url:
   wait(lambda:js('return document.querySelectorAll(".pet-face").length')==1)
   info=js('return {url:location.href,faces:document.querySelectorAll(".pet-face").length,text:document.body.innerText,width:innerWidth,height:innerHeight}')
   pets.append((h,info));screen('pet-'+str(len(pets)))
 record('three native pet windows single face',len(pets)==3,[x[1] for x in pets])
 switch(main);click('睡覺');wait(lambda:'Sleeping' in body())
 states=[]
 for h,info in pets:
  switch(h);time.sleep(.3);states.append(js('return {url:location.href,pose:document.querySelector(".pet-face img").className,text:document.body.innerText}'))
 record('state event and independent pet views',sum('pose-sleep' in x['pose'] for x in states)==1,states)
 # Close the real control window through its native Tauri API, then reopen from a life window.
 switch(main);r=request_close(os.environ['DISPLAY'],'Pet 控制台');record('native WM close request',True,r);time.sleep(.5)
 switch(pets[0][0]);click('控制台');switch(main);wait(lambda:'寵物控制台' in body());screen('control-reopened');record('control reopen from pet',True,body())
 switch(pets[0][0]);click('回籠子');wait(lambda:len(ses('GET','/window/handles'))==3);record('cage closes only one window',True,{'windows':3})
 rpc('DELETE','/session/'+sid);sid=None;time.sleep(1)
 handles=session();details=[]
 for h in handles:
  switch(h);details.append({'url':ses('GET','/url'),'text':wait(body)})
 record('restart reloads saved profiles',any(all(n in x['text'] for n in ['正式甲','正式乙','正式丙']) for x in details),details)
 with sqlite3.connect(f'file:{run}/pet.sqlite?mode=ro',uri=True) as db:
  record('persisted profile rows',db.execute('select count(*) from pet_profile').fetchone()[0]==3,{'integrity':db.execute('pragma integrity_check').fetchone()[0]})
except Exception as e:record('GUI suite execution',False,{'error':str(e),'traceback':traceback.format_exc()})
finally:
 if sid:
  try:rpc('DELETE','/session/'+sid)
  except Exception:pass
 for p,f in reversed(children):
  if p.poll() is None:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=8)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  f.close()
 record('cleanup',True,'Stopped only own WebDriver and asset-server process groups; isolated SQLite retained under work for evidence')
