import os,pathlib,subprocess,json,time,shutil,hashlib
base=pathlib.Path.cwd(); src=pathlib.Path('/home/willie/Documents/rust_ai_chat'); repo=base/'work/rust_ai_chat'; out=base/'outputs/verification'
shutil.copytree(src,repo,ignore=shutil.ignore_patterns('.git','.env*','target','docs','*.db','*.sqlite*','dist'),dirs_exist_ok=True)
(repo/'target').mkdir(exist_ok=True)
env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ['TOKEN','SECRET','PASSWORD','API_KEY','DATABASE_URL'])}
env.update(CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_TERM_COLOR='never',DATABASE_URL='sqlite::memory:'); env.pop('NO_COLOR',None)
meta={'source':str(src),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'status_before':subprocess.check_output(['git','status','--porcelain'],cwd=src,text=True),'lock_sha256':hashlib.sha256((src/'Cargo.lock').read_bytes()).hexdigest(),'files':{str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/rel for rel in subprocess.check_output(['git','ls-files'],cwd=src,text=True).splitlines()) if p.is_file() and not p.name.startswith('.env')}}
(out/'snapshot.json').write_text(json.dumps(meta,indent=2)); results=[]
def run(name,cmd,extra=None,cwd=repo):
 print('START',name,flush=True); start=time.monotonic()
 with (out/'logs'/f'{name}.log').open('w') as f:
  try: rc=subprocess.run(cmd,cwd=cwd,env=env|(extra or {}),stdout=f,stderr=subprocess.STDOUT,timeout=1800).returncode
  except subprocess.TimeoutExpired: rc=124
 results.append(dict(name=name,command=cmd,exit_code=rc,seconds=round(time.monotonic()-start,1)))
 (out/'results.json').write_text(json.dumps(results,indent=2)); print('DONE',name,rc,flush=True)
 return rc
run('environment',['bash','-c','rustc -Vv; cargo -V; node -v; rustup target list --installed; pkg-config --modversion gtk+-3.0 webkit2gtk-4.1; cargo leptos --version; trunk --version'])
steps=[('fmt','cargo fmt --all -- --check'),('node','node --test'),('workspace-tests','cargo test --locked --workspace --exclude desktop-pet-frontend'),('server-ssr-test','cargo test --locked -p server --features ssr'),('native-check','cargo check --locked --workspace --exclude desktop-pet-frontend'),('ui-ssr','cargo check --locked -p ui --features ssr'),('ui-wasm','cargo check --locked -p ui --features hydrate --target wasm32-unknown-unknown'),('pet-wasm','cargo check --locked -p desktop-pet-frontend --target wasm32-unknown-unknown'),('clippy','cargo clippy --locked --workspace --exclude desktop-pet-frontend --all-targets -- -D warnings')]
for name,cmd in steps: run(name,cmd.split())
pg='/usr/lib/postgresql/18/bin/'; data=base/'work/pg-data'; sock=base/'work/pg-socket'; sock.mkdir(exist_ok=True)
if data.exists() or run('pg-init',[pg+'initdb','-D',str(data),'--no-locale','--encoding=UTF8','--auth=trust'])==0:
 if run('pg-start',[pg+'pg_ctl','-D',str(data),'-l',str(base/'work/pg.log'),'-o',f"-k {sock} -p 55438 -h ''",'-w','start'])==0:
  pg_env={'DATABASE_URL':f'postgresql://willie@localhost:55438/postgres?host={sock}','ANALYTICS_TEST_DATABASE_URL':f'postgresql://willie@localhost:55438/postgres?host={sock}'}
  try:
   run('postgres-tests','cargo test --locked -p stats-server --features postgres-integration'.split(),pg_env)
   run('postgres-ignored','cargo test --locked -p stats-server --features postgres-integration -- --ignored'.split(),pg_env)
  finally: run('pg-stop',[pg+'pg_ctl','-D',str(data),'-m','fast','-w','stop'])
for name,cmd in [('chat-release','cargo leptos build --cargo-locked --release'),('native-build','cargo build --locked --workspace --exclude desktop-pet-frontend'),('stats-release','cargo build --locked -p stats-server --release')]: run(name,cmd.split())
run('pet-release','trunk build --locked --release'.split(),cwd=repo/'apps/desktop_pet/frontend')
meta['status_after']=subprocess.check_output(['git','status','--porcelain'],cwd=src,text=True); meta['lock_sha256_after']=hashlib.sha256((src/'Cargo.lock').read_bytes()).hexdigest(); (out/'snapshot.json').write_text(json.dumps(meta,indent=2))
