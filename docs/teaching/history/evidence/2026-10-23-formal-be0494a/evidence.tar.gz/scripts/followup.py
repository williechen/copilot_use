import pathlib,subprocess,os,json,time
base=pathlib.Path.cwd();repo=base/'work/rust_ai_chat';out=base/'outputs/verification';env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ['TOKEN','SECRET','PASSWORD','API_KEY','DATABASE_URL'])};env.update(CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_TERM_COLOR='never',DATABASE_URL='sqlite::memory:');rows=[]
for name,cmd in [('latest-fmt','cargo fmt --all -- --check'),('latest-ui-ci','cargo test --locked -p ui'),('latest-ui-ssr','cargo test --locked -p ui --features ssr'),('latest-workspace','cargo test --locked --workspace --exclude desktop-pet-frontend')]:
 print('START',name,flush=True);t=time.monotonic()
 with (out/'logs'/f'{name}.log').open('w') as f:p=subprocess.run(cmd.split(),cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 rows.append({'name':name,'command':cmd,'exit_code':p.returncode,'seconds':round(time.monotonic()-t,1)});(out/'followup-results.json').write_text(json.dumps(rows,indent=2));print('DONE',name,p.returncode,flush=True)
