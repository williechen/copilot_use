import pathlib,subprocess,json
base=pathlib.Path.cwd();out=base/'outputs/verification';pg='/usr/lib/postgresql/18/bin/';results=[]
def run(name,cmd):
 with (out/'logs'/f'{name}.log').open('w') as f:p=subprocess.run(cmd,cwd=base,stdout=f,stderr=subprocess.STDOUT,timeout=40)
 results.append({'name':name,'command':cmd,'exit_code':p.returncode});return p.returncode
run('pet-old-upgrade',['work/upgrade-probe','sqlite',str(base/'work/old-migrations/desktop_pet'),str(base/'work/rust_ai_chat/apps/desktop_pet/migrations'),'sqlite://'+str(base/'work/pet-upgrade.sqlite')+'?mode=rwc'])
if run('upgrade-pg-start',[pg+'pg_ctl','-D',str(base/'work/pg-data'),'-l',str(base/'work/pg.log'),'-o',f"-k {base}/work/pg-socket -p 55438 -h ''",'-w','start'])==0:
 try:
  run('upgrade-pg-createdb',[pg+'createdb','-h',str(base/'work/pg-socket'),'-p','55438','formal_upgrade'])
  run('analytics-old-upgrade',['work/upgrade-probe','postgres',str(base/'work/old-migrations/stats_server'),str(base/'work/rust_ai_chat/apps/stats_server/migrations'),f'postgresql://willie@localhost:55438/formal_upgrade?host={base}/work/pg-socket'])
 finally:run('upgrade-pg-stop',[pg+'pg_ctl','-D',str(base/'work/pg-data'),'-m','fast','-w','stop'])
(out/'upgrade-results.json').write_text(json.dumps({'baseline':'4f0cd00','sentinel':'isolated synthetic table formal_preserved; not a product profile test','results':results},indent=2));print([(r['name'],r['exit_code']) for r in results]);print((out/'logs/pet-old-upgrade.log').read_text());print((out/'logs/analytics-old-upgrade.log').read_text())
