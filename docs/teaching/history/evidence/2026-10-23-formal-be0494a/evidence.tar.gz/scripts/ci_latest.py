import json,urllib.request,pathlib,datetime
base='https://api.github.com/repos/williechen/rust_ai_chat'; sha=pathlib.Path('outputs/verification/snapshot.json').read_text(); sha='be0494a2a70be91eb74b2b726970a23fc3e5c044'
def get(path):
 with urllib.request.urlopen(urllib.request.Request(base+path,headers={'Accept':'application/vnd.github+json','User-Agent':'local-validation'}),timeout=30) as r: return json.load(r)
runs=get('/actions/runs?head_sha='+sha+'&per_page=100')['workflow_runs']; rows=[]
for r in runs:
 jobs=get('/actions/runs/'+str(r['id'])+'/jobs?per_page=100')['jobs']
 rows.append({k:r[k] for k in ['id','name','head_sha','status','conclusion','html_url','updated_at']} | {'jobs':[{k:j[k] for k in ['id','name','status','conclusion','html_url']} for j in jobs]})
pathlib.Path('outputs/verification/ci-latest.json').write_text(json.dumps({'queried_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),'sha':sha,'runs':rows},indent=2))
print([(r['name'],r['status'],r['conclusion']) for r in rows])
