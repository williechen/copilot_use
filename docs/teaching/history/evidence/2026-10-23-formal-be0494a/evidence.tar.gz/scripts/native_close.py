import ctypes,subprocess,os,re

def request_close(display_name,title):
 env=dict(os.environ,DISPLAY=display_name)
 tree=subprocess.check_output(['xwininfo','-root','-tree','-display',display_name],env=env,text=True)
 ids=[m.group(1) for line in tree.splitlines() if title in line and (m:=re.match(r'\s*(0x[0-9a-fA-F]+)',line))]
 if len(ids)!=1:raise RuntimeError('Expected exactly one title match: '+str(ids))
 lib=ctypes.CDLL('libX11.so.6');lib.XOpenDisplay.argtypes=[ctypes.c_char_p];lib.XOpenDisplay.restype=ctypes.c_void_p
 lib.XInternAtom.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int];lib.XInternAtom.restype=ctypes.c_ulong
 class Data(ctypes.Union):_fields_=[('b',ctypes.c_char*20),('s',ctypes.c_short*10),('l',ctypes.c_long*5)]
 class Client(ctypes.Structure):_fields_=[('type',ctypes.c_int),('serial',ctypes.c_ulong),('send_event',ctypes.c_int),('display',ctypes.c_void_p),('window',ctypes.c_ulong),('message_type',ctypes.c_ulong),('format',ctypes.c_int),('data',Data)]
 class Event(ctypes.Union):_fields_=[('client',Client),('pad',ctypes.c_long*24)]
 d=lib.XOpenDisplay(display_name.encode());assert d
 e=Event();e.client.type=33;e.client.display=d;e.client.window=int(ids[0],16);e.client.message_type=lib.XInternAtom(d,b'WM_PROTOCOLS',False);e.client.format=32;e.client.data.l[0]=lib.XInternAtom(d,b'WM_DELETE_WINDOW',False)
 lib.XSendEvent.argtypes=[ctypes.c_void_p,ctypes.c_ulong,ctypes.c_int,ctypes.c_long,ctypes.POINTER(Event)];lib.XFlush.argtypes=[ctypes.c_void_p];lib.XCloseDisplay.argtypes=[ctypes.c_void_p]
 sent=lib.XSendEvent(d,int(ids[0],16),False,0,ctypes.byref(e));lib.XFlush(d);lib.XCloseDisplay(d);assert sent
 return {'window_id':ids[0],'event':'WM_DELETE_WINDOW','display':display_name}
