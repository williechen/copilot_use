import pathlib,subprocess,os,json,time,socket,urllib.request,urllib.error,urllib.parse,re,uuid,pty,select,signal
base=pathlib.Path.cwd();repo=base/'work/rust_ai_chat';out=base/'outputs/verification';results=[];p=None;started=False
pg='/usr/lib/postgresql/18/bin/';url=f'postgresql://willie@localhost:55438/postgres?host={base}/work/pg-socket'
env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ['TOKEN','SECRET','PASSWORD','API_KEY','DATABASE_URL'])};env.update(ANALYTICS_DATABASE_URL=url,ANALYTICS_CHAT_TOKEN='formal-chat-fixture',ANALYTICS_PET_TOKEN='formal-pet-fixture')
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kw):return None
opener=urllib.request.build_opener(NoRedirect)
def req(path,expected=200,data=None,cookie=None,headers=None):
 h=headers or {}
 if cookie:h['Cookie']=cookie
 if data is not None:
  h['Origin']='http://127.0.0.1:3100'
  if isinstance(data,dict):data=urllib.parse.urlencode(data).encode();h.setdefault('Content-Type','application/x-www-form-urlencoded')
 q=urllib.request.Request('http://127.0.0.1:3100'+path,data=data,headers=h)
 try:r=opener.open(q,timeout=10)
 except urllib.error.HTTPError as e:r=e
 body=r.read().decode();results.append({'path':path,'expected':expected,'actual':r.code,'passed':r.code==expected});return r,body
try:
 for port in [3100]:
  with socket.socket() as s:
   if s.connect_ex(('127.0.0.1',port))==0:raise RuntimeError('port occupied')
 subprocess.run([pg+'pg_ctl','-D',str(base/'work/pg-data'),'-l',str(base/'work/pg.log'),'-o',f"-k {base}/work/pg-socket -p 55438 -h ''",'-w','start'],check=True,stdout=subprocess.DEVNULL);started=True
 pid,fd=pty.fork()
 if pid==0:
  os.chdir(repo);os.execve(str(repo/'target/release/bootstrap_admin'),['bootstrap_admin'],env)
 prompts=0;buf=b'';deadline=time.monotonic()+30;status=None
 while time.monotonic()<deadline:
  if select.select([fd],[],[],.2)[0]:
   try:chunk=os.read(fd,4096)
   except OSError:break
   buf+=chunk
   count=buf.count('：'.encode())
   if count>prompts and prompts<2:os.write(fd,b'formal-fixture-password\n');prompts+=1
  done,status=os.waitpid(pid,os.WNOHANG)
  if done:break
 else:os.kill(pid,signal.SIGTERM)
 try:_,status=os.waitpid(pid,0)
 except ChildProcessError:pass
 os.close(fd);results.append({'name':'bootstrap real TTY','passed':status==0,'exit_status':status,'prompts':prompts});assert status==0
 log=(out/'logs/runtime-analytics.log').open('w');p=subprocess.Popen([str(repo/'target/release/stats-server')],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 for _ in range(150):
  try:
   with socket.create_connection(('127.0.0.1',3100),timeout=.1):break
  except OSError:time.sleep(.1)
 req('/healthz');r,html=req('/login');results.append({'name':'login Leptos SSR','passed':html.lower().count('<!doctype html>')==1 and 'id="analytics-password"' in html})
 req('/dashboard',303)
 r,_=req('/login',303,{'username':'admin','password':'formal-fixture-password'});c=r.headers['Set-Cookie'].split(';')[0]
 req('/api/v1/events/web_chat/summary',403,cookie=c)
 _,html=req('/change-password',cookie=c);csrf=re.search(r'name="csrf" value="([a-f0-9]+)"',html).group(1)
 results.append({'name':'change password Leptos labels','passed':'id="change-current"' in html and html.lower().count('<!doctype html>')==1})
 req('/change-password',303,{'current_password':'formal-fixture-password','new_password':'formal-new-password','confirm_password':'formal-new-password','email':'formal-admin@example.test','csrf':csrf},c)
 req('/api/v1/events/web_chat/summary',401,cookie=c)
 req('/login',401,{'username':'admin','password':'formal-fixture-password'})
 r,_=req('/login',303,{'username':'admin','password':'formal-new-password'});c=r.headers['Set-Cookie'].split(';')[0]
 req('/dashboard',cookie=c);req('/change-password',cookie=c)
 for source,token in [('web_chat','formal-chat-fixture'),('desktop_pet','formal-pet-fixture')]:
  event={'schema_version':1,'event_id':str(uuid.uuid4()),'source_app':source,'event_type':'formal.validation'};data=json.dumps(event).encode()
  req('/api/v1/events',401,data,headers={'Content-Type':'application/json'})
  req('/api/v1/events',201,data,headers={'Content-Type':'application/json','Authorization':'Bearer '+token})
  req('/api/v1/events',200,data,headers={'Content-Type':'application/json','Authorization':'Bearer '+token})
  req('/dashboard?source='+source,cookie=c)
except Exception as e:results.append({'name':'analytics runtime suite','passed':False,'error':str(e)})
finally:
 if p:
  p.terminate()
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:p.kill();p.wait()
  log.close()
 if started:subprocess.run([pg+'pg_ctl','-D',str(base/'work/pg-data'),'-m','fast','-w','stop'],stdout=subprocess.DEVNULL)
 (out/'analytics-runtime.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(json.dumps(results,ensure_ascii=False,indent=2))
