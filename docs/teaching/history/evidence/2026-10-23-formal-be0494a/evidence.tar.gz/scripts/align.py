import pathlib,subprocess,json,hashlib
src=pathlib.Path('/home/willie/Documents/rust_ai_chat');base=pathlib.Path.cwd();repo=base/'work/rust_ai_chat';files=subprocess.check_output(['git','ls-files'],cwd=src,text=True).splitlines();rows=[]
for name in files:
 if name.startswith('.env'):continue
 p=src/name;q=repo/name
 if not p.is_file():continue
 blob=subprocess.check_output(['git','rev-parse','HEAD:'+name],cwd=src,text=True).strip();actual=hashlib.sha1(b'blob '+str(p.stat().st_size).encode()+b'\0'+p.read_bytes()).hexdigest()
 rows.append({'path':name,'matches_head':actual==blob,'snapshot_matches_local':q.exists() and p.read_bytes()==q.read_bytes(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
x={'source_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'tracked_files':len(rows),'source_changes':[r['path'] for r in rows if not r['matches_head']],'snapshot_mismatches':[r['path'] for r in rows if not r['snapshot_matches_local']],'files':rows}
(base/'outputs/verification/alignment.json').write_text(json.dumps(x,indent=2));print({k:v for k,v in x.items() if k!='files'})
