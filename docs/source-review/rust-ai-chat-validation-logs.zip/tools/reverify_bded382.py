from pathlib import Path
import os,sys,subprocess,json,time,socket,tempfile,datetime,zoneinfo,hashlib
root=Path(__file__).resolve().parent.parent;ref=root/'work/reference-snapshots/bded382';src=root/'work/validation-source-bded382';target=root/'work/validation-target';stamp=datetime.datetime.now(zoneinfo.ZoneInfo('Asia/Taipei')).strftime('%Y%m%d-%H%M%S');out=root/'evidence'/('verification-'+stamp);out.mkdir()
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ref,text=True).strip();assert sha=='bded3825f3c7c76599bf3f4284452d5dc79e02b2'
import tarfile,io
src.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','HEAD'],cwd=ref))) as t:t.extractall(src,filter='data')
for p in subprocess.check_output(['git','ls-files','-z'],cwd=ref).decode().split('\0'):
 if p:assert (ref/p).read_bytes()==(src/p).read_bytes(),p
(root/'evidence/current-verification-path.txt').write_text(str(out)+'\n')
env=os.environ.copy()
for k in list(env):
 if any(x in k.upper() for x in ['OPENAI','API_KEY','DATABASE','PET_AUTHORIZED_ROOT']):env.pop(k,None)
env.update(CARGO_TARGET_DIR=str(target),CARGO_NET_OFFLINE='true',NO_COLOR='true',CARGO_TERM_COLOR='never',DATABASE_URL='sqlite::memory:',DATABASE_SQLITE_URL='sqlite::memory:')
report={'reference_sha':sha,'started_at':datetime.datetime.now(zoneinfo.ZoneInfo('Asia/Taipei')).isoformat(),'status':'running','source_modified':False,'commands':[],'paid_ai_executed':False}
def run(name,cmd,cwd=src,extra=None):
 print('START '+name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=cwd,env=env|(extra or {}),stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exit_code':p.returncode,'seconds':round(time.monotonic()-start,2),'log':name+'.log'};report['commands'].append(row);save();print('FINISH '+name+' exit='+str(p.returncode),flush=True)
 if p.returncode:print('\n'.join((out/(name+'.log')).read_text().splitlines()[-13:]),flush=True)
 return p.returncode
def save():(out/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
save()
run('format',['cargo','fmt','--all','--','--check']);run('node-tests',['node','--test'])
run('workspace-tests',['cargo','test','--offline','--locked','--workspace','--exclude','desktop-pet-frontend'])
run('clippy',['cargo','clippy','--offline','--locked','--workspace','--exclude','desktop-pet-frontend','--all-targets','--','-D','warnings'])
run('chat-ssr',['cargo','check','--offline','--locked','-p','server','-p','ui','--features','ssr'])
run('chat-wasm',['cargo','check','--offline','--locked','-p','ui','--features','hydrate','--target','wasm32-unknown-unknown'])
run('pet-wasm',['cargo','check','--offline','--locked','-p','desktop-pet-frontend','--target','wasm32-unknown-unknown'])
pgbin=Path(subprocess.check_output(['pg_config','--bindir'],text=True).strip());data=root/'work'/('postgres-'+stamp);sock=Path(tempfile.mkdtemp(prefix='rust-ai-pg-'))
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
started=False
try:
 if run('postgres-init',[str(pgbin/'initdb'),'-D',str(data),'-A','trust','--no-locale','-E','UTF8'])==0 and run('postgres-start',[str(pgbin/'pg_ctl'),'-D',str(data),'-l',str(out/'postgres.log'),'-o',f'-h 127.0.0.1 -p {port} -k {sock}','-w','start'])==0:
  started=True;run('postgres-integration',['cargo','test','--offline','--locked','-p','stats-server','--features','postgres-integration','--test','postgres_event_store'],extra={'DATABASE_URL':f'postgresql://{os.environ.get("USER","willie")}@127.0.0.1:{port}/postgres'})
finally:
 if started:run('postgres-stop',[str(pgbin/'pg_ctl'),'-D',str(data),'-m','fast','-w','stop'])
run('pet-release-frontend',['trunk','build','--locked=true','--release=true','--no-color'],cwd=src/'apps/desktop_pet/frontend',extra={'CARGO_TARGET_DIR':str(root/'work/pet-wasm-release-target')})
run('native-release',['cargo','build','--offline','--locked','--release','--workspace','--exclude','desktop-pet-frontend'])
run('chat-release',['cargo','leptos','build','--cargo-locked','--release'])
# Fresh runtime DB and logs; original test helper is copied as audit tooling only.
rt=(root/'evidence/runtime_smoke.py').read_text().replace("src=root/'work/validation-source'",'src=Path('+repr(str(src))+')').replace("out=root/'evidence/rust-ai-chat-local'",'out=Path('+repr(str(out))+')').replace("db=root/'work/runtime-chat.sqlite'",'db=Path('+repr(str(out/'runtime-chat.sqlite'))+')')
p=root/'evidence'/('runtime-'+stamp+'.py');p.write_text(rt);run('runtime-smoke',['python3',str(p)],cwd=root)
report['runtime']=json.loads((out/'runtime-result.json').read_text());report['source_worktree_clean']=not subprocess.check_output(['git','status','--porcelain'],cwd=ref,text=True).strip();assert report['source_worktree_clean']
report['status']='local_completed';report['completed_at']=datetime.datetime.now(zoneinfo.ZoneInfo('Asia/Taipei')).isoformat();save();print('LOCAL COMPLETE '+str(out),flush=True)
