from pathlib import Path
import urllib.request,json,datetime,zoneinfo
root=Path(__file__).resolve().parent.parent;out=root/'evidence/rust-ai-chat-local';assert json.loads((out/'formal-result.json').read_text())['status']=='completed'
sha=json.loads((out/'result.json').read_text())['reference_sha'];base='https://api.github.com/repos/williechen/rust_ai_chat/'
for name,path in [('remote-branch','branches/main'),('remote-workflows',f'actions/runs?head_sha={sha}&event=push&per_page=100'),('remote-checks',f'commits/{sha}/check-runs?per_page=100')]:
 req=urllib.request.Request(base+path,headers={'Accept':'application/vnd.github+json','User-Agent':'local-reference-validation','X-GitHub-Api-Version':'2022-11-28'})
 with urllib.request.urlopen(req,timeout=30) as r:d=json.load(r)
 (out/(name+'.json')).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 if name=='remote-branch':print('current main '+d['commit']['sha'])
 elif name=='remote-workflows':print('workflows',[(x['name'],x['status'],x['conclusion']) for x in d['workflow_runs']])
 else:print('checks',len(d['check_runs']),[(x['name'],x['conclusion']) for x in d['check_runs'] if x['conclusion']!='success'])
