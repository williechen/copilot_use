from pathlib import Path
import json,os,subprocess,time,socket,datetime
root=Path(__file__).resolve().parent.parent;src=root/'work/validation-source';out=root/'evidence/rust-ai-chat-local';env=os.environ.copy()
for k in list(env):
 if any(x in k.upper() for x in ['OPENAI','API_KEY','DATABASE_URL','DATABASE_PG_URL','DATABASE_SQLITE_URL','PET_AUTHORIZED_ROOT']):env.pop(k,None)
env.update(CARGO_TARGET_DIR=str(root/'work/validation-target'),CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never')
while json.loads((out/'result.json').read_text()).get('status')!='completed':time.sleep(2)
results={'reference_sha':json.loads((out/'result.json').read_text())['reference_sha'],'status':'running','commands':[]}
def run(name,cmd,cwd=src,extra=None):
 print('START '+name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=cwd,env=env|(extra or {}),stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exit_code':p.returncode,'duration_seconds':round(time.monotonic()-start,2),'log':name+'.log'};results['commands'].append(row);(out/'formal-result.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print('FINISH '+name+' exit='+str(p.returncode),flush=True)
 if p.returncode:print('\n'.join((out/(name+'.log')).read_text().splitlines()[-18:]),flush=True)
 return p.returncode
pgbin=Path(subprocess.check_output(['pg_config','--bindir'],text=True).strip());data=root/'work/validation-postgres';sock=Path('/tmp')/('rust-ai-pg-'+str(os.getpid()));sock.mkdir(exist_ok=True,mode=0o700)
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
started=False
try:
 if run('postgres-init',[str(pgbin/'initdb'),'-D',str(data),'-A','trust','--no-locale','-E','UTF8'])==0:
  if run('postgres-start',[str(pgbin/'pg_ctl'),'-D',str(data),'-l',str(out/'postgres.log'),'-o',f'-h 127.0.0.1 -p {port} -k {sock}','-w','start'])==0:
   started=True
   run('postgres-integration',['cargo','test','--offline','--locked','-p','stats-server','--features','postgres-integration','--test','postgres_event_store'],extra={'DATABASE_URL':f'postgresql://{os.environ.get("USER","willie")}@127.0.0.1:{port}/postgres'})
finally:
 if started:run('postgres-stop',[str(pgbin/'pg_ctl'),'-D',str(data),'-m','fast','-w','stop'])
# 先建 WASM assets，再建 native release，對應目前 CI 實際入口。
run('pet-release-frontend',['trunk','build','--locked','--release'],cwd=src/'apps/desktop_pet/frontend')
run('native-release',['cargo','build','--offline','--locked','--release','--workspace','--exclude','desktop-pet-frontend'])
run('chat-release',['cargo','leptos','build','--cargo-locked','--release'])
results['status']='completed';(out/'formal-result.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
