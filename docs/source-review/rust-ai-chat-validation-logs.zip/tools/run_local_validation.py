from pathlib import Path
import os,subprocess,json,datetime,tarfile,io,time
root=Path(__file__).resolve().parent.parent;ref=root/'work/reference-rust_ai_chat';src=root/'work/validation-source';src.mkdir(exist_ok=True);out=root/'evidence/rust-ai-chat-local';out.mkdir(exist_ok=True)
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ref,text=True).strip()
archive=subprocess.check_output(['git','archive','HEAD'],cwd=ref)
with tarfile.open(fileobj=io.BytesIO(archive)) as t:t.extractall(src,filter='data')
env=os.environ.copy()
for k in list(env):
 if any(x in k.upper() for x in ['OPENAI','API_KEY','DATABASE_URL','DATABASE_PG_URL','DATABASE_SQLITE_URL','PET_AUTHORIZED_ROOT']):env.pop(k,None)
env.update(CARGO_TARGET_DIR=str(root/'work/validation-target'),CARGO_NET_OFFLINE='true',DATABASE_URL='sqlite::memory:',DATABASE_SQLITE_URL='sqlite::memory:',CARGO_TERM_COLOR='never')
commands=[('format',['cargo','fmt','--all','--','--check']),('node-tests',['node','--test']),('workspace-tests',['cargo','test','--offline','--locked','--workspace','--exclude','desktop-pet-frontend']),('clippy',['cargo','clippy','--offline','--locked','--workspace','--exclude','desktop-pet-frontend','--all-targets','--','-D','warnings']),('chat-ssr',['cargo','check','--offline','--locked','-p','server','-p','ui','--features','ssr']),('chat-wasm',['cargo','check','--offline','--locked','-p','ui','--features','hydrate','--target','wasm32-unknown-unknown']),('pet-wasm',['cargo','check','--offline','--locked','-p','desktop-pet-frontend','--target','wasm32-unknown-unknown'])]
result={'reference_sha':sha,'source_copy':str(src),'source_modified':False,'real_ai_executed':False,'commands':[],'status':'running'}
for label,args in commands:
 print('START '+label,flush=True);start=time.monotonic()
 with (out/(label+'.log')).open('w') as f:p=subprocess.run(args,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT)
 result['commands'].append({'name':label,'command':args,'exit_code':p.returncode,'duration_seconds':round(time.monotonic()-start,2),'log':label+'.log'})
 (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print('FINISH '+label+' exit='+str(p.returncode),flush=True)
 if p.returncode:print('\n'.join((out/(label+'.log')).read_text().splitlines()[-18:]),flush=True)
result['status']='completed';(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
