from pathlib import Path
import subprocess,os,json,time,socket,urllib.request,urllib.error,sqlite3
root=Path(__file__).resolve().parent.parent;src=root/'work/validation-source';target=root/'work/validation-target/release';out=root/'evidence/rust-ai-chat-local';db=root/'work/runtime-chat.sqlite';env=os.environ.copy()
for k in list(env):
 if any(x in k.upper() for x in ['OPENAI','API_KEY','DATABASE','PET_AUTHORIZED_ROOT']):env.pop(k,None)
env.update(DATABASE_SQLITE_URL=f'sqlite://{db}?mode=rwc',LEPTOS_OUTPUT_NAME='rust_ai_chat',LEPTOS_SITE_ROOT=str(src/'target/site'))
for port in [3000,3100]:
 with socket.socket() as s:s.bind(('127.0.0.1',port))
results=[];procs=[];logs=[]
def req(port,path,data=None):
 b=None if data is None else json.dumps(data).encode();r=urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=b,headers={'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(r,timeout=3) as x:return x.status,x.read().decode()
 except urllib.error.HTTPError as e:return e.code,e.read().decode()
def check(name,condition,detail=None):
 results.append({'name':name,'passed':condition,'detail':detail});assert condition,name
try:
 for binary,port in [('server',3000),('stats-server',3100)]:
  f=(out/(binary+'-runtime.log')).open('w');logs.append(f);p=subprocess.Popen([str(target/binary)],cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT);procs.append(p)
  for _ in range(50):
   try:code,body=req(port,'/health' if port==3000 else '/healthz');break
   except Exception:
    if p.poll() is not None:raise RuntimeError(binary+' failed to start')
    time.sleep(.1)
  check(binary+' health',code==200)
 code,body=req(3000,'/api/rooms',{'name':'isolated local verification'});check('create actual SQLite room',code==200);room=json.loads(body)['id']
 code,body=req(3000,'/api/rooms',{'name':'second isolated room'});room2=json.loads(body)['id']
 node='''const room=process.argv[1];const room2=process.argv[2];const a=new WebSocket('ws://127.0.0.1:3000/ws/'+room);const b=new WebSocket('ws://127.0.0.1:3000/ws/'+room);const other=new WebSocket('ws://127.0.0.1:3000/ws/'+room2);let count=0;let leaked=false;const timer=setTimeout(()=>{console.error('message timeout');process.exit(2)},8000);other.onmessage=()=>{leaked=true};for(const w of[a,b,other])w.onopen=()=>{if(++count===3)setTimeout(()=>a.send(JSON.stringify({type:'send_message',data:{room_id:room,content:'isolated durable WS validation'}})),100)};b.onmessage=e=>{const v=JSON.parse(e.data);if(v.type==='message_created'&&v.data.content==='isolated durable WS validation'){setTimeout(()=>{clearTimeout(timer);a.close();b.close();other.close();console.log(JSON.stringify({received:true,leaked}));process.exit(leaked?3:0)},150)}};'''
 n=subprocess.run(['node','-e',node,room,room2],capture_output=True,text=True,timeout=12);(out/'websocket-runtime.log').write_text(n.stdout+n.stderr);check('actual two-client WS and room isolation',n.returncode==0,n.stdout.strip())
 with sqlite3.connect(db) as c:check('WS message persisted to SQLite',c.execute('SELECT COUNT(*) FROM messages WHERE room_id=? AND content=?',(room,'isolated durable WS validation')).fetchone()[0]==1)
 event={'schema_version':1,'event_id':'b47d7db8-b501-42a6-99f3-18bff0752c61','source_app':'web_chat','event_type':'message.persisted'}
 code,body=req(3100,'/api/v1/events',event);check('Analytics current HTTP stub honestly returns 501',code==501,'not functional ingestion acceptance')
except Exception as e:results.append({'name':'runtime execution','passed':False,'detail':str(e)})
finally:
 for p in procs:
  p.terminate()
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:p.kill();p.wait()
 for f in logs:f.close()
(out/'runtime-result.json').write_text(json.dumps({'checks':results,'paid_ai_executed':False},ensure_ascii=False,indent=2)+'\n');print(json.dumps(results,ensure_ascii=False))
