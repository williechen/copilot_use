from pathlib import Path
import os, json, subprocess, socket, tempfile, time, hashlib, urllib.request, urllib.error, uuid
root=Path(__file__).resolve().parent.parent
out=Path((root/'evidence/current-day12-verification-path.txt').read_text().strip())
base=json.loads((out/'result.json').read_text()); src=Path(base['copied_source'])
env=os.environ.copy()
for k in list(env):
    if any(v in k.upper() for v in ['OPENAI','API_KEY','DATABASE','PET_AUTHORIZED_ROOT']):env.pop(k,None)
env.update(CARGO_TARGET_DIR=str(root/'work/validation-target'), CARGO_NET_OFFLINE='true', NO_COLOR='true', CARGO_TERM_COLOR='never', CHAT_DATABASE_URL='sqlite::memory:',DATABASE_SQLITE_URL='sqlite::memory:', ANALYTICS_CHAT_TOKEN='local-chat-test', ANALYTICS_PET_TOKEN='local-pet-test')
rows=[]
formal=os.environ.get('DAY12_FORMAL')=='1'
def run(name,cmd):
    print('START '+name,flush=True)
    with (out/(name+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT)
    rows.append(dict(name=name,exit_code=p.returncode,command=cmd));save()
    print('FINISH '+name+' exit='+str(p.returncode),flush=True)
    if p.returncode:print((out/(name+'.log')).read_text()[-2500:],flush=True)
    return p.returncode
def save():(out/'extended-result.json').write_text(json.dumps({'commands':rows},indent=2)+'\n')
pg=Path(subprocess.check_output(['pg_config','--bindir'],text=True).strip()); data=out/'postgres'; sock=Path(tempfile.mkdtemp(prefix='day12-pg-'))
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
started=False
try:
    if run('pg-init',[str(pg/'initdb'),'-D',str(data),'-A','trust','--no-locale','-E','UTF8']):raise RuntimeError('initdb failed')
    if run('pg-start',[str(pg/'pg_ctl'),'-D',str(data),'-l',str(out/'postgres.log'),'-o',f'-h 127.0.0.1 -p {port} -k {sock}','-w','start']):raise RuntimeError('postgres failed')
    started=True
    url=f'postgresql://{os.environ.get("USER","willie")}@127.0.0.1:{port}/postgres'
    env.update(DATABASE_URL=url,ANALYTICS_DATABASE_URL=url)
    for migration in sorted((src/'apps/stats_server/migrations').glob('*.sql')):run('pg-migration',[str(pg/'psql'),url,'-v','ON_ERROR_STOP=1','-f',str(migration)])
    run('workspace-tests',['cargo','test','--offline','--locked','--workspace','--exclude','desktop-pet-frontend'])
    run('postgres-integration',['cargo','test','--offline','--locked','-p','stats-server','--features','postgres-integration','--test','postgres_event_store'])
    run('clippy',['cargo','clippy','--offline','--locked','--workspace','--exclude','desktop-pet-frontend','--all-targets','--','-D','warnings'])
    run('chat-ssr',['cargo','check','--offline','--locked','-p','server','-p','ui','--features','ssr'])
    run('chat-wasm',['cargo','check','--offline','--locked','-p','ui','--features','hydrate','--target','wasm32-unknown-unknown'])
    run('pet-wasm',['cargo','check','--offline','--locked','-p','desktop-pet-frontend','--target','wasm32-unknown-unknown'])
    run('node-tests',['node','--test'])
    if formal:
        run('native-release',['cargo','build','--offline','--locked','--release','--workspace','--exclude','desktop-pet-frontend'])
        run('chat-release',['cargo','leptos','build','--cargo-locked','--release'])
        old_cwd=src
        src=old_cwd/'apps/desktop_pet/frontend'
        env['CARGO_TARGET_DIR']=str(root/'work/pet-wasm-release-target')
        run('pet-release-frontend',['trunk','build','--locked=true','--release=true','--no-color'])
        src=old_cwd
        env['CARGO_TARGET_DIR']=str(root/'work/validation-target')
    if run('runtime-build',['cargo','build','--offline','--locked','-p','stats-server','-p','server','--features','server/ssr'])==0:
        runtime=[]; procs=[]; logs=[]
        def check(name,ok):runtime.append({'name':name,'passed':ok});assert ok,name
        def req(port,path,event=None,token=None):
            headers={'Content-Type':'application/json'}
            if token:headers['Authorization']='Bearer '+token
            request=urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=None if event is None else json.dumps(event).encode(),headers=headers)
            try:
                with urllib.request.urlopen(request,timeout=40) as r:return r.status,r.read().decode()
            except urllib.error.HTTPError as e:return e.code,e.read().decode()
        try:
            env.update(CHAT_DATABASE_URL=f'sqlite://{out}/runtime.sqlite?mode=rwc',LEPTOS_OUTPUT_NAME='rust_ai_chat',LEPTOS_SITE_ROOT=str(src/'target/site'))
            for binary,port,path in [('stats-server',3100,'/healthz'),('server',3000,'/health')]:
                with socket.socket() as s:s.bind(('127.0.0.1',port))
                f=(out/(binary+'-runtime.log')).open('w');logs.append(f)
                profile='release' if formal else 'debug'
                p=subprocess.Popen([str(root/'work/validation-target'/profile/binary)],cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT);procs.append(p)
                for _ in range(80):
                    try:code,_=req(port,path);break
                    except Exception:
                        if p.poll() is not None:raise RuntimeError(binary+' exited')
                        time.sleep(.1)
                check(binary+' health',code==200)
            event=dict(schema_version=1,event_id=str(uuid.uuid4()),source_app='web_chat',event_type='chat.message.persisted')
            check('missing token rejected',req(3100,'/api/v1/events',event)[0]==401)
            check('wrong source token rejected',req(3100,'/api/v1/events',event,'local-pet-test')[0]==401)
            check('authenticated event stored',req(3100,'/api/v1/events',event,'local-chat-test')[0]==201)
            check('persistent duplicate accepted',req(3100,'/api/v1/events',event,'local-chat-test')[0]==200)
            event['event_type']='chat.message.changed'
            check('identity conflict rejected',req(3100,'/api/v1/events',event,'local-chat-test')[0]==409)
            invalid=event|{'schema_version':2}
            check('invalid payload rejected',req(3100,'/api/v1/events',invalid,'local-chat-test')[0]==400)
            pet=event|{'source_app':'desktop_pet','event_type':'pet.cleanup.succeeded'}
            check('same id separate source stored',req(3100,'/api/v1/events',pet,'local-pet-test')[0]==201)
            from concurrent.futures import ThreadPoolExecutor
            concurrent=event|{'event_id':str(uuid.uuid4())}
            with ThreadPoolExecutor(max_workers=8) as executor:
                codes=list(executor.map(lambda _:req(3100,'/api/v1/events',concurrent,'local-chat-test')[0],range(8)))
            check('concurrent same id stored exactly once',codes.count(201)==1 and codes.count(200)==7)
            procs[0].terminate();procs[0].wait(timeout=5)
            procs[0]=subprocess.Popen([str(root/'work/validation-target'/profile/'stats-server')],cwd=src,env=env,stdout=logs[0],stderr=subprocess.STDOUT)
            for _ in range(80):
                try:req(3100,'/healthz');break
                except Exception:time.sleep(.1)
            check('dedup survives service restart',req(3100,'/api/v1/events',concurrent,'local-chat-test')[0]==200)
            room=json.loads(req(3000,'/api/rooms',{'name':'Day12 runtime'})[1])['id']
            other=json.loads(req(3000,'/api/rooms',{'name':'Day12 isolated'})[1])['id']
            node="""const [r,o]=process.argv.slice(1);const a=new WebSocket('ws://127.0.0.1:3000/ws/'+r),b=new WebSocket('ws://127.0.0.1:3000/ws/'+r),c=new WebSocket('ws://127.0.0.1:3000/ws/'+o);let n=0,leak=false;const t=setTimeout(()=>process.exit(2),6000);c.onmessage=e=>{if(JSON.parse(e.data).type==='typing_changed')leak=true};for(const w of[a,b,c])w.onopen=()=>{if(++n===3)setTimeout(()=>a.send(JSON.stringify({type:'typing',data:{room_id:r,active:true}})),100)};b.onmessage=e=>{const x=JSON.parse(e.data);if(x.type==='typing_changed'&&x.data.room_id===r&&x.data.active===true)setTimeout(()=>{clearTimeout(t);console.log(JSON.stringify({typing:true,leak}));process.exit(leak?3:0)},200)};"""
            p=subprocess.run(['node','-e',node,room,other],capture_output=True,text=True,timeout=10)
            (out/'typing-runtime.log').write_text(p.stdout+p.stderr);check('actual typing broadcast and room isolation',p.returncode==0)
            import sqlite3
            with sqlite3.connect(out/'runtime.sqlite') as db:check('typing creates no message records',db.execute('SELECT COUNT(*) FROM messages').fetchone()[0]==0)
            run('pg-runtime-stop',[str(pg/'pg_ctl'),'-D',str(data),'-m','fast','-w','stop']);started=False
            check('database failure returns 503 without success acknowledgement',req(3100,'/api/v1/events',event|{'event_id':str(uuid.uuid4())},'local-chat-test')[0]==503)
        except Exception as e:runtime.append({'name':'runtime execution','passed':False,'error':str(e)})
        finally:
            for p in procs:
                p.terminate()
                try:p.wait(timeout=5)
                except subprocess.TimeoutExpired:p.kill();p.wait()
            for f in logs:f.close()
            (out/'runtime-result.json').write_text(json.dumps(runtime,indent=2)+'\n');print(json.dumps(runtime),flush=True)
finally:
    if started:run('pg-stop',[str(pg/'pg_ctl'),'-D',str(data),'-m','fast','-w','stop'])
    for item in json.loads((out/'file-manifest.json').read_text()):assert hashlib.sha256((Path(base['local_path'])/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
    assert subprocess.check_output(['git','status','--porcelain'],cwd=base['local_path'],text=True)==base['git_status']
    print('ORIGINAL SOURCE PRESERVED',flush=True)
