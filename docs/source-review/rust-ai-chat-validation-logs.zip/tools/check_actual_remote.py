from pathlib import Path
import json,urllib.request,datetime,zoneinfo
root=Path(__file__).resolve().parent.parent;out=Path((root/'evidence/current-day12-verification-path.txt').read_text().strip());b=json.loads((out/'result.json').read_text());e=json.loads((out/'extended-result.json').read_text());r=json.loads((out/'runtime-result.json').read_text());assert all(c['exit_code']==0 for c in b['commands']+e['commands']);assert all(c['passed'] for c in r)
sha=b['base_sha'];api='https://api.github.com/repos/williechen/rust_ai_chat/'
for name,path in [('branch','branches/main'),('workflows',f'actions/runs?head_sha={sha}&event=push&per_page=100'),('checks',f'commits/{sha}/check-runs?per_page=100')]:
 request=urllib.request.Request(api+path,headers={'User-Agent':'actual-local-day12-validation','Accept':'application/vnd.github+json'})
 with urllib.request.urlopen(request,timeout=30) as res:data=json.load(res)
 (out/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n')
ws=json.loads((out/'workflows.json').read_text())['workflow_runs'];cs=json.loads((out/'checks.json').read_text())['check_runs'];branch=json.loads((out/'branch.json').read_text())['commit']['sha']
# A rerun replaces prior attempts for the same workflow/check name.
latest={}
for w in sorted(ws,key=lambda x:x['updated_at']):latest[w['name']]=w
ws=list(latest.values());latest={}
for c in sorted(cs,key=lambda x:x['id']):latest[c['name']]=c
cs=list(latest.values());state='success' if ws and cs and all(x['conclusion']=='success' for x in ws+cs) else ('failed' if any(x['conclusion']=='failure' for x in ws+cs) else ('pending' if any(x['status']!='completed' for x in ws+cs) else 'failed_or_missing'))
summary={'checked_at':datetime.datetime.now(zoneinfo.ZoneInfo('Asia/Taipei')).isoformat(),'reference_sha':sha,'latest_main_sha':branch,'latest_sha_matches':sha==branch,'gate':state,'workflow_success':sum(x['conclusion']=='success' for x in ws),'workflow_total':len(ws),'check_success':sum(x['conclusion']=='success' for x in cs),'check_total':len(cs),'workflows':[{'name':x['name'],'status':x['status'],'conclusion':x['conclusion'],'url':x['html_url']} for x in ws],'checks':[{'name':x['name'],'status':x['status'],'conclusion':x['conclusion'],'url':x['html_url']} for x in cs],'checked_after_local':True}
(out/'remote-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False))
for w in ws:
 if w['conclusion']=='failure':
  request=urllib.request.Request(api+f"actions/runs/{w['id']}/jobs?per_page=100",headers={'User-Agent':'actual-local-day12-validation','Accept':'application/vnd.github+json'})
  with urllib.request.urlopen(request,timeout=30) as res:jobs=json.load(res)
  (out/(f"jobs-{w['id']}.json")).write_text(json.dumps(jobs,indent=2)+'\n')
  print('FAILED JOBS',[(j['name'],[s['name'] for s in j['steps'] if s['conclusion']=='failure']) for j in jobs['jobs'] if j['conclusion']=='failure'])
