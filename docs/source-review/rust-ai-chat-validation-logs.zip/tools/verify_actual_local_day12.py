from pathlib import Path
import os,subprocess,json,datetime,zoneinfo,hashlib,shutil,time,re
root=Path(__file__).resolve().parent.parent;actual=Path('/home/willie/Documents/rust_ai_chat');stamp=datetime.datetime.now(zoneinfo.ZoneInfo('Asia/Taipei')).strftime('%Y%m%d-%H%M%S');out=root/'evidence'/('local-day12-'+stamp);src=root/'work'/('actual-day12-'+stamp);out.mkdir();src.mkdir()
(root/'evidence/current-day12-verification-path.txt').write_text(str(out)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=actual)
# 以working tree bytes（含未提交與非忽略的新source）建立隔離副本，不用git archive HEAD。
files=[p for p in git('ls-files','--cached','--others','--exclude-standard','-z').decode().split('\0') if p];manifest=[]
for name in files:
 p=actual/name
 if not p.is_file():continue
 if p.name.startswith('.env') or p.suffix in ['.sqlite','.sqlite3','.db'] or any(x in p.parts for x in ['target','node_modules','gen','dist']):continue
 data=p.read_bytes();dest=src/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);manifest.append({'path':name,'sha256':hashlib.sha256(data).hexdigest()})
sha=git('rev-parse','HEAD').decode().strip();status=git('status','--porcelain').decode();diff=git('diff','--binary');(out/'working-tree.patch').write_bytes(diff);(out/'file-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
report={'local_path':str(actual),'source_kind':'actual local working tree including uncommitted Day12 edits','base_sha':sha,'git_status':status,'copied_source':str(src),'commands':[],'status':'running','source_modified_by_verifier':False,'paid_ai_executed':False,'github_ci_covers_this_worktree':False};env=os.environ.copy()
for k in list(env):
 if any(x in k.upper() for x in ['OPENAI','API_KEY','DATABASE','PET_AUTHORIZED_ROOT']):env.pop(k,None)
env.update(CARGO_TARGET_DIR=str(root/'work/validation-target'),CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never',NO_COLOR='true',DATABASE_URL='sqlite::memory:',DATABASE_SQLITE_URL='sqlite::memory:')
commands=[('format',['cargo','fmt','--all','--','--check']),('chat-protocol',['cargo','test','--offline','--locked','-p','shared']),('chat-ws',['cargo','test','--offline','--locked','-p','server']),('pet-roam',['cargo','test','--offline','--locked','-p','desktop-pet']),('analytics-http',['cargo','test','--offline','--locked','-p','stats-server'])]
for name,cmd in commands:
 print('START '+name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:proc=subprocess.run(cmd,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT)
 report['commands'].append({'name':name,'command':cmd,'exit_code':proc.returncode,'seconds':round(time.monotonic()-start,2),'log':name+'.log'});(out/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('FINISH '+name+' exit='+str(proc.returncode),flush=True)
 if proc.returncode:print('\n'.join((out/(name+'.log')).read_text().splitlines()[-17:]),flush=True)
for f in manifest:assert hashlib.sha256((actual/f['path']).read_bytes()).hexdigest()==f['sha256'],('Source changed during validation',f['path'])
assert git('status','--porcelain').decode()==status
report['status']='completed';report['local_day12_gate']='passed' if all(c['exit_code']==0 for c in report['commands']) else 'failed';report['original_source_preserved']=True;(out/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('DAY12 COMPLETE '+str(out),flush=True)
