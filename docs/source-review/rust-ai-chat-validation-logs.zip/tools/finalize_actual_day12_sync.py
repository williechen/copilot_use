from pathlib import Path
import json,re,hashlib,datetime,zoneinfo,zipfile,subprocess
root=Path(__file__).resolve().parent.parent;repo=root/'work/copilot_use';docs=repo/'docs';out=Path((root/'evidence/current-day12-verification-path.txt').read_text().strip());d=docs/'teaching/current';m=json.loads((d/'manifest.json').read_text());pages=json.loads((root/'evidence/formal-article-sync/pages.json').read_text());now=datetime.datetime.now(zoneinfo.ZoneInfo('Asia/Taipei')).isoformat()
for page,entry in zip(pages[1:],m['articles']):
 content=page['text'].split('<content>\n',1)[1].split('\n</content>',1)[0]+'\n';p=repo/entry['path'];old=p.read_text()
 assert re.findall(r'```[\s\S]*?```',old)==re.findall(r'```[\s\S]*?```',content)
 assert len(re.findall(r'^## [1-4]\. ',content,re.M))==4;p.write_text(content)
 entry.update(synced_content_sha256=hashlib.sha256(content.encode()).hexdigest(),notion_readback_verified=True)
m.update(synced_at=now);(d/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
verification={'title_parent_preserved':True,'all_original_code_blocks_preserved':True,'four_sections':True,'pages':[{'id':p['id'],'title':p['title'],'url':p['url'],'content_sha256':hashlib.sha256(p['text'].encode()).hexdigest()} for p in pages]}
(root/'evidence/formal-article-sync/readback-verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n');(out/'article-readback-verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n')
p=docs/'learning-state.json';state=json.loads(p.read_text());remote=state['reference_validation']['remote_ci'];state['reference_validation']['remote_ci']={k:v for k,v in remote.items() if k not in ['workflows','checks']};state['reference_validation']['remote_ci']['failed_job']='https://github.com/williechen/rust_ai_chat/actions/runs/38745289793/job/116457220577';state['article_sync']['checked_at']=now;p.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n')
p=docs/'source-review/rust-ai-chat-validation.json';report=json.loads(p.read_text());report['post_validation_worktree_observation']={'checked_at':now,'status':subprocess.check_output(['git','status','--porcelain'],cwd='/home/willie/Documents/rust_ai_chat',text=True),'scope':'persistence.yml edited by user after source snapshot; not included in a57e532 evidence; does not alter test.yml job env'};report['ci_remediation']='DAY12_CI_ENVIRONMENT.md';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(out/'summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
p=docs/'source-review/RUST_AI_CHAT_STATUS.md';s=p.read_text().replace('乾淨提交','驗證取樣時的乾淨提交');s+='\n[CI 測試環境診斷與待套用設定](DAY12_CI_ENVIRONMENT.md)。驗證取樣後本地 `persistence.yml` 出現未提交調整，未納入上述 SHA 的驗證／CI；其 env 不會作用到另一個 workflow 的 test-workspace。\n';p.write_text(s);(out/'REPORT.md').write_text(s)
with zipfile.ZipFile(docs/'source-review/rust-ai-chat-validation-logs.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.iterdir()):
  if p.is_file() and p.suffix in ['.json','.log','.md','.patch']:z.write(p,p.name)
 for name in ['verify_actual_local_day12.py','verify_day12_extended.py','check_actual_remote.py','finalize_actual_day12_sync.py']:z.write(root/'evidence'/name,'tools/'+name)
for entry in m['articles']:
 assert hashlib.sha256((repo/entry['path']).read_bytes()).hexdigest()==entry['synced_content_sha256']
assert state['next_day']=={'chat':13,'pet':13,'analytics':13};assert state['last_full_comparison'] is None;assert state['fixed_tag_sha']=='22b44f33b9e2c9edb0fb398fb9bff3efd57b00ee'
changed=subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines();assert all(x=='README.md' or x.startswith('docs/') for x in changed)
print('Verified Notion/GitHub mirrors, hashes, 4 sections, preserved code; no Day/stage/tag/weekly changes')
