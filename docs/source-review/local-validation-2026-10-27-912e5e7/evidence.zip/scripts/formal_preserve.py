from pathlib import Path
import hashlib,json,subprocess
out=Path('outputs/formal-validation-912e5e7');base=json.loads((out/'baseline.json').read_text());source=Path('work/formal-validation-912e5e7/source');repo=Path('/home/willie/Documents/rust_ai_ring');docs=Path('/home/willie/Documents/copilot_use')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot(p):return {str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file()}
after=snapshot(source);modified=[f for f,h in base['isolated_source'].items() if after.get(f)!=h];generated={f:h for f,h in after.items() if f not in base['isolated_source']}
expected={'pet_apps/pet_server/gen/schemas/'+x for x in ['linux-schema.json','acl-manifests.json','capabilities.json','desktop-schema.json']}
assert not modified;assert set(generated)==expected
for root,key in [(repo,'original_product'),(docs,'original_docs')]:
 assert all((root/f).exists() and sha(root/f)==h for f,h in base[key].items())
 assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root).strip()
assert all(Path(f).exists() and sha(Path(f))==h for f,h in base['protected_local_data'].items())
rows=json.loads((out/'commands.json').read_text());stop=next(r for r in rows if r['label']=='pg-stop');assert stop['exit_code']==0
report={'source_sha':base['source_sha'],'docs_parent':base['docs_sha'],'original_product_unchanged':True,'original_product_worktree_clean':True,'original_docs_unchanged_before_documentation_update':True,'isolated_tracked_source_unchanged':True,'patches_applied':False,'env_and_database_hashes_unchanged':True,'postgres_stopped':True,'generated_in_isolation_only':generated,'initial_runner_exit_code':1,'initial_runner_failure_reason':'Post-test preservation assertion rejected four newly generated Tauri schema files; all test/check commands had already completed. Classified and rechecked generated-only additions without rerunning tests.','preservation_recheck_exit_code':0}
(out/'preservation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
