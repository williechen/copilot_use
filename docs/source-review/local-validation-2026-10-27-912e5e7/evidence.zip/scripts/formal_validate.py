from pathlib import Path
import subprocess,os,json,time,signal,shlex,tarfile,io,hashlib,tempfile,shutil
base=Path.cwd();out=base/'outputs/formal-validation-912e5e7';out.mkdir(exist_ok=False);scratch=base/'work/formal-validation-912e5e7';scratch.mkdir(exist_ok=False)
repo=Path('/home/willie/Documents/rust_ai_ring');docs=Path('/home/willie/Documents/copilot_use');root=scratch/'source';root.mkdir();records=[]
def git(args,p=repo):return subprocess.check_output(['git',*args],cwd=p,text=True).strip()
source_sha=git(['rev-parse','HEAD']);assert source_sha=='912e5e77d8e3d2e24f0e9d804f28d86ae768c1d4'
assert not git(['status','--porcelain=v1','--untracked-files=all']);assert not git(['status','--porcelain=v1','--untracked-files=all'],docs)
archive=subprocess.check_output(['git','archive','--format=tar',source_sha],cwd=repo)
with tarfile.open(fileobj=io.BytesIO(archive)) as t:t.extractall(root,filter='data')
def hashes(p, tracked=False):
 paths=[p/x for x in git(['ls-files'],p).splitlines()] if tracked else list(p.rglob('*'))
 return {str(x.relative_to(p)):hashlib.sha256(x.read_bytes()).hexdigest() for x in paths if x.is_file() and '.git' not in x.parts}
baseline={'source_sha':source_sha,'docs_sha':git(['rev-parse','HEAD'],docs),'original_product':hashes(repo,True),'original_docs':hashes(docs,True),'isolated_source':hashes(root),'protected_local_data':{str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in repo.rglob('*') if x.is_file() and '.git' not in x.parts and (x.name=='.env' or x.suffix in ['.db','.sqlite','.sqlite3'])}}
(out/'baseline.json').write_text(json.dumps(baseline,indent=2))
env=os.environ.copy()
for key in list(env):
 if any(x in key for x in ['DATABASE_URL','ANALYTICS_CHAT_TOKEN','ANALYTICS_PET_TOKEN']) or key.startswith('PG'):env.pop(key)
env.update(CARGO_TARGET_DIR=str(base/'work/cargo-target'),CARGO_TERM_COLOR='never',CARGO_NET_RETRY='0',CARGO_HTTP_TIMEOUT='30',DATABASE_URL='sqlite::memory:',TMPDIR=str(scratch/'test-tmp'))
(scratch/'test-tmp').mkdir()
(out/'environment.json').write_text(json.dumps({key:env[key] for key in ['CARGO_TARGET_DIR','CARGO_TERM_COLOR','CARGO_NET_RETRY','CARGO_HTTP_TIMEOUT','DATABASE_URL','TMPDIR']},indent=2))
def run(label,args,cwd=root,override=None,timeout=600):
 e=env.copy();e.update(override or {});a=out/(label+'.stdout.txt');b=out/(label+'.stderr.txt');start=time.time();timed=False
 with a.open('w') as so,b.open('w') as se:
  try:
   p=subprocess.Popen(args,cwd=cwd,env=e,stdout=so,stderr=se,start_new_session=True)
   try:code=p.wait(timeout)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGTERM);p.wait();code=124;timed=True
  except FileNotFoundError as ex:se.write(str(ex));code=127
 row=dict(label=label,command=shlex.join(map(str,args)),cwd=str(cwd),environment_overrides=override or {},exit_code=code,timeout=timed,seconds=round(time.time()-start,2),stdout=a.name,stderr=b.name,stdout_summary=a.read_text()[-3000:],stderr_summary=b.read_text()[-3000:]);records.append(row);(out/'commands.json').write_text(json.dumps(records,indent=2,ensure_ascii=False));print(label,code,row['stderr_summary'][-500:],flush=True);return code
for label,args in [('rustc-version',['rustc','--version']),('cargo-version',['cargo','--version']),('node-version',['node','--version']),('rust-targets',['rustup','target','list','--installed'])]:run(label,args)
for w in ['chat_apps','pet_apps','analytics_apps','crates']:run('metadata-'+w,['cargo','metadata','--locked','--no-deps','--format-version','1','--manifest-path',w+'/Cargo.toml'])
run('test-pet-node',['node','--test'],root/'pet_apps/pet_ui')
run('test-chat',['cargo','test','--locked','--manifest-path','chat_apps/Cargo.toml','--workspace','--features','chat-server/ssr,chat-ui/ssr','--no-fail-fast'])
run('test-pet',['cargo','test','--locked','--manifest-path','pet_apps/Cargo.toml','--workspace','--exclude','pet-ui','--no-fail-fast'])
run('test-analytics-default',['cargo','test','--locked','--manifest-path','analytics_apps/Cargo.toml','--workspace','--no-fail-fast'])
run('test-crates',['cargo','test','--locked','--manifest-path','crates/Cargo.toml','--workspace','--no-fail-fast'])
pgbin=Path('/usr/lib/postgresql/18/bin');pgdata=scratch/'pgdata';socket=Path(tempfile.mkdtemp(prefix='codex-verify-pg-'));socket.chmod(0o700);started=False
try:
 init=run('pg-initdb',[str(pgbin/'initdb'),'-D',str(pgdata),'-U','codex_validation','-A','trust','--no-locale','--encoding=UTF8'])
 if init==0:
  started=run('pg-start',[str(pgbin/'pg_ctl'),'-D',str(pgdata),'-l',str(out/'postgres.log'),'-o',f"-F -k {socket} -h '' -p 55437",'-w','start'])==0
 if started:
  url=f'postgresql://codex_validation@localhost:55437/postgres?host={socket}'
  override={'DATABASE_URL':url,'ANALYTICS_TEST_DATABASE_URL':url,'ANALYTICS_DATABASE_URL':url}
  run('pg-identity',['psql',url,'-X','-v','ON_ERROR_STOP=1','-c','SELECT version(), current_user, current_database();'],override=override)
  run('test-analytics-postgres',['cargo','test','--locked','--manifest-path','analytics_apps/Cargo.toml','-p','analytics-server','-p','analytics-persistence','--features','analytics-server/postgres-integration,analytics-persistence/postgres-integration','--no-fail-fast','--','--include-ignored'],override=override)
 else:records.append({'label':'test-analytics-postgres','exit_code':None,'reason':'Dedicated temporary PostgreSQL startup failed; no existing database used.'})
finally:
 if started:run('pg-stop',[str(pgbin/'pg_ctl'),'-D',str(pgdata),'-m','fast','-w','stop'])
 if not list(socket.iterdir()):socket.rmdir()
run('check-chat-wasm',['cargo','check','--locked','--manifest-path','chat_apps/Cargo.toml','-p','chat-ui','--features','hydrate','--target','wasm32-unknown-unknown'])
run('check-pet-wasm',['cargo','check','--locked','--manifest-path','pet_apps/Cargo.toml','-p','pet-ui','--target','wasm32-unknown-unknown'])
assert hashes(repo,True)==baseline['original_product'];assert not git(['status','--porcelain=v1','--untracked-files=all'])
assert hashes(docs,True)==baseline['original_docs'];assert hashes(root)==baseline['isolated_source']
assert all(Path(p).exists() and hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in baseline['protected_local_data'].items())
(out/'preservation.json').write_text(json.dumps({'original_product_unchanged':True,'original_docs_unchanged_before_documentation_update':True,'isolated_source_unchanged':True,'env_and_database_hashes_unchanged':True,'source_sha':source_sha,'patches_applied':False,'postgres_stopped':not started or records[-3 if False else 0].get('nothing',True)},indent=2))
print('VALIDATION COMPLETE — no source or test fixes applied',flush=True)
