from pathlib import Path
import subprocess,os,json,time
b=Path(__file__).resolve().parent;env=os.environ.copy();env.update(CARGO_TARGET_DIR='/tmp/day36-verify-target',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',DATABASE_URL='postgres://willie@127.0.0.1:55436/postgres')
checks=[('chat_apps','red-chat','test --locked --offline -p chat-server --features ssr day36_'),('pet_apps','red-pet','test --locked --offline -p pet-persistence day36_restore_adapter_tests'),('analytics_apps','red-analytics','test --locked --offline -p analytics-server --features postgres-integration day35_live_router_exposes_exact_kind_with_source_acl')];res=[]
for ws,n,c in checks:
 print('START',n,flush=True)
 with (b/'logs'/f'{n}.log').open('w') as f:r=subprocess.run(['cargo']+c.split(),cwd=b/'teaching-base'/ws,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 res.append(dict(workspace=ws,name=n,command='cargo '+c,exit=r.returncode));(b/'red-results.json').write_text(json.dumps(res,indent=2));print('END',n,r.returncode,flush=True)
