from pathlib import Path
import subprocess,os,json,time
base=Path(__file__).resolve().parent
root=next(base.glob('rust_ai_ring-*'))
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/tmp/day36-verify-target',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',DATABASE_URL='postgres://willie@127.0.0.1:55436/postgres')
checks=[
('chat_apps','chat-full','test --locked --offline -p chat-server --features ssr'),
('chat_apps','chat-ui-ssr','test --locked --offline -p chat-ui --features ssr'),
('chat_apps','chat-wasm','check --locked --offline -p chat-ui --features hydrate --target wasm32-unknown-unknown'),
('chat_apps','chat-build','build --locked --offline -p chat-server --features ssr'),
('pet_apps','pet-adapter','test --locked --offline -p pet-persistence day36_restore_adapter_tests'),
('pet_apps','pet-day36','test --locked --offline -p pet-server day36_restart_restores_all_uncaged_not_just_selected'),
('pet_apps','pet-full','test --locked --offline -p pet-server --all-targets'),
('pet_apps','pet-wasm','check --locked --offline -p pet-ui --target wasm32-unknown-unknown'),
('analytics_apps','analytics-day36','test --locked --offline -p analytics-server --features postgres-integration day36_'),
('analytics_apps','analytics-kind','test --locked --offline -p analytics-server --features postgres-integration source_kind_summary_tests'),
('analytics_apps','analytics-pg-full','test --locked --offline -p analytics-server --features postgres-integration'),
('analytics_apps','analytics-all-targets','test --locked --offline -p analytics-server --all-targets'),
('analytics_apps','analytics-check','check --locked --offline -p analytics-server --all-targets'),
]
results=[]
for ws,name,cmd in checks:
 print('START',name,flush=True);start=time.time()
 with (base/'logs'/f'{name}.log').open('w') as f:
  try:r=subprocess.run(['cargo']+cmd.split(),cwd=root/ws,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=900);code=r.returncode
  except subprocess.TimeoutExpired:code=124
 results.append(dict(workspace=ws,name=name,command='cargo '+cmd,exit=code,seconds=round(time.time()-start,2)))
 (base/'checks.json').write_text(json.dumps(results,indent=2));print('END',name,code,flush=True)
