# Day36 TDD 實際驗證報告

**結論：最新 main 已含三案 Green；本次在隔離原始碼快照實跑測試，不能再沿用「目前程式未套用」的說法。三案尚未完成完整產品驗收。**

驗證日期：2026-10-25（Asia/Taipei）。遠端 main 在開始及結束時 SHA 相同。

| 對象 | 精確 SHA / 狀態 |
|---|---|
| rust_ai_ring 遠端 main | `5c713553daee4055738239f047d6c774fcc7a7a1`，提交訊息 `Phase2 day36` |
| copilot_use 遠端 main | `fcf4ecfc06292e68a11b56156fda34a9960fd5d6` |
| 教學原始對照來源 | `61ed5930bd9ff38e0d5822eea2983121001d8422` |
| 本地 rust_ai_ring HEAD | `3aeab095f27aa3fc7f1b76995e0d059a94c5dd4d`，原有 chat_ui 修改及 Pet dist 修改／刪除 |
| 本地 copilot_use HEAD | `fd426c68facdfdfd97616cf04a8bbc6badfe02cc`，原有未追蹤 `docs/teaching/pending/` |

兩個本地目錄為 `/home/willie/Documents/rust_ai_ring`、`/home/willie/Documents/copilot_use`。沒有 fetch、checkout、reset、commit、push，也未寫入其 target。前後 HEAD、porcelain status、tracked diff SHA256 完全相同。

為遵守「不要修改任何 repo」，採用 GitHub 精確 SHA archive 解出的無 `.git` 隔離快照，沒有以 `git worktree add` 改動原 repo 的 Git metadata。最新快照內的所有原始追蹤檔也已逐一與 archive 比較，沒有改動。Green 已存在於 main，沒有重複貼入；只有另一份 `61ed5930` 快照加入教學 Red。

**文件、Cargo 與呼叫端核對**

Chat、Pet r1/r2、Analytics 四篇文章的 Git blob SHA 與 SHA256 均符合 delivery-audit。七個首頁與三個 ENTRY 的 Day36 相對連結均存在；learning-state / manifest 的 next_day 都是 Chat/Pet/Analytics=37。這些只證明文件交付一致。未改 next_day、last_full_comparison 或任何遠端文件。

四個獨立 workspace 為 `chat_apps`、`pet_apps`、`analytics_apps`、`crates`，沒有以 repo 根目錄當單一 workspace。全部 metadata 與 fmt check 通過。相較教學原始來源，所有 Cargo.toml 及四份 Cargo.lock 皆未變更，lock blob 依序為：

```text
Chat      384bcb23a13bc0f4e876f29e3037f2181ebbc3d5
Pet       7097f943da5c88be851979cec74641fa35e6e613
Analytics 44abb16f1ec3f74fa181c69d46e8bd984a090f21
Crates    c5ec8079981d59244ce5482258424cd8ff57f9a3
```

- Chat：`chat_ui/src/chat_socket.rs` → `/ws/{room_id}` → guarded_ws 的 SqlitePool Extension 與 require_member → ws_handler → handle_socket 的 tick / incoming / broadcast 三處 Session 重查 → active_member → SQLite。`AppState::new` 不需更動；logout 仍刪除同一 mbr_session。
- Pet：UI bridge → Tauri → PetStore；啟動 setup 已改 `store.uncaged()`，經 pet_persistence::list_uncaged 查詢 local-owner、未回籠資料，再逐隻呼叫 pet_windows::open。active slot 保留給控制台選取。open 以 UUID label 建窗，失敗清除該 Runtime，setup 迴圈繼續。
- Analytics：main → password_login::build → 正式 exact-kind route → require_query_session → 原 session（期限、帳號 active、admin、密碼 fingerprint、首次改密碼）→ SQLx 聚合 → renewed Cookie。POST ingestion 仍走來源 token。修改 handler 的 Response 型別及舊測試 caller 已一併接通，沒有拿 cfg(test) 歷史 helper 當正式路由。

**實際環境與命令**

`rustc 1.99.1 (58cf8f9c3 2026-10-13)`；`cargo 1.99.1 (5f94df478 2026-08-27)`。已安裝 native 及 wasm32-unknown-unknown target。下列 cargo 命令在對應隔離 workspace 執行，全部沿用 lock 並加 `--offline`，沒有升級依賴。

```bash
export CARGO_TARGET_DIR=/tmp/day36-verify-target
export CARGO_BUILD_JOBS=2
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
export CARGO_INCREMENTAL=0
export DATABASE_URL=postgres://willie@127.0.0.1:55436/postgres
```

停用 debug info / incremental 是控制隔離編譯磁碟用量；這不是 release 測試或所有 profile 驗證。獨立 PostgreSQL 叢集由 `/usr/lib/postgresql/18/bin/initdb -D work/pg-data --auth=trust --no-locale` 建立，再用 `pg_ctl ... -o "-h 127.0.0.1 -p 55436 -k /tmp" start` 啟動。實測為 `18.6 (Ubuntu 18.6-1.pgdg26.04+2)`；未使用原有 5432 服務。完成後已關閉本次 55436 叢集。

每個 workspace 都執行：

```bash
cargo metadata --locked --offline --format-version 1 --no-deps
cargo fmt --all -- --check
```

| 工作目錄 | 實際執行命令 | 最終結果 | log |
|---|---|---|---|
| chat_apps | `cargo test --locked --offline -p chat-server --features ssr day36_` | 2 passed | chat-day36.log |
| chat_apps | `cargo test --locked --offline -p chat-server --features ssr` | 31 passed / 0 failed / 0 ignored | chat-full.log |
| chat_apps | `cargo test --locked --offline -p chat-ui --features ssr` | 14 passed / 0 failed / 0 ignored | chat-ui-ssr.log |
| chat_apps | `cargo check --locked --offline -p chat-ui --features hydrate --target wasm32-unknown-unknown` | exit 0 | chat-wasm.log |
| chat_apps | `cargo build --locked --offline -p chat-server --features ssr` | exit 0 | chat-build.log |
| pet_apps | `cargo test --locked --offline -p pet-persistence day36_restore_adapter_tests` | 1 passed / 0 failed / 0 ignored | pet-adapter.log |
| pet_apps | `cargo test --locked --offline -p pet-server day36_restart_restores_all_uncaged_not_just_selected` | 1 passed / 0 failed / 0 ignored | pet-day36.log |
| pet_apps | `cargo test --locked --offline -p pet-server --all-targets` | 54 passed / 0 failed / 0 ignored | pet-full.log |
| pet_apps | `cargo check --locked --offline -p pet-ui --target wasm32-unknown-unknown` | exit 0 | pet-wasm.log |
| analytics_apps | `cargo test --locked --offline -p analytics-server --features postgres-integration day36_` | 2 passed / 0 failed / 0 ignored | analytics-day36.log |
| analytics_apps | `cargo test --locked --offline -p analytics-server --features postgres-integration source_kind_summary_tests` | 2 passed / 0 failed / 0 ignored | analytics-kind.log |
| analytics_apps | `cargo test --locked --offline -p analytics-server --features postgres-integration` | 42 passed / 0 failed / 1 ignored | analytics-pg-full.log |
| analytics_apps | `cargo test --locked --offline -p analytics-server --all-targets` | 27 passed / 0 failed / 1 ignored | analytics-all-targets.log |
| analytics_apps | `cargo check --locked --offline -p analytics-server --all-targets` | exit 0 | analytics-check.log |
| analytics_apps | `cargo test --locked --offline -p analytics-server --features postgres-integration admin::tests::login_query_postgres_and_logout_flow -- --ignored` | 1 passed；獨立叢集內執行 | analytics-ignored.log |
| analytics_apps | `cargo build --locked --offline -p analytics-server` | exit 0 | analytics-build.log |

Analytics feature 全套為 42 passed / 1 ignored；另外明確執行略過項為 1 passed。該項是歷史 admin helper 的測試，不能替代本日正式路由。表內重複執行的 Day36／全套測試不重複累加為不同測試。

**教學原始來源的 Red**

在另一份 `61ed5930` archive 只加入教學指定測試／斷言，沒有加入 Green：

| workspace | 實際命令 | 結果 |
|---|---|---|
| chat_apps | `cargo test --locked --offline -p chat-server --features ssr day36_` | exit 101：E0432，socket_session_active 不存在；符合編譯 Red |
| pet_apps | `cargo test --locked --offline -p pet-persistence day36_restore_adapter_tests` | exit 101：E0432，list_uncaged 不存在；符合編譯 Red |
| analytics_apps | `cargo test --locked --offline -p analytics-server --features postgres-integration day35_live_router_exposes_exact_kind_with_source_acl` | exit 101：實際 200，預期 401；符合行為 Red |

這是本次在隔離副本重現的 Red → 最新 main Green，不是聲稱原提交作者曾經執行過 TDD。Pet 的 Store 缺符號 Red 沒有另外跑；已跑 adapter Red 與最新 Store Green。

**Chat：真實 HTTP / WebSocket 補充驗證**

命令：`python3 work/chat_ws_probe.py`。直接啟動本次由精確 SHA 編譯的 chat-server，使用獨立 SQLite，由 HTTP 註冊與登入取得 Cookie；兩個不同帳號同房連線，使用真正 HTTP Upgrade／masked WS frame。不是 oneshot 模擬，也不是瀏覽器測試。

| 情境 | 結果 | 撤銷完成後至 Close（秒） |
|---|---|---|
| logout-idle | passed | 0.9756 |
| logout-send | passed | 0.0008 |
| expiry | passed | 1.0006 |
| disabled | passed | 0.9916 |
| logout-broadcast | passed | 0.0421 |

登出後立即送訊息未增加 messages；無效 A 不收到有效 B 的廣播，B 的訊息正常寫入且 B 可繼續使用；閒置、直接注入到期、停用帳號時均 Close。後兩項用隔離 SQLite 改資料作故障情境，登入／登出走實際 HTTP。本次 Python SQLite client 實測版本為 3.46.1；未據此推定 SQLx 連結的 SQLite engine 版本。

教學「≤1 秒」不能視為硬性保證：修正計時後，expiry 情境從 DB commit 完成起量到 Close 為 1.0006 秒；最初計時還包含 HTTP 登出往返，原數值不得當作純撤銷延遲。程式每秒輪詢且等待 DB／socket I/O，沒有硬性上界。此測試只做單次各情境，未覆蓋高負載或競態。

**Analytics：真實 HTTP / PostgreSQL 補充驗證**

命令：`python3 work/analytics_http_probe.py`。啟動本次編譯的 analytics-server，使用獨立 analytics_probe_final DB、正式 migration、正式 password_login::build。測試包含：

- 無 Cookie、只有 Chat／Pet 來源 token 查詢：401。
- 真登入預設 admin 後首次改密碼前：403；走 HTTP change-password 成功，舊 Cookie：401；重新登入後可查詢。
- 用機器 token 攝取：201；重送同 event：200；錯來源 token：401。
- 有效人員 Cookie 查 exact-kind：200、精確 total=1、Set-Cookie；無效來源／類型：400。
- 在隔離 DB 注入過期、停用、密碼 fingerprint 改變：401；HTTP logout 後重試：401。

共 22 個 HTTP 狀態斷言通過（含重複登入），另有 JSON 與 Set-Cookie 斷言。不是 22 項獨立產品功能驗收。PostgreSQL migration 成功資訊見 analytics-db-evidence.txt。沒有量測產品所有 DB 故障情境；正式 API 的角色／來源 ACL 未實作。

**剩餘缺口與判定**

| 專案 | 已驗證 | 尚不能宣稱 |
|---|---|---|
| Chat | 最新 Green 編譯、SQLite helper、真 HTTP 登入／登出、WS 撤銷／阻止後續寫入 | Session 檢查與 message INSERT 同交易原子撤銷、負載下延遲上界、逐房 ACL、作者／歷史訊息、瀏覽器 UI 驗收 |
| Pet | SQLx adapter、重建 Store 清單、native server 測試及啟動 caller 編譯、WASM check | 真正結束／重啟 Tauri 程序後多窗恢復、單隻建窗失敗注入、DB 旗標與視窗一致性、動態漫遊、單幀單圖及安裝包 dist |
| Analytics | 人員 Session／來源 token 邊界、正式 route + PG、真 HTTP 改密碼／登出、攝取去重 | 角色／來源 ACL、SSE 撤銷、完整瀏覽器／Dashboard UI、全面安全與產品驗收 |

Pet Day36 測試實際只是同一 pool 重建 PetStore，沒有重開程序；adapter 測試的 fixture 只有 local-owner，雖 SQL 有 owner filter，尚無異 owner fixture 的排除斷言。Chat 新的兩項 Day36 單測只直接呼叫 helper，真 WS 的證據來自本次額外探測。Analytics Day36 原測試只刪 session，停用／到期／改密碼由本次額外 HTTP 探測補足部分證據。

本次沒有全面重新核對文章宣稱的「所有官方最新穩定版本」，已核實的是實際 toolchain、workspace、lock 與 PG runtime。沒有把 docs.rs 的 latest 字樣或文件版本表當本機已安裝證據。沒有執行遠端 CI。

**原始失敗與復原**

首次 Pet native 編譯撞到 `/tmp` 使用者配額（os error 122），後續幾條命令也因此無法編譯。保留於 first-attempt-logs 與 checks-first-attempt.json；將本次自建快取的部分 rlib／WASM 移至 /dev/shm 後重跑全部受影響命令，均通過。沒有挪動、刪除或共用本地 repo 的 target。

本次探測腳本亦有兩次 fixture 錯誤並已修正：Chat 初次精細計時版本把 B 與停用的 A 設為同帳號，B 被關閉是正確行為，最後改為兩個獨立帳號；Analytics 初版健康檢查誤用 /health，正式路由為 /healthz，修正後全部 HTTP 斷言通過。原始錯誤 log 保留，未算成產品缺陷或通過證據。

最終判定：**三案 Green 已存在且本次已執行相關測試；Chat 與 Analytics 增加真實通訊驗證。三案仍未完成完整產品驗收。所有 repo 保持本次開始時原狀。**
