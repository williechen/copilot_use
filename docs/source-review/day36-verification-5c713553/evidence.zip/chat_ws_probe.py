import socket,base64,os,hashlib,struct,json,time,sqlite3,subprocess,requests
from pathlib import Path
base=Path(__file__).resolve().parent;root=next(base.glob('rust_ai_ring-*'));db=base/'chat-probe-final.sqlite';db.touch()
url='http://127.0.0.1:3000';env=os.environ.copy();env['CHAT_DATABASE_URL']='sqlite://'+str(db)
class WS:
 def __init__(self,cookie):
  self.s=socket.create_connection(('127.0.0.1',3000),timeout=3);self.s.settimeout(3)
  key=base64.b64encode(os.urandom(16)).decode();self.s.sendall((f'GET /ws/probe-room HTTP/1.1\r\nHost: 127.0.0.1:3000\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: {key}\r\nCookie: {cookie}\r\n\r\n').encode());h=b''
  while not h.endswith(b'\r\n\r\n'):h+=self.s.recv(1)
  assert b'101 Switching Protocols' in h,h
  assert base64.b64encode(hashlib.sha1((key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest()) in h
 def send(self,obj):
  p=json.dumps(obj).encode();mask=os.urandom(4);n=len(p);head=bytes([0x81,0x80|n]) if n<126 else bytes([0x81,0x80|126])+struct.pack('!H',n)
  self.s.sendall(head+mask+bytes(v^mask[i%4] for i,v in enumerate(p)))
 def exact(self,n):
  b=b''
  while len(b)<n:
   v=self.s.recv(n-len(b));assert v,'EOF';b+=v
  return b
 def recv(self):
  a,b=self.exact(2);n=b&127
  if n==126:n=struct.unpack('!H',self.exact(2))[0]
  if n==127:n=struct.unpack('!Q',self.exact(8))[0]
  return a&15,self.exact(n)
 def close(self):self.s.close()
def login(username="day36_probe"):
 r=requests.post(url+'/login',headers={'Origin':url},data={'username':username,'password':'Day36-probe-pass'},allow_redirects=False);assert r.status_code==303,(r.status_code,r.text)
 return r.headers['Set-Cookie'].split(';')[0]
results=[]
with (base/'logs/chat-probe-server.log').open('w') as log:
 p=subprocess.Popen(['/tmp/day36-verify-target/debug/chat-server'],cwd=root/'chat_apps',env=env,stdout=log,stderr=log)
 try:
  for _ in range(100):
   try:
    if requests.get(url+'/health').status_code==200:break
   except requests.ConnectionError:pass
   if p.poll() is not None:raise RuntimeError('server exited')
   time.sleep(.1)
  else:raise RuntimeError('startup timeout')
  r=requests.post(url+'/signup',headers={'Origin':url},data={'username':'day36_probe','email':'day36@example.invalid','display_name':'Day36','password':'Day36-probe-pass'},allow_redirects=False);assert r.status_code==303,(r.status_code,r.text)
  con=sqlite3.connect(db);con.execute("INSERT INTO rooms VALUES('probe-room','test','Probe','Probe',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)");con.commit()
  r=requests.post(url+'/signup',headers={'Origin':url},data={'username':'day36_control','email':'control@example.invalid','display_name':'Control','password':'Day36-probe-pass'},allow_redirects=False);assert r.status_code==303
  b_cookie=login('day36_control');b=WS(b_cookie)
  for mode in ['logout-idle','logout-send','expiry','disabled','logout-broadcast']:
   con.execute("UPDATE mbr_user SET user_status='active' WHERE user_acnt='day36_probe'");con.commit()
   cookie=login();raw=cookie.split('=',1)[1];token=hashlib.sha256(raw.encode()).hexdigest();a=WS(cookie)
   a.send({'type':'ping'});op,body=a.recv();assert op==1 and json.loads(body)['type']=='pong'
   before=con.execute('SELECT count(*) FROM messages').fetchone()[0];start=time.monotonic()
   if mode.startswith('logout'):
    csrf=hashlib.sha256(('logout:'+raw).encode()).hexdigest();r=requests.post(url+'/logout',headers={'Origin':url,'Cookie':cookie},data={'csrf':csrf},allow_redirects=False);assert r.status_code==303,r.status_code
   elif mode=='expiry':con.execute('UPDATE mbr_session SET expires_at=unixepoch()-1 WHERE token_hash=?',(token,));con.commit()
   else:con.execute("UPDATE mbr_user SET user_status='disabled' WHERE user_acnt='day36_probe'");con.commit()
   revoked_at=time.monotonic()
   if mode=='logout-send':a.send({'type':'send_message','data':{'room_id':'probe-room','content':'must not persist'}})
   if mode=='logout-broadcast':
    b.send({'type':'send_message','data':{'room_id':'probe-room','content':'B survives'}});op,body=b.recv();assert op==1 and json.loads(body)['type']=='message_created'
   op,body=a.recv();elapsed=time.monotonic()-start;after_revocation=time.monotonic()-revoked_at;assert op==8,(mode,op,body)
   count=con.execute('SELECT count(*) FROM messages').fetchone()[0];assert count==before+(mode=='logout-broadcast'),(mode,before,count)
   if mode!='disabled':b.send({'type':'ping'});op,body=b.recv();assert op==1 and json.loads(body)['type']=='pong'
   else:
    con.execute("UPDATE mbr_user SET user_status='active' WHERE user_acnt='day36_probe'");con.commit()
   a.close();results.append(dict(case=mode,passed=True,close_seconds=round(elapsed,4),after_revocation_seconds=round(after_revocation,4),message_count=count))
  b.close();con.close()
 finally:
  p.terminate()
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:p.kill();p.wait()
print(json.dumps(results,indent=2));(base/'chat-ws-results.json').write_text(json.dumps(results,indent=2))
