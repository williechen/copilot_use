from pathlib import Path
import subprocess,os,time,requests,hashlib,json,uuid
base=Path(__file__).resolve().parent;root=next(base.glob('rust_ai_ring-*'));pg='postgres://willie@127.0.0.1:55436/analytics_probe_final';url='http://127.0.0.1:3100';path='/api/v1/events/web_chat/summary/chat.message.persisted';results=[]
def sql(s):return subprocess.check_output(['psql',pg,'-At','-v','ON_ERROR_STOP=1','-c',s],text=True).strip()
def check(name,r,expected):
 assert r.status_code==expected,(name,r.status_code,r.text);results.append({'case':name,'status':r.status_code,'passed':True});return r
def get(cookie=None,p=path,bearer=None):return requests.get(url+p,headers={**({'Cookie':cookie} if cookie else {}),**({'Authorization':'Bearer '+bearer} if bearer else {})},allow_redirects=False)
def login(password):
 r=check('login',requests.post(url+'/login',headers={'Origin':url},data={'username':'admin','password':password},allow_redirects=False),303);return r.headers['Set-Cookie'].split(';')[0]
subprocess.run(['createdb','-h','127.0.0.1','-p','55436','-U','willie','analytics_probe_final'],check=True)
env=os.environ.copy();env.update(ANALYTICS_DATABASE_URL=pg,ANALYTICS_CHAT_TOKEN='probe-chat-token',ANALYTICS_PET_TOKEN='probe-pet-token')
with (base/'logs/analytics-probe-server.log').open('w') as log:
 p=subprocess.Popen(['/tmp/day36-verify-target/debug/analytics-server'],cwd=root/'analytics_apps',env=env,stdout=log,stderr=log)
 try:
  for _ in range(100):
   try:
    if requests.get(url+'/healthz').status_code==200:break
   except requests.ConnectionError:pass
   if p.poll() is not None:raise RuntimeError('server exited')
   time.sleep(.1)
  else:raise RuntimeError('startup timeout')
  check('anonymous',get(),401)
  for t in ['probe-chat-token','probe-pet-token']:check('source-token-only',get(bearer=t),401)
  restricted=login('admin');check('first-password-required',get(restricted),403)
  raw=restricted.split('=',1)[1];csrf=hashlib.sha256(('change-password:'+raw).encode()).hexdigest()
  r=requests.post(url+'/change-password',headers={'Origin':url,'Cookie':restricted},data=dict(current_password='admin',new_password='Day36-probe-password',confirm_password='Day36-probe-password',email='day36@example.invalid',csrf=csrf),allow_redirects=False);check('change-password',r,303);check('old-cookie-after-change',get(restricted),401)
  cookie=login('Day36-probe-password')
  event=dict(schema_version=1,event_id=str(uuid.uuid4()),source_app='web_chat',event_type='chat.message.persisted')
  for name,expected in [('ingest',201),('ingest-deduplicate',200)]:check(name,requests.post(url+'/api/v1/events',headers={'Authorization':'Bearer probe-chat-token'},json=event),expected)
  check('ingest-wrong-source-token',requests.post(url+'/api/v1/events',headers={'Authorization':'Bearer probe-pet-token'},json=event),401)
  r=check('query-person-session',get(cookie),200);assert 'Set-Cookie' in r.headers;rows=r.json();assert len(rows)==1 and rows[0]['total']==1,rows
  check('bad-kind',get(cookie,p='/api/v1/events/web_chat/summary/%20'),400)
  check('bad-source',get(cookie,p='/api/v1/events/unknown/summary/chat.message.persisted'),400)
  raw=cookie.split('=',1)[1];token=hashlib.sha256(raw.encode()).hexdigest()
  sql("UPDATE uac_login_session SET expires_at=0 WHERE token_hash='"+token+"'");check('expired',get(cookie),401)
  cookie=login('Day36-probe-password');sql("UPDATE uac_user SET user_status='disabled' WHERE user_acnt='admin'");check('disabled',get(cookie),401)
  sql("UPDATE uac_user SET user_status='active' WHERE user_acnt='admin'");cookie=login('Day36-probe-password');old_hash=sql("SELECT user_pd FROM uac_user WHERE user_acnt='admin'")
  sql("UPDATE uac_user SET user_pd='probe-password-changed' WHERE user_acnt='admin'");check('credential-fingerprint-changed',get(cookie),401)
  sql("UPDATE uac_user SET user_pd='"+old_hash+"' WHERE user_acnt='admin'");cookie=login('Day36-probe-password');raw=cookie.split('=',1)[1]
  csrf=hashlib.sha256(('logout:'+raw).encode()).hexdigest();r=requests.post(url+'/logout',headers={'Origin':url,'Cookie':cookie},data={'csrf':csrf},allow_redirects=False);check('logout',r,303);check('revoked-after-logout',get(cookie),401)
  (base/'analytics-db-evidence.txt').write_text(sql('SHOW server_version;')+'\n'+sql('SELECT version, success FROM _sqlx_migrations ORDER BY version;')+'\n')
 finally:
  p.terminate()
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:p.kill();p.wait()
print(json.dumps(results,indent=2));(base/'analytics-http-results.json').write_text(json.dumps(results,indent=2))
