from pathlib import Path
import json,re,hashlib,subprocess
root=Path(__file__).resolve().parents[2];out=root/'evidence/full-review'
ast=json.loads((out/'ast-index.json').read_text());groups=json.loads((out/'module-mapping.json').read_text());cov=json.loads((out/'coverage.json').read_text())
assert not cov['parse_errors']
for repo,key in [('reference-rust_ai_chat','reference'),('copilot_use','product')]:
 own={f['path'] for f in ast if f['repo']==repo and not f['vendor']};assigned=[p for g in groups for p in g[key]]
 assert own==set(assigned) and len(assigned)==len(own)
 for f in ast:
  if f['repo']!=repo:continue
  for e in f['entries']:assert 1<=e['line']<=max(1,f['lines']),(f['path'],e)
for f in json.loads((out/'tracked-files.json').read_text()):assert hashlib.sha256((root/f['repo']/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
links=0
for doc in [out/'data-flow-review.md',root/'copilot_use/docs/FULL_SOURCE_REVIEW.md']:
 for path in re.findall(r'\]\(([^)]+)\)',doc.read_text()):
  p=(doc.parent/path.split('#')[0]).resolve();assert p.exists(),p
  if '#L' in path:assert int(path.rsplit('#L',1)[1])<=len(p.read_text().splitlines()),path
  links+=1
assert subprocess.check_output(['git','-C',str(root/'reference-rust_ai_chat'),'status','--porcelain']).decode()==''
assert subprocess.check_output(['git','-C',str(root/'copilot_use'),'rev-parse','v0.1.0^{}']).decode().strip()=='22b44f33b9e2c9edb0fb398fb9bff3efd57b00ee'
result={'coverage':'passed','all_source_hashes_match':True,'links_verified':links,'reference_clean':True,'tag_preserved':True,'review_scope':'static source/contract/flow audit','runtime_or_paid_ai_tests':'not executed this audit'}
(out/'report-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
