use quote::ToTokens;
use serde_json::{json,Value};
use syn::{visit::{self,Visit},spanned::Spanned};
struct Calls { calls:Vec<String>, literals:Vec<String> }
impl<'a> Visit<'a> for Calls {
 fn visit_expr_call(&mut self,n:&'a syn::ExprCall) { self.calls.push(n.func.to_token_stream().to_string()); visit::visit_expr_call(self,n); }
 fn visit_expr_method_call(&mut self,n:&'a syn::ExprMethodCall) { self.calls.push(format!(".{}",n.method)); visit::visit_expr_method_call(self,n); }
 fn visit_lit_str(&mut self,n:&'a syn::LitStr) { self.literals.push(n.value()); }
 fn visit_macro(&mut self,n:&'a syn::Macro) { self.calls.push(format!("{}!",n.path.to_token_stream())); }
}
struct Index { scope:Vec<String>, entries:Vec<Value> }
impl Index {
 fn function(&mut self,sig:&syn::Signature,body:Option<&syn::Block>,vis:&syn::Visibility,attrs:&[syn::Attribute]) {
  let mut calls=Calls{calls:vec![],literals:vec![]}; if let Some(body)=body { calls.visit_block(body); }
  self.entries.push(json!({"kind":"function","scope":self.scope.join("::"),"name":sig.ident.to_string(),"line":sig.span().start().line,"end_line":body.map(|b|b.span().end().line),"visibility":vis.to_token_stream().to_string(),"signature":sig.to_token_stream().to_string(),"attributes":attrs.iter().map(|a|a.to_token_stream().to_string()).collect::<Vec<_>>(),"calls":calls.calls,"literals":calls.literals}));
 }
}
impl<'a> Visit<'a> for Index {
 fn visit_item_mod(&mut self,n:&'a syn::ItemMod) { self.entries.push(json!({"kind":"module","name":n.ident.to_string(),"scope":self.scope.join("::"),"line":n.span().start().line,"visibility":n.vis.to_token_stream().to_string(),"inline":n.content.is_some()}));self.scope.push(n.ident.to_string());visit::visit_item_mod(self,n);self.scope.pop(); }
 fn visit_item_impl(&mut self,n:&'a syn::ItemImpl) { self.scope.push(format!("impl {}{}",n.trait_.as_ref().map(|(_,p,_)|format!("{} for ",p.to_token_stream())).unwrap_or_default(),n.self_ty.to_token_stream()));visit::visit_item_impl(self,n);self.scope.pop(); }
 fn visit_item_trait(&mut self,n:&'a syn::ItemTrait) { self.entries.push(json!({"kind":"trait","name":n.ident.to_string(),"line":n.span().start().line,"definition":n.to_token_stream().to_string()}));self.scope.push(n.ident.to_string());visit::visit_item_trait(self,n);self.scope.pop(); }
 fn visit_item_fn(&mut self,n:&'a syn::ItemFn) { self.function(&n.sig,Some(&n.block),&n.vis,&n.attrs); }
 fn visit_impl_item_fn(&mut self,n:&'a syn::ImplItemFn) { self.function(&n.sig,Some(&n.block),&n.vis,&n.attrs); }
 fn visit_trait_item_fn(&mut self,n:&'a syn::TraitItemFn) { self.function(&n.sig,n.default.as_ref(),&syn::Visibility::Inherited,&n.attrs); }
 fn visit_item_use(&mut self,n:&'a syn::ItemUse) { self.entries.push(json!({"kind":"use","line":n.span().start().line,"visibility":n.vis.to_token_stream().to_string(),"definition":n.to_token_stream().to_string()})); }
 fn visit_item_const(&mut self,n:&'a syn::ItemConst) { self.entries.push(json!({"kind":"const","name":n.ident.to_string(),"line":n.span().start().line,"visibility":n.vis.to_token_stream().to_string(),"definition":n.to_token_stream().to_string()})); }
 fn visit_item_static(&mut self,n:&'a syn::ItemStatic) { self.entries.push(json!({"kind":"static","name":n.ident.to_string(),"line":n.span().start().line,"visibility":n.vis.to_token_stream().to_string(),"definition":n.to_token_stream().to_string()})); }
 fn visit_item_foreign_mod(&mut self,n:&'a syn::ItemForeignMod) { self.entries.push(json!({"kind":"foreign_interface","line":n.span().start().line,"definition":n.to_token_stream().to_string()})); }
 fn visit_item_struct(&mut self,n:&'a syn::ItemStruct) { self.entries.push(json!({"kind":"struct","name":n.ident.to_string(),"line":n.span().start().line,"definition":n.to_token_stream().to_string()})); }
 fn visit_item_enum(&mut self,n:&'a syn::ItemEnum) { self.entries.push(json!({"kind":"enum","name":n.ident.to_string(),"line":n.span().start().line,"definition":n.to_token_stream().to_string()})); }
 fn visit_impl_item_type(&mut self,n:&'a syn::ImplItemType) { self.entries.push(json!({"kind":"associated_type","name":n.ident.to_string(),"scope":self.scope.join("::"),"line":n.span().start().line,"definition":n.to_token_stream().to_string()})); }
 fn visit_trait_item_type(&mut self,n:&'a syn::TraitItemType) { self.entries.push(json!({"kind":"associated_type","name":n.ident.to_string(),"scope":self.scope.join("::"),"line":n.span().start().line,"definition":n.to_token_stream().to_string()})); }
 fn visit_item_type(&mut self,n:&'a syn::ItemType) { self.entries.push(json!({"kind":"type","name":n.ident.to_string(),"line":n.span().start().line,"definition":n.to_token_stream().to_string()})); }
}
fn main(){
 let args:Vec<String>=std::env::args().skip(1).collect();let mut all=Vec::new();
 for repo in args { let output=std::process::Command::new("git").args(["-C",&repo,"ls-files"]).output().unwrap();let list=String::from_utf8(output.stdout).unwrap();
  for path in list.lines().filter(|p|p.ends_with(".rs")){let text=std::fs::read_to_string(format!("{repo}/{path}")).unwrap();match syn::parse_file(&text){Ok(file)=>{let mut idx=Index{scope:vec![],entries:vec![]};idx.visit_file(&file);all.push(json!({"repo":repo,"path":path,"vendor":path.starts_with("vendor/"),"lines":text.lines().count(),"entries":idx.entries}));},Err(err)=>{all.push(json!({"repo":repo,"path":path,"parse_error":err.to_string()}));}}}
 }
 println!("{}",serde_json::to_string_pretty(&all).unwrap());
}
