from pathlib import Path
import json,hashlib,subprocess,re,tomllib,collections
root=Path(__file__).resolve().parents[2]; out=root/'evidence/full-review'
ast=json.loads((out/'ast-index.json').read_text())
R='reference-rust_ai_chat'; P='copilot_use'
# 每組對照由實際職責判定，沒有同名檔案也必須列出對應或缺口。
groups=[]
def group(id,title,r,p,contract,flow,decision):
 groups.append(dict(id=id,title=title,reference=r.split(),product=p.split(),contract=contract,data_flow=flow,decision=decision))
group('C01','Chat Domain','crates/chat_domain/src/lib.rs','crates/chat_domain/src/lib.rs','ChatMessage/MessageAuthor/Room → MessageInput/Committed/MessageError；String ID → UUID；category_room_id 無對應','HTTP author/room/content → validate → repository；Domain 不匯入 Driver','概念可映射、公開型別與序列化不等同；category 不能當 topic')
group('C02','Chat Application','crates/chat_application/src/lib.rs crates/chat_application/src/repository.rs','crates/chat_application/src/lib.rs crates/chat_application/src/tests.rs','create_room/RoomRepository、MessageRepository::create、persist_then_publish → MessageRepository::commit/CommitFuture/persist','參考 create→callback；成品 validate→commit→Committed(inserted)','儲存後才通知的不變量對應；無 RoomRepository 等同實作；保留 durable Adapter')
group('C03','Chat 事件','crates/chat_application/src/product_event.rs tests/chat/product_event_contract.rs','crates/shared/src/lib.rs','PersistedMessageEvent → ProductEvent；四欄 message.persisted 一致；參考 String message ID 必須可轉 UUID','參考事件 factory 尚非 Outbox；成品 stage 同交易→gRPC','四欄事件子集可適配，不能宣稱所有事件／發送方式相同')
group('C04','Chat SQLite','crates/persistence/src/lib.rs','crates/persistence/src/lib.rs crates/persistence/src/tests.rs crates/persistence/src/database.rs crates/persistence/src/database/tests.rs','SqliteRoom/MessageRepository → ChatWriter；rooms/messages → chat_rooms/chat_messages；UUID BLOB/ACL/Outbox/realtime','BEGIN IMMEDIATE→message+outbox+topic+realtime→commit；失敗 rollback；SQLite backup/import','同為 SQLite，schema/交易邊界不相同；參考 41 字元測試斷言與文字相反')
group('C05','Chat 入口/HTTP/SSR','apps/server/src/http.rs apps/server/src/lib.rs apps/server/src/main.rs apps/server/src/ssr.rs apps/server/src/state.rs tests/server/day5_tests.rs','apps/server/src/main.rs apps/server/src/lib.rs apps/server/src/web.rs apps/server/frontend/src/main.rs','/api/rooms {name} 200 {id} → /api/v1/rooms {id,name} 201；/health → /healthz；3000 → 3001','Leptos SSR→browser HTTP→auth/ACL→SQLite；入口狀態從 repositories 變為 StateData','API 不相容；產品入口保留，教學需明示 adapter/URL/DTO')
group('C06','Chat WS/Fanout','apps/server/src/ws.rs apps/server/src/hub.rs','apps/server/src/realtime.rs apps/server/src/fanout.rs','ClientEvent/ServerEvent tagged DTO → flat notifications/HTTP send；broadcast128 → durable realtime polling','參考 WS persist_then_publish→room hub；成品 HTTPcommit→canonical DB fanout→WS，lag→resync_required','保留跨程序 durability/ACL；不能把參考 socket 當成品 client')
group('C07','Chat UI','crates/ui/src/lib.rs crates/ui/src/chat_socket.rs crates/ui/src/room_api.rs','crates/ui/src/lib.rs crates/ui/src/browser.rs','參考 typed WS/room API → auth UI、HTTP messages、notification WS、SSE/retryqueue','Hydrate→session→room ACL→HTTP；斷線 reconnect + resync，不以樂觀UI當 durable','映射頁面／生命週期，非逐檔移植；參考 hardcoded localhost WS 不適用部署')
group('C08','Chat 認證','','apps/server/src/auth.rs','Argon2/users/sessions/CSRF/owner/member/invite/throttle；參考無對應','登入→hash sessiontoken→SQLite；write→CSRF+ACL；auth事件與狀態同交易','產品安全擴充，不刪除以追求 reference 相同')
group('C09','Chat RAG/MCP/Agent','','apps/server/src/knowledge.rs apps/server/src/knowledge/tests.rs apps/server/src/mcp.rs apps/server/src/agent.rs','owner-scoped document/1536 embedding；MCP readonly tools；bounded citations','auth→owner retrieve/MCP→provider→citation查證→重新 principal/ACL→persist','產品擴充；Agent 外部呼叫後有授權複核，不可概括到所有 AI 入口')
group('C10','Chat AI SSE','','apps/server/src/openai.rs','ReplyRequest{room_id,rag}；delta/done/error；completed 才 persist','先 auth/ACL→provider stream→Decoder/output buffer→ChatWriter.persist_as→done','靜態缺口：produce 未攜 actor/headers，完成前未複核 session/ACL；尚未修正或實測撤權 race')
group('C11','Chat personas/policy','','apps/server/src/personas.rs apps/server/src/suggestions.rs','persona revision/lease/run budgets；approved proposal/context policy/CAS receipts','owner→bounded run→durable turn revision/lease CAS；proposal→apply→rollback compare revision','產品擴充，不能用一般 ChatMessage factory 取代')
group('C12','Chat 同意撤回','','apps/server/src/topic_http.rs crates/persistence/src/topics.rs','consent flag/topic outbox/withdrawal batch；本文與 owner 不進事件','同意→訊息 txn stage topics；withdraw→local disable+outbox→Analytics tombstone→ack','產品隱私擴充；category 與 topic 語意分離')
group('C13','Chat persist/publish 回歸','tests/chat/persist_publish.rs','','FakeRepo 成功一次/失敗不publish；成品 C02/C04 tests','參考 callback ordering；成品 DB atomic+fanout 重讀','測試目的映射，保留 owning crate tests，不建立根 tests workspace')
group('P01','Pet FSM','crates/pet_domain/src/lib.rs crates/pet_domain/src/error.rs tests/pet/pet_machine.rs','crates/pet_domain/src/lib.rs crates/pet_runtime/src/interaction.rs','Idle/Interacting/Sleeping、Interact/FinishInteraction/Sleep/Wake、revision → Action/Speed/proactive','參考 dispatch→snapshot→event→UI revision；成品 settings→animation/reminder','狀態與命令不相容；Sleep/Wake/revision 目前無等同流程，不能空造同名型別')
group('P02','Pet Profile','crates/pet_domain/src/profile.rs tests/pet/profile_contract.rs tests/pet/day5_codec_tests.rs','crates/pet_domain/src/profile.rs crates/pet_domain/src/application.rs crates/pet_domain/src/application/tests.rs','五欄/optional appearance-animation；JSON codec → TOML codec/limits/AssetManifest/ProfileRepository','Tauri→save_profile validation→PetStore.save→SQLite→private TOML projection','概念對應，格式/驗證/錯誤不等同；ProjectionPending 必須保留')
group('P03','Pet cleanup Domain','crates/pet_domain/src/cleanup.rs crates/pet_domain/src/cleanup_event.rs tests/pet/cleanup_contract.rs tests/pet/cleanup_event_contract.rs','','Previewed→Confirmed→Succeeded/Failed；pet.cleanup.succeeded → file.cleanup.succeeded','參考純狀態，並非真 OS receipt；成品真隔離成功 receipt→SQLite/Outbox','事件名稱不相容；對照成品 P08，不以狀態成功代替真操作成功')
group('P04','Pet Tauri 入口','apps/desktop_pet/src/lib.rs apps/desktop_pet/src/main.rs apps/desktop_pet/build.rs','apps/desktop_pet/src/main.rs apps/desktop_pet/build.rs','參考四 IPC/get_pet_state/send_pet_command/chat_with_pet/scan_file_preview → 44 IPC','GUI→invoke→runtimeStore/confirmedRoot→serialized result；preview opaqueID cache','40 frontend command names 對應44 backend；非參考 bridge/DTO 等同；詳列呼叫端與簽章')
group('P05','Pet Frontend','apps/desktop_pet/frontend/src/bridge.rs apps/desktop_pet/frontend/src/component/activity.rs apps/desktop_pet/frontend/src/component/chat.rs apps/desktop_pet/frontend/src/component/control.rs apps/desktop_pet/frontend/src/component/mod.rs apps/desktop_pet/frontend/src/main.rs','apps/desktop_pet/frontend/src/main.rs','window.getPetState/... wrappers + snapshot revision → __TAURI__.core.invoke + settings/asset UI','參考 listener→apply_snapshot；成品 IPC result→reactive UI；drag權限由Tauri capability','前端 schema/狀態不同；保留既有功能，不能直接替换參考 component')
group('P06','Pet 真視窗漫遊','apps/desktop_pet/src/roam.rs','','monitor work_area/current_position/set_position bounded movement','參考 window moves→verify progress→bounce/stop；成品僅window內角色動畫','參考功能尚未對應成品；缺失為 native window roaming，不把sprite移动宣稱等同')
group('P07','Pet preview/duplicates','apps/desktop_pet/src/file_organizer.rs','','AuthorizedRoot/ScanPreview/duplicate_preview SHA256 → runtime AuthorizedRoot/FilePreview','參考 recursivescan→sizegroups→revalidate+hash；成品 root.scan→opaqueUUID/name/size','對照P08：安全preview存在，重複檔案雜湊分組尚未對應')
group('P08','Pet 真 OS quarantine/restore','','crates/pet_runtime/src/lib.rs crates/pet_runtime/src/unix_fs.rs crates/pet_runtime/src/windows_fs.rs','pinnedroot/preview/confirm/Trash/CleanupReceipt/RestoreReceipt/journal','確認→revalidate pinned OS entry→隔離/還原→journal receipt；failedDB→recovery→Outbox','產品安全擴充；FS與DB非單一交易，明確部分成功與恢復，不假稱零窗口')
group('P09','Pet Store/Profile 投影','','crates/pet_runtime/src/state.rs crates/pet_runtime/src/files.rs crates/pet_runtime/src/registry.rs','PetStore/memory/cards/conversation/assets/archive/projection','SQLite canonical→serialized private fileprojection；reconcile；archive active setting+event txn','產品擴充；對照Profile與五欄概念；資料隔離／filepath不進publicevent')
group('P10','Pet 學習/備份','','crates/pet_domain/src/learning.rs crates/pet_runtime/src/backup.rs','Schedule::review/time injected；SQLite snapshots/checksums/restore safety snapshot','quality→pure Schedule→Card+Outbox txn；VACUUM→hash→private restore migration/merge','產品擴充；不在Domain匯SQLx，backup與reference preview不是對應功能')
group('P11','Pet Chat/Agent/生圖','apps/desktop_pet/src/chat.rs','crates/pet_runtime/src/ai.rs crates/pet_runtime/src/agent.rs crates/pet_runtime/src/main.rs','MockChatModel → actualOpenAI/profile+memories+boundedstdio MCP；generated asset profilehash','userprompt→profile/memory/history→provider→conversations/eventtxn；assets staleversioncheck','參考 mock 不等同成品AI；真實AI本輪未執行，readonlytool限制保留')
group('P12','Pet Outbox/policy','','crates/pet_runtime/src/outbox.rs crates/pet_runtime/src/suggestions.rs','lease_token/lease_until/CASACK/backoff/blocked/requeue；approved policy receipt','claim→gRPC→matching ACK→CAS delivered；fail重試/blocked；policy rollback revision','產品可靠投遞擴充；At-least-once delivery+durable dedup，非無限 exactly-once保證')
group('P13','Pet 更新/平台回歸','','apps/desktop_pet/src/updater.rs apps/desktop_pet/tests/glib_variant_safety.rs','check→verify→confirmed install；optimized Linux GLib str iterator regression','configured signedupdate→downloadverify→install/restart；test platformcfgLinux','無參考 counterpart；Windows/macOS runtime 本輪未重跑；vendor列獨立清單')
group('A01','Analytics reference契約','apps/stats_server/src/lib.rs apps/stats_server/src/main.rs tests/analytics/event_kind_tests.rs tests/analytics/http_contract_tests.rs tests/analytics/idempotency_contract.rs tests/analytics/postgres_ingest.rs tests/common/mod.rs','apps/stats_server/src/application.rs','EventInput/InMemoryDeduplicator/501 → EventRepository/Analytics/RepositoryError','參考 validinput→501，FakeStore並非PG；成品 receive→durable repository','參考未實作不是成品應退回501；strict event whitelist不等同任意非空kind')
group('A02','Analytics HTTP/入口','','apps/stats_server/src/lib.rs apps/stats_server/src/main.rs','source token ingest/query/admin tokens；HTTP 202/409/400/503；PGhealth','sourceauth→receive→PG commit→HTTPack；separatequeryauth','產品擴充；四欄shape對應，驗證/status/security不相容')
group('A03','Analytics PostgreSQL','','apps/stats_server/src/persistence.rs','PgPool/EventStore；source+eventID durable dedup/typehash conflict','BEGIN→dedupkey+event insert→commit/revision trigger；duplicate不重計；query排除archive/withdraw','產品 durable實作；参考HashSet不能替換；PGmigration非SQLite')
group('A04','Analytics gRPC','','apps/stats_server/src/grpc.rs apps/stats_server/src/grpc/tests.rs','EventIngestion.IngestEvents；1..64/64KiB/4fields/outcomes','wholebatch auth beforewrite→per-event transaction→ACK；Unavailable後可重送已commit事件','批次非全有全無；來源不可冒用；共享application非旁路SQL')
group('A05','Analytics Dashboard/SSE','','apps/stats_server/src/dashboard.rs apps/stats_server/src/live.rs','HTTP queries + SSE revision/polling/max16 streams；fetchBearer','commit→DBrevision→SSEnotification→dashboardquery；disconnectDBfailurecloses','SSE非event replay或gRPC替代；aggregate自動更新、recent/trend手動')
group('A06','Analytics governance/topics','','apps/stats_server/src/governance.rs apps/stats_server/src/topics.rs','Taipei timeline/archive/restore；topic tombstones/withdraw','authorizedtransaction→archiveflags/revision；latearrivalprivacy excludes via tombstone','產品擴充；archive後重送不復活，withdraw不等archive')
group('A07','Analytics Insights','','apps/stats_server/src/insights.rs','aggregate→proposal pending/approved/rejected/applied/rolled_back；receipts/evaluate','grounded stats→AI suggestion→humanreview→targetapply→receipt→descriptiveevaluation','產品擴充；不把描述性變化當因果/uniqueusers；本輪不執行AI')
group('X01','Shared wire/type','crates/shared/src/lib.rs','crates/shared/src/topics.rs','參考 WS DTO → 產品 ProductEvent(C03)/fixedtopiclabels','typed WSconsumer(C06/C07) 對照 product通知；事件→transport','同名crate不同職責；禁止把 WS Message本文加入low-sensitivity analytics schema')
group('X02','AI Provider','crates/ai_core/src/lib.rs','crates/ai_core/src/lib.rs crates/ai_core/src/agent.rs','ChatModel/ChatRequest/Response/Mock → Provider/Decoder/embedding/sprite/agent tools','bounded HTTP Responses/Image/embedding→callercheckedstorage；decoder splitschunkframes','具體Adapter非純Domain；參考trait抽象沒有直接實作等同保證')
group('X03','MCP','','crates/mcp_bridge/src/lib.rs','HttpClient/JSONRPC/toolmetadata/header validation；stdio另P11','host-scopedtools→protocol→boundedexecute；不可tools自行擴scope','產品 Driver，不進 Domain/Application；實際server另server::mcp/runtime')
group('X04','Analytics transport','','crates/analytics_transport/build.rs crates/analytics_transport/src/lib.rs','Tonic/Prost build from shared/proto/analytics.proto；u16↔uint32、UUID↔string','Outbox→3s connect/10s request→sourceBearer→matchingid/source/Stored或AlreadyExists→ACK','產品driver，timeout<30s lease；permanentstatusesblocked；proto不存在參考')
group('X05','Telemetry','crates/telemetry/src/lib.rs','crates/telemetry/src/lib.rs','參考空crate → OTelinit/exporter/header sanitize/span HTTP metrics','route/method/status+traceparent→collector；禁止繼承敏感OTelheaders','產品擴充；沒有空模組功能等同；不以AST說明取代部署collector驗證')
# Cover every own file exactly once; overlapping conceptual comparisons point to IDs rather than duplication.
for repo,key in [(R,'reference'),(P,'product')]:
 paths=[f['path'] for f in ast if f['repo']==repo and not f['vendor']]
 assigned=[p for g in groups for p in g[key]]
 assert set(paths)==set(assigned),(repo,'missing',set(paths)-set(assigned),'extra',set(assigned)-set(paths))
 assert len(assigned)==len(set(assigned)),(repo,'duplicate')
(out/'module-mapping.json').write_text(json.dumps(groups,ensure_ascii=False,indent=2)+'\n')
# 全 tracked bytes 身分與類別；不把讀取hash稱為手動文件內容审阅。
files=[]
for repo in [R,P]:
 paths=subprocess.check_output(['git','-C',str(root/repo),'ls-files','-z']).decode().split('\0')
 for p in filter(None,paths):
  b=(root/repo/p).read_bytes()
  cat='third_party' if p.startswith('vendor/') else 'rust' if p.endswith('.rs') else 'migration' if p.endswith('.sql') else 'manifest' if p.endswith('.toml') else 'lock' if p.endswith('.lock') else 'protocol' if p.endswith('.proto') else 'ci' if p.startswith('.github/') else 'script' if p.startswith('scripts/') else 'document' if p.startswith('docs/') or p.endswith('.md') else 'configuration_or_asset'
  files.append(dict(repo=repo,path=p,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),category=cat))
(out/'tracked-files.json').write_text(json.dumps(files,ensure_ascii=False,indent=2)+'\n')
# 保留精確 signatures/types + private callers; no guessed overload resolution.
lines=['# 全部自有 Rust 宣告、介面與呼叫點','', '來源固定於本報告 SHA。含 public/private/trait methods、DTO fields/serde attributes、常數、reexports、外部 JS interface、cfg/test。呼叫清單為語法節點，不展開巨集、不解析接收者型別／動態dispatch；跨檔案可靠接線見資料流程報告。此清單不是 compiler call graph。','']
for f in ast:
 if f['vendor']:continue
 g=next(g for g in groups if f['path'] in g['reference' if f['repo']==R else 'product'])
 lines += [f"## {f['repo']}/{f['path']} · {g['id']}",'',f"職責：{g['title']}。判定：{g['decision']}",'']
 for e in f['entries']:
  lines.append(f"### L{e['line']} · {e['kind']} · {e.get('scope','')} {e.get('name','')}")
  lines.append('')
  value=e.get('signature',e.get('definition',f"{e.get('visibility','')} mod {e.get('name','')} (inline={e.get('inline')})"))
  lines.extend(['```rust',value,'```',''])
  if e['kind']=='function':
   lines.append('可見性／屬性：`'+e.get('visibility','private/inherited')+'`；`'+' '.join(e.get('attributes',[]))+'`。')
   lines.append('')
   lines.append('函式內呼叫：'+ ('；'.join('`'+c+'`' for c in e['calls']) or '無可解析直接呼叫／trait 無 body')+'。')
   lines.append('')
(out/'interface-catalog.md').write_text('\n'.join(lines)+'\n')
# 逐命令列 frontend 原文（macro 內 JSON payload）與 backend signature，保留 dynamic Value 限制。
ui=(root/P/'apps/desktop_pet/frontend/src/main.rs').read_text().splitlines()
backend=[(f,e) for f in ast if f['repo']==P for e in f['entries'] if e['kind']=='function' and any('tauri :: command' in a for a in e['attributes'])]
cmds={e['name']:(f,e) for f,e in backend}
contracts=[]
for name,(f,e) in sorted(cmds.items()):
 calls=[dict(path='apps/desktop_pet/frontend/src/main.rs',line=i+1,source=s.strip()) for i,s in enumerate(ui) if re.search(r'call\("'+re.escape(name)+r'"',s)]
 contracts.append(dict(command=name,backend_path=f['path'],line=e['line'],signature=e['signature'],frontend_calls=calls))
(out/'ipc-payloads.json').write_text(json.dumps(contracts,ensure_ascii=False,indent=2)+'\n')
# Cargo 依賴及 DB schema／入口路由索引：每個檔案都有 path+line，不省略補充契約。
contracts=['# 非 Rust 契約與入口索引','','Rust types/serde/signatures 見 interface-catalog；本檔完整收錄 tracked manifests、migrations、proto、CI/scripts/config 的身分。歷史文件和圖像只列身分，不推論目前執行結果。','']
for f in files:
 p=f['path']; repo=f['repo']
 if f['category']=='third_party':continue
 if f['category'] in ['manifest','migration','protocol','ci','script'] or p.endswith(('.js','.mjs','.html','.css')) or p in ['compose.yaml','Dockerfile','.env.example','apps/desktop_pet/tauri.conf.json','apps/desktop_pet/capabilities/default.json']:
  text=(root/repo/p).read_text()
  contracts += [f'## {repo}/{p}','',f"SHA256 `{f['sha256']}`。",'', '```', '\n'.join(f'{i+1}: {s}' for i,s in enumerate(text.splitlines())), '```','']
(out/'configuration-contracts.md').write_text('\n'.join(contracts)+'\n')
summary=dict(reference_sha=subprocess.check_output(['git','-C',str(root/R),'rev-parse','HEAD']).decode().strip(),product_sha=subprocess.check_output(['git','-C',str(root/P),'rev-parse','HEAD']).decode().strip(),tracked_counts=dict(collections.Counter(f['repo'] for f in files)),rust_counts=dict(collections.Counter(f['repo'] for f in ast)),own_rust_counts=dict(collections.Counter(f['repo'] for f in ast if not f['vendor'])),parse_errors=[f for f in ast if 'parse_error' in f],own_declarations=dict(collections.Counter(e['kind'] for f in ast if not f['vendor'] for e in f['entries'])),module_groups=len(groups),all_own_rust_files_assigned_once=True,backend_ipc_commands=len(cmds),frontend_ipc_commands=len(set(re.findall(r'call\("([^"]+)"','\n'.join(ui)))),paid_ai_executed=False,semantic_equivalence=False)
(out/'coverage.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
