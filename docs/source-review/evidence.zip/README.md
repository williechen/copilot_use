完整固定 SHA 靜態核對證據。Rust語法索引、lexical references不是type-resolved graph；沒有AI或部署重測。重現工具原先要求同層 reference-rust_ai_chat/copilot_use checkout；audit產物SHA以coverage.json為準，文件更新不改寫原始snapshot。
